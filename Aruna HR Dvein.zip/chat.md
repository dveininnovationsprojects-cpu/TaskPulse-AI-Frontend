# WhatsApp Chat Export: Aruna HR Dvein
Export date: October 23, 2026 at 10:38 AM

---

## August 4, 2026

[4:39 PM] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[4:39 PM] **Aruna HR Dvein:** Sri Ramakrishna College Of Engineering

[4:39 PM] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[4:39 PM] **You:** Thank you mam

[4:39 PM] **Aruna HR Dvein:** perambalur

[4:39 PM] **Aruna HR Dvein:** location name

[5:30 PM] **Aruna HR Dvein:** [Image]

[7:25 PM] **You:** Mam

[7:25 PM] **You:** Call pannigala

[7:25 PM] **You:** Thiruvanamali

[7:55 PM] **You:** Aruna mam

[7:55 PM] **You:** Antha pasaga kita pasuga

[7:56 PM] **You:** Sikiram

[9:49 PM] **You:** Mam

[9:50 PM] **You:** Busy ah erukura mathiri natikathiga . Antha thiruvanamali payan kita pesuga . Suriya kuta avaga friends gang la oru ponnu pesitu erukaam so suriya antha clg la pesuna avagaluku ketikum easy ah

[9:50 PM] **You:** Na avalotha soluvan

[9:52 PM] **Aruna HR Dvein:** Trm mess pani pesuran ok va

[9:52 PM] **You:** Eppo msg pannuga

[9:53 PM] **You:** Onga mela erukura akarila solura🫩

[9:53 PM] **You:** Ethuku mela onga verupam

[9:54 PM] **Aruna HR Dvein:**
> _You: Eppo msg pannuga_
[Voice message]

[9:55 PM] **You:** Na solura mathiri msg pannuga

[9:55 PM] **You:** Hii I am Aruna Devi

[9:56 PM] **You:** Munik sir number kututharunu matum soluga

[9:56 PM] **You:** Respect ah replay varalana yanna Venum nalum yanna bad words la thituga na vaakiran

[9:56 PM] **You:** But my name mention pannuga

[10:00 PM] **Aruna HR Dvein:** Mess paniruken

[10:01 PM] **You:** Hmm

---

## August 5, 2026

[10:39 AM] **You:** Ok

[10:58 AM] **You:** Ppt na pananuma

[10:58 AM] **You:** ?

[10:58 AM] **You:** Illa change pannuvagala clg ku vara person ah

[10:58 AM] **Aruna HR Dvein:** Trm ne enna eduka poriyoo atha pananum

[10:59 AM] **Aruna HR Dvein:**
> _You: Illa change pannuvagala clg ku vara person ah_
Thrla still edhuvu sollala

[10:59 AM] **You:** Hmm

[10:59 AM] **Aruna HR Dvein:** Ne panura mari panu pathukalam

[10:59 AM] **You:** Onga hero suriya kuti poga

[10:59 AM] **You:**
> _Aruna HR Dvein: Ne panura mari panu pathukalam_
Hmm

[10:59 AM] **Aruna HR Dvein:**
> _You: Onga hero suriya kuti poga_
Ok nan solikuren

[10:59 AM] **You:** Ok

[7:05 PM] **Aruna HR Dvein:** Munik

[7:05 PM] **You:** Hmm

[7:05 PM] **Aruna HR Dvein:** Ne vara apo enoda lap kondu variya nan vandhu vaangikuren

[7:05 PM] **You:**
> _Aruna HR Dvein: Ne vara apo enoda lap kondu variya nan vandhu vaangikuren_
Yappo

[7:06 PM] **You:** Clg ah

[7:06 PM] **Aruna HR Dvein:**
> _You: Yappo_
Aft 8clk

[7:06 PM] **You:**
> _Aruna HR Dvein: Aft 8clk_
Bus stop varava

[7:06 PM] **Aruna HR Dvein:** Lla nan kfc kitaiye varen

[7:06 PM] **Aruna HR Dvein:** Ne kelambura apo oru call adi

[7:06 PM] **You:** Hmm ok

[7:06 PM] **Aruna HR Dvein:** Podhum

[7:06 PM] **You:**
> _Aruna HR Dvein: Ne kelambura apo oru call adi_
Ok

[7:10 PM] **You:** Sahana yanna songa

[7:10 PM] **You:** Ppt ku

[7:11 PM] **Aruna HR Dvein:** Onu sollave lla

[7:13 PM] **You:** Today sema tention ah eruku

[7:13 PM] **You:** Ethalam personal ah kuptu solirukalam la

[7:13 PM] **You:** Yara ketu data science nu potikanu

[7:13 PM] **You:** Nama 2 perukutha meeting ah

[7:15 PM] **Aruna HR Dvein:**
> _You: Nama 2 perukutha meeting ah_
I know

[7:15 PM] **Aruna HR Dvein:** Feel free

[7:17 PM] **You:** Rompa depration ah eruku

[7:17 PM] **You:** 😔

[7:46 PM] **Aruna HR Dvein:** Dei kelambura apo sollu da

[7:46 PM] **Aruna HR Dvein:**
> _You: Rompa depration ah eruku_
Vidu vaaa

[7:47 PM] **Aruna HR Dvein:** Trm nama nalla pani spr ah vdo eduthu post podurom

[7:47 PM] **You:**
> _Aruna HR Dvein: Dei kelambura apo sollu da_
7.55 ku niga room la eruthu kalampu

[7:47 PM] **You:** Correct ah erukim

[7:47 PM] **Aruna HR Dvein:**
> _You: 7.55 ku niga room la eruthu kalampu_
Ok da

[7:47 PM] **You:** Yanaku balance illa nitha call pananum

[7:47 PM] **Aruna HR Dvein:**
> _You: Yanaku balance illa nitha call pananum_
Ok da

[7:47 PM] **You:** Laptop o kita thana eruku

[7:47 PM] **You:**
> _Aruna HR Dvein: Trm nama nalla pani spr ah vdo eduthu post podurom_
Mass panurom🔥

[7:47 PM] **Aruna HR Dvein:**
> _You: Laptop o kita thana eruku_
[Voice message]

[7:48 PM] **Aruna HR Dvein:**
> _You: Mass panurom🔥_
We will do it vro🤩🥳

[7:48 PM] **You:**
> _Aruna HR Dvein: Voice message_
Bag oota yatuthu varava

[7:48 PM] **You:**
> _Aruna HR Dvein: We will do it vro🤩🥳_
Vata vaaki kutu eppo

[7:48 PM] **You:** Pls

[7:49 PM] **Aruna HR Dvein:**
> _You: Vata vaaki kutu eppo_
Puriyala

[7:49 PM] **Aruna HR Dvein:**
> _You: Pls_
Vadai ya

[7:49 PM] **Aruna HR Dvein:**
> _You: Bag oota yatuthu varava_
[Voice message]

[7:50 PM] **You:** Ok

[7:50 PM] **You:**
> _Aruna HR Dvein: Vadai ya_
Ama

[10:40 PM] **Aruna HR Dvein:** [Image]

[10:40 PM] **Aruna HR Dvein:** Side la paru made with Gamma nu varudhu da

[11:17 PM] **You:** Mam

[11:17 PM] **You:** Sahana mam ku send pannitigala mam

[11:27 PM] **Aruna HR Dvein:** panitan

---

## August 6, 2026

[8:18 AM] **You:** 7358447233

[10:49 AM] **Aruna HR Dvein:** [Document] Dvein Workshop Presentation (2).pdf

[6:36 PM] **Aruna HR Dvein:** [Forwarded] [Video]

[6:36 PM] **Aruna HR Dvein:** [unknown message]

---

## August 7, 2026

[10:18 PM] **You:** Mam

[10:19 PM] **You:** Tomorrow course illa la mam

[10:19 PM] **You:** Morning 9.30 ku office vanthuratuma mam?

[10:48 PM] **Aruna HR Dvein:**
> _You: Morning 9.30 ku office vanthuratuma mam?_
Hm ama

[10:48 PM] **You:** Tq mam

---

## August 10, 2026

[6:17 PM] **You:** Hii

[6:18 PM] **Aruna HR Dvein:** hii

[6:19 PM] **You:** Avagaluku matum yaa sikiram poraga

[6:20 PM] **You:** Namalum tha anaki naai mathiri alachu workshop mutuchu vanthom

[6:20 PM] **Aruna HR Dvein:** avanga trm workshop porangalam so sikiram ah porangalam adhn sikiram poranga

[6:20 PM] **Aruna HR Dvein:** nama ponathu 1 day dhn eh adhan polla

[6:20 PM] **You:** Evaga sokusa car la bike la poutu vanthaga nama avalo kaista pattu bus la vanthom

[6:20 PM] **Aruna HR Dvein:**
> _You: Namalum tha anaki naai mathiri alachu workshop mutuchu vanthom_
adhungalam apdthan vidu adhungaluku money matter avlodhn vera onumae kedaiyathu

[6:21 PM] **You:**
> _Aruna HR Dvein: adhungalam apdthan vidu adhungaluku money matter avlodhn vera onumae kedaiyathu_
Yanaku yanana thariyala rompa depration ah eruku

[6:21 PM] **Aruna HR Dvein:** Surely they face a "KARMA"

[6:21 PM] **Aruna HR Dvein:** God will see

[6:21 PM] **You:** Yappo intha place vettu povom nu eruku

[6:21 PM] **You:** Chi

[6:21 PM] **Aruna HR Dvein:** nan friday oorku pogitu wednesday dhn varuvan appa ta pesitan avarum vara sonanga vandhutu poga soli

[6:22 PM] **You:** Na o kuta lam santa potuvan but niga alum pothum yanaku yanna nu lam paathukitu suma eruka matan

[6:22 PM] **You:**
> _Aruna HR Dvein: nan friday oorku pogitu wednesday dhn varuvan appa ta pesitan avarum vara sonanga vandhutu poga soli_
Friday night ah oruku

[6:22 PM] **Aruna HR Dvein:**
> _You: Na o kuta lam santa potuvan but niga alum pothum yanaku yanna nu lam paathukitu suma eruka matan_
yen epd sollura?

[6:22 PM] **Aruna HR Dvein:**
> _You: Friday night ah oruku_
ticket epo kedaichalum pogiduvan da train la

[6:23 PM] **You:**
> _Aruna HR Dvein: ticket epo kedaichalum pogiduvan da train la_
Hmm ok

[6:23 PM] **You:** Nanum yappo da uruku povom nu eruku

[6:23 PM] **You:** But thirupi vara putikala

[6:23 PM] **Aruna HR Dvein:**
> _You: Nanum yappo da uruku povom nu eruku_
Enaku dhn

[6:23 PM] **You:** Manasukula oru mathiri kaistama eruku

[6:23 PM] **Aruna HR Dvein:** Mind la heavy ah iruku same manasum oru mari iruku

[6:23 PM] **You:** But yaa nu thariyala

[6:23 PM] **Aruna HR Dvein:**
> _You: Manasukula oru mathiri kaistama eruku_
Same here

[6:23 PM] **You:** Thapana place la erukomo nu thonuthu

[6:23 PM] **Aruna HR Dvein:** Ne nan selvamani navin la same ah paper potaa apo theryum idhungaluku

[6:24 PM] **You:** Namakana place ethu illa yo nu thonuthu

[6:24 PM] **Aruna HR Dvein:**
> _You: Thapana place la erukomo nu thonuthu_
Apdthan irukom eh yen ne vera

[6:24 PM] **You:**
> _Aruna HR Dvein: Ne nan selvamani navin la same ah paper potaa apo theryum idhungaluku_
Super nanum sikiram papar poturuvan

[6:24 PM] **Aruna HR Dvein:**
> _You: Namakana place ethu illa yo nu thonuthu_
Enakula epovo thoniduchi munik growth suthama lla

[6:24 PM] **Aruna HR Dvein:** Epd amt employee kita kekuranga

[6:24 PM] **You:** Ama

[6:25 PM] **Aruna HR Dvein:** Sahana enkita direct ah kekala jayasri ah vachi keta yen avlo ego iruntha enkita Straight ah keturukalam la

[6:25 PM] **You:** Navin selvamani ku yapaum salary sikiram poturuvaga avagaluka eppo leat

[6:25 PM] **You:** Appo namaku

[6:25 PM] **You:** 🤷‍♂️

[6:25 PM] **You:**
> _Aruna HR Dvein: Sahana enkita direct ah kekala jayasri ah vachi keta yen avlo ego iruntha enkita Straight ah keturukalam la_
Amount ah

[6:25 PM] **Aruna HR Dvein:**
> _You: Appo namaku_
Namakulla ramatham

[6:25 PM] **Aruna HR Dvein:**
> _You: Amount ah_
Ama

[6:25 PM] **Aruna HR Dvein:** Enkita jayasri keta mam kekuranganu soli

[6:25 PM] **Aruna HR Dvein:** Aftnoon

[6:25 PM] **You:**
> _Aruna HR Dvein: Namakulla ramatham_
Pg owner morning ah ketan

[6:25 PM] **Aruna HR Dvein:**
> _You: Pg owner morning ah ketan_
Rent ah?

[6:25 PM] **You:**
> _Aruna HR Dvein: Enkita jayasri keta mam kekuranganu soli_
Yaa new manager kita keka vetiyathu thana

[6:26 PM] **You:**
> _Aruna HR Dvein: Rent ah?_
Ama

[6:26 PM] **Aruna HR Dvein:**
> _You: Yaa new manager kita keka vetiyathu thana_
Adhan sir ku theriyamathan eh selvamani kita ketanga

[6:27 PM] **You:** Suriya sir kita keka solura

[6:27 PM] **You:** Oru mathiri heart kita Wight ah erukura mathiri feel akuthu

[6:27 PM] **Aruna HR Dvein:** nanu adhan sona ah avan ta illamaiya nu soli

[6:27 PM] **You:**
> _You: Oru mathiri heart kita Wight ah erukura mathiri feel akuthu_
But yaa na thariyala

[6:28 PM] **You:** Work pressure erutha yanaku happy but inga vera yatho pressure aakuthu

[6:28 PM] **Aruna HR Dvein:**
> _You: But yaa na thariyala_
ada chi vidu namaku nama parents irukanga namala pathupanga and nama ellaru nallathah iruka porom god will wtaching all the things so feel free vidu illana next meeting la nan eh soliduvan openup ah

[6:28 PM] **Aruna HR Dvein:**
> _You: Work pressure erutha yanaku happy but inga vera yatho pressure aakuthu_
yen ne yen pressure agura

[6:29 PM] **You:**
> _Aruna HR Dvein: ada chi vidu namaku nama parents irukanga namala pathupanga and nama ellaru nallathah iruka porom god will wtaching all the things so feel free vidu illana next meeting la nan eh soliduvan openup ah_
Pakalam

[6:29 PM] **Aruna HR Dvein:** enakula unaiya vida avlo pressure da weight loss agitae iruku inga vandhu health issues over agiduchi enaku

[6:29 PM] **You:**
> _Aruna HR Dvein: yen ne yen pressure agura_
Thariyala evaga intern or course ah kontu varaga . Inga yathuku vanthom eppo yanna work pannitu erukom

[6:29 PM] **You:**
> _Aruna HR Dvein: enakula unaiya vida avlo pressure da weight loss agitae iruku inga vandhu health issues over agiduchi enaku_
Tharium

[6:30 PM] **Aruna HR Dvein:**
> _You: Thariyala evaga intern or course ah kontu varaga . Inga yathuku vanthom eppo yanna work pannitu erukom_
crt dhn da vidu side la job thedu nanla adhan pana ah poren

[6:30 PM] **You:** Eppo matum yanaku inverter ketacha tomorrow ah papar poturuvan na ready ah erukan

[6:30 PM] **You:** Invester tha thetitu erukan

[6:30 PM] **Aruna HR Dvein:** v2ku la odira matan vera nalla job theda poren

[6:30 PM] **Aruna HR Dvein:**
> _You: Eppo matum yanaku inverter ketacha tomorrow ah papar poturuvan na ready ah erukan_
illa vera company la select agita aprm dhn paper podanum da

[6:30 PM] **Aruna HR Dvein:** interview nu poda kudathu

[6:30 PM] **You:**
> _Aruna HR Dvein: v2ku la odira matan vera nalla job theda poren_
Atha nala idea v2 ku pona aprom appa once vera nala company ketachalum veta mataga

[6:31 PM] **You:**
> _Aruna HR Dvein: interview nu poda kudathu_
Interview illa invester

[6:32 PM] **Aruna HR Dvein:**
> _You: Atha nala idea v2 ku pona aprom appa once vera nala company ketachalum veta mataga_
Ama ama adhan yosikuren

[6:32 PM] **Aruna HR Dvein:** Nanu

[6:33 PM] **Aruna HR Dvein:**
> _You: Interview illa invester_
Ohh ok ok

[7:16 PM] **You:** Hmm

[7:16 PM] **You:** Sorry

[7:21 PM] **You:** Sorry if I hurt you in any way

[7:24 PM] **Aruna HR Dvein:**
> _You: Sorry if I hurt you in any way_
Enna new va sollura

[7:28 PM] **You:**
> _Aruna HR Dvein: Enna new va sollura_
Yanna new ah soluran

[10:56 PM] **Aruna HR Dvein:**
> _You: Yanna new ah soluran_
Sry la sollura ne adhan sona ah

[10:57 PM] **You:** 😂

[10:57 PM] **You:** Eruka porathu kocha days thana nama yalarum

[10:57 PM] **You:** So antha days la yathuku muchiya thukitu erukanum

[10:58 PM] **You:** Ni yanna sonalum na kochuka matan🩷

[10:58 PM] **You:** Happy ah erukalam kocha days eruthalum

[10:59 PM] **Aruna HR Dvein:** Konjam days nallu atha ninaichi pathalae kastama iruku la🥲🫠

[10:59 PM] **Aruna HR Dvein:**
> _You: Ni yanna sonalum na kochuka matan🩷_
Yen apd?

[11:01 PM] **You:**
> _Aruna HR Dvein: Konjam days nallu atha ninaichi pathalae kastama iruku la🥲🫠_
Rompa

[11:01 PM] **You:** 1 month or 2 months avalotha

[11:02 PM] **Aruna HR Dvein:**
> _You: 1 month or 2 months avalotha_
Yen da ne vera🧎🏻‍♀️❤️‍🩹

[11:02 PM] **You:** Athu varakum nala memories create panalam ni na selvamani navin

[11:02 PM] **Aruna HR Dvein:**
> _You: Athu varakum nala memories create panalam ni na selvamani navin_
🥺🥺❣️kandipa

[11:02 PM] **You:** No fight muchiya thukitu eruthu yanna kontu poka porom

[11:03 PM] **You:** So athalam vetam Ora oru jenma matum tha. So athula matum tha nama 4 perum ona work pannurom

[11:03 PM] **You:** So antha moment ah happy ah kontu pokalam nariya photo yatukalam

[11:07 PM] **Aruna HR Dvein:** [Voice message]

[11:08 PM] **You:** Ok onnum worry pannigathiga . Jolly ah erupom🩷

[11:10 PM] **You:** Tomorrow la eruthu nama work la 1000 problem erukalam but nama jolly ah intha time ah use full ah good things ah share panalam

[11:10 PM] **You:** ☺️🤗

[11:11 PM] **You:** Evagalukaka aluthu onga Tears waste panathiga

[11:11 PM] **You:** Gn morning happy morning ah erukum ☺️😁

[11:11 PM] **You:** Time

[11:11 PM] **You:** 11:11

[11:12 PM] **You:** Trust universal

[11:12 PM] **You:** Gn

[11:41 PM] **Aruna HR Dvein:**
> _You: Tomorrow la eruthu nama work la 1000 problem erukalam but nama jolly ah intha time ah use full ah good things ah share panalam_
💯💯kandipa

[11:41 PM] **Aruna HR Dvein:**
> _You: Evagalukaka aluthu onga Tears waste panathiga_
❤️‍🩹🧎🏻‍♀️

[11:42 PM] **Aruna HR Dvein:**
> _You: Trust universal_
Yeah I'll believe this one

[11:42 PM] **Aruna HR Dvein:** Good night

---

## August 11, 2026

[7:10 AM] **You:** Gm

[9:35 AM] **Aruna HR Dvein:** Gud mrng ✨

[11:00 AM] **Aruna HR Dvein:** [Image]

[6:12 PM] **Aruna HR Dvein:** [Document] OFFER-   Data Analytics (1).pdf

[6:15 PM] **Aruna HR Dvein:** [Contact: BEGIN:VCARD
VERSION:3.0
N:;Sahana;;;
FN:Sahana
TEL;type=Mobile;waid=917358447233:+91 73584 47233
END:VCARD]

[6:15 PM] **You:** Panitan

[6:15 PM] **Aruna HR Dvein:** Intha number dhn eh vachiruka ne

[6:15 PM] **Aruna HR Dvein:** Idhula pesi

[6:15 PM] **Aruna HR Dvein:** Pesu

[6:15 PM] **You:**
> _Aruna HR Dvein: Intha number dhn eh vachiruka ne_
Anaki nigatha send paniga

[6:15 PM] **You:** Eruku

[6:16 PM] **Aruna HR Dvein:** Ok ok

[6:16 PM] **You:** Ok

[6:16 PM] **You:** Snacks saptu polam

[6:16 PM] **Aruna HR Dvein:**
> _You: Snacks saptu polam_
Poda nan varula dress wash pananum neriya work iruku

[6:16 PM] **Aruna HR Dvein:** Sema tired ah iruku

[6:16 PM] **You:**
> _Aruna HR Dvein: Poda nan varula dress wash pananum neriya work iruku_
Nanum tha wash pananum

[6:16 PM] **You:** Eruka saptu polam

[6:16 PM] **You:** Today tha yanaku nimathiya eruku

[6:17 PM] **You:** So porom niga na navin selvamani

[6:17 PM] **You:** Sapturom

[6:18 PM] **Aruna HR Dvein:** Illa munik navin ta kelu suthama mudiyala force panatha

[6:20 PM] **You:** 🥲

[6:20 PM] **You:** [Sticker]

[6:20 PM] **You:** Savu

[6:20 PM] **You:** Mam

[6:20 PM] **You:** Eppo yanaku oruthavaga call panaga

[6:20 PM] **Aruna HR Dvein:**
> _You: Savu_
Unwanted ah ne pesatha seriya

[6:20 PM] **You:** Job vaaki kututhathuku aprom amount pay panna pothum nu

[6:20 PM] **Aruna HR Dvein:**
> _You: Eppo yanaku oruthavaga call panaga_
Soo

[6:21 PM] **You:** Avaga yapdina nama offer letter lam kututhutu antha company la join panathum nama pay panna pothum

[6:21 PM] **You:** Atha nampalama

[6:21 PM] **You:** ?

[6:23 PM] **You:**
> _Aruna HR Dvein: Soo_
Epdi illa so what nu kekanum

[6:25 PM] **Aruna HR Dvein:**
> _You: Atha nampalama_
Noo

[6:27 PM] **You:**
> _Aruna HR Dvein: Noo_
Hmm ok tq

---

## August 12, 2026

[7:28 AM] **You:** Good morning

[7:28 AM] **You:** College name ?

[7:32 AM] **Aruna HR Dvein:** Alpha College Of Engineering

[7:33 AM] **You:** Tq

[8:01 AM] **You:** [Document] ALPHA COLLEGE.docx

[8:02 AM] **You:** mam just niga once check pannitu soluga ongaluku yathum correction thariyalana next na sahana mam ku send pannura avaga ok sonathuku aprom clg ku send paniralam

[8:02 AM] **You:** niga check pannitu correction erutha soluga na change panni tharan

[8:06 AM] **Aruna HR Dvein:** Haan seri munik

[8:06 AM] **You:** Ok

[8:07 AM] **Aruna HR Dvein:**
> _You: Document: ALPHA COLLEGE.docx_
Sahana ku send panidu munik

[8:08 AM] **Aruna HR Dvein:** Overall ok va iruku avangakita send panidu

[8:08 AM] **You:** hmm ok

[8:08 AM] **Aruna HR Dvein:** Spelling mistakes lla dhn eh nan check pana ah lla edhuvh

[8:09 AM] **You:**
> _Aruna HR Dvein: Spelling mistakes lla dhn eh nan check pana ah lla edhuvh_
Nanum check pannitan

[8:09 AM] **Aruna HR Dvein:** IT students uh data science padipanga dhn eh?

[8:09 AM] **Aruna HR Dvein:**
> _You: Nanum check pannitan_
Okiee da share with sahana

[8:09 AM] **You:** Last time careless mistake but altime etha mathiri natakathu

[8:09 AM] **You:**
> _Aruna HR Dvein: Okiee da share with sahana_
Panitan

[8:10 AM] **You:**
> _Aruna HR Dvein: IT students uh data science padipanga dhn eh?_
Avagaluku basic computer science tha erukum

[8:14 AM] **Aruna HR Dvein:**
> _You: Last time careless mistake but altime etha mathiri natakathu_
Ok munuk

[8:14 AM] **Aruna HR Dvein:**
> _You: Panitan_
Ok da

[8:14 AM] **Aruna HR Dvein:**
> _You: Avagaluku basic computer science tha erukum_
Seri seri apo ok

[8:14 AM] **You:** Hmm

[8:49 AM] **You:** https://youtube.com/shorts/1x_THG8PppU?si=LlvZHQY_EoZLQxIY

[3:33 PM] **You:** Hi

[3:33 PM] **You:** Yaa yanna achu

[3:35 PM] **Aruna HR Dvein:** Paper enaiku podalam yosikuren

[3:35 PM] **You:** Yaa

[3:35 PM] **You:** Yanna achu

[3:35 PM] **You:** Yathum sonagal

[3:36 PM] **Aruna HR Dvein:** nooo

[3:36 PM] **You:** Aprom yanna achu

[3:36 PM] **You:** Eppo yanga poraga

[3:37 PM] **Aruna HR Dvein:** thrla enga poranganu

[3:37 PM] **You:** Hmm

[3:39 PM] **You:** [Document] ALPHA COLLEGE_.pdf

---

## August 13, 2026

[10:46 AM] **Aruna HR Dvein:** [Document] Dvein Workshop Presentation (2)_compressed.pdf

[5:33 PM] **You:** Mam sir kita maatikitaga

[5:33 PM] **You:** Sir Jaya sree ku payakarama text poturukaka

[5:33 PM] **Aruna HR Dvein:** Enanu da

[5:33 PM] **Aruna HR Dvein:**
> _You: Sir Jaya sree ku payakarama text poturukaka_
Enanu

[5:33 PM] **You:** Ongala thola pannurathuku sorry jaya sri mam

[5:34 PM] **You:** Yalathukum thanks

[5:34 PM] **Aruna HR Dvein:** Amt mater ah?

[5:34 PM] **You:**
> _Aruna HR Dvein: Amt mater ah?_
Avaga yaru kuta pourukakanu

[5:34 PM] **Aruna HR Dvein:**
> _You: Avaga yaru kuta pourukakanu_
Puriyala

[5:34 PM] **You:** Avalo time kukuraru mam yarukuta pourukakanu

[5:34 PM] **Aruna HR Dvein:**
> _You: Avalo time kukuraru mam yarukuta pourukakanu_
Pogirukangana?

[5:34 PM] **You:**
> _Aruna HR Dvein: Puriyala_
Mam eppo veliya ponagala cirtificate ku yaru kuta ponaganu

[5:34 PM] **Aruna HR Dvein:** Intha certificate vaanga ponangalaae athuva

[5:34 PM] **You:**
> _Aruna HR Dvein: Intha certificate vaanga ponangalaae athuva_
Ama

[5:35 PM] **Aruna HR Dvein:**
> _You: Mam eppo veliya ponagala cirtificate ku yaru kuta ponaganu_
Jayasri enna sona ah athuku

[5:35 PM] **You:**
> _Aruna HR Dvein: Jayasri enna sona ah athuku_
Mam kita phone kututhuruchu

[5:35 PM] **Aruna HR Dvein:** Jayasri mess ah katucha unkita

[5:35 PM] **Aruna HR Dvein:**
> _You: Mam kita phone kututhuruchu_
Loosu ava

[5:35 PM] **Aruna HR Dvein:** Vera enna keturukaru

[5:35 PM] **You:**
> _Aruna HR Dvein: Jayasri mess ah katucha unkita_
Ama sir msg panna panna katuchu

[5:35 PM] **Aruna HR Dvein:**
> _You: Ama sir msg panna panna katuchu_
Paravalaiyae

[5:35 PM] **You:**
> _Aruna HR Dvein: Jayasri mess ah katucha unkita_
Mam tha vaakitaga

[5:35 PM] **Aruna HR Dvein:**
> _You: Mam tha vaakitaga_
Ok ok da

[5:36 PM] **You:**
> _Aruna HR Dvein: Vera enna keturukaru_
Nariya pasunaru

[5:36 PM] **Aruna HR Dvein:**
> _You: Nariya pasunaru_
Enanu

[5:36 PM] **You:** Jaya sri soluchu sir kita work related ah matum keluganu

[5:36 PM] **You:** Aprom delete paniruchu

[5:36 PM] **Aruna HR Dvein:** Loosa ah ava manager ta poitu epd pesiruka ah ava?

[5:36 PM] **You:** Sir ketaru ni yanga erukiga mam ... Onga mam yanga erukakanu

[5:37 PM] **Aruna HR Dvein:**
> _You: Sir ketaru ni yanga erukiga mam ... Onga mam yanga erukakanu_
Maybe avaru pathuruparu nu ninaikuren veliya

[5:37 PM] **You:** Jaya sri soluchu na office la sir mam cirtificate vaaka pourugaka nu

[5:37 PM] **You:** Yaru kuta nu ketaru

[5:37 PM] **Aruna HR Dvein:** ADHAN kekuraaru polla

[5:37 PM] **You:** Mam kita ketuchu sir epdi kekuraru yanna solanu. Mam songa na matum pourukanu solunu

[5:37 PM] **Aruna HR Dvein:**
> _You: Yaru kuta nu ketaru_
Avaru oru nal inga vandhu pakkanum apo iruku blast uhh blast uhh💥

[5:37 PM] **Aruna HR Dvein:**
> _You: Mam kita ketuchu sir epdi kekuraru yanna solanu. Mam songa na matum pourukanu solunu_
Karumoooo

[5:38 PM] **You:**
> _Aruna HR Dvein: Avaru oru nal inga vandhu pakkanum apo iruku blast uhh blast uhh💥_
Avaru mechir vara mataru

[5:38 PM] **Aruna HR Dvein:** Suriya naiyu nalla evlo agudhu paru

[5:38 PM] **Aruna HR Dvein:**
> _You: Avaru mechir vara mataru_
Puriyala

[5:38 PM] **You:** Sir soluraru yalathukum thanks apdinu

[5:38 PM] **Aruna HR Dvein:**
> _You: Sir soluraru yalathukum thanks apdinu_
Ohhh

[5:38 PM] **You:**
> _Aruna HR Dvein: Puriyala_
[GIF]

[5:38 PM] **Aruna HR Dvein:** Seri Vera enna achi

[5:38 PM] **You:**
> _You: Video_
Avaru

[5:38 PM] **Aruna HR Dvein:** Vera edhuvu sollalaiya avaru

[5:39 PM] **You:**
> _Aruna HR Dvein: Seri Vera enna achi_
Avaru ketaru yarum Sola kutathunu solirukakala yaa kita nu

[5:39 PM] **Aruna HR Dvein:**
> _You: Avaru ketaru yarum Sola kutathunu solirukakala yaa kita nu_
😅😂

[5:50 PM] **You:** Yathuku poi solura jaya sri

[5:50 PM] **You:** Yanna paatha yapdi thariuthu unaku nu kuturukaru

[5:51 PM] **Aruna HR Dvein:** 🤯😱🙄

[6:20 PM] **You:** Ama

[6:20 PM] **You:** Polamputhu

---

## August 14, 2026

[12:58 PM] **Aruna HR Dvein:** Nan thirumbura apolam prasanth pathute iruntha and nenga pesurathaiyu pathutu irunthan adhan sona ah llana soliruka matan munik

[1:01 PM] **You:** Niga yannota nakathukutha soluriga yanaku puriuthu but avanuka kuta compare panunathutha putikala

[1:02 PM] **You:** Other wise niga nariya time soli na amithiya eruthurukan

[1:02 PM] **You:** So avaga la nanakum pothu tha putikathu

[1:02 PM] **You:** Sari vetuga athalam onnum illa

[1:02 PM] **You:** Paathu ponga oruku ☺️

[1:03 PM] **Aruna HR Dvein:** enaku meeting la ungala edhuvu solida kudathunu dhn nan apo apove unga kita kekuran kathuren puriyudha unaku

[2:01 PM] **You:** Hmm ok ok atha vetu

[2:01 PM] **You:** Saptu po

[2:01 PM] **You:** Yanaku yappo 6 mani aaka pokutho?

[2:01 PM] **You:** 🫩

[3:56 PM] **Aruna HR Dvein:**
> _You: Yanaku yappo 6 mani aaka pokutho?_
Haha

[3:56 PM] **Aruna HR Dvein:**
> _You: Saptu po_
Ok da

[4:33 PM] **You:** Hmm

---

## August 16, 2026

[6:05 PM] **You:** Hii mam

[6:05 PM] **You:** Course pasaga pay pannitagala?

[6:05 PM] **You:** Tomorrow yenagu office 9.30 or 11.00

[6:08 PM] **Aruna HR Dvein:**
> _You: Tomorrow yenagu office 9.30 or 11.00_
11 ah?

[6:08 PM] **Aruna HR Dvein:** Avanga trm dhn pay panuvanga munik

[6:25 PM] **You:**
> _Aruna HR Dvein: Avanga trm dhn pay panuvanga munik_
Apdiya

[6:25 PM] **You:** Trm paniruvagala

[9:52 PM] **Aruna HR Dvein:**
> _You: Trm paniruvagala_
Ama panuranu solitanga

[9:52 PM] **Aruna HR Dvein:** Edhuku jayasri ta ketukuriya

[9:53 PM] **Aruna HR Dvein:** Chni pogitiya munik

[10:18 PM] **You:**
> _Aruna HR Dvein: Edhuku jayasri ta ketukuriya_
Athu unga kita keka soluchu

[10:18 PM] **You:**
> _Aruna HR Dvein: Chni pogitiya munik_
Selam

[10:19 PM] **You:** Tmr 9.30 ku pogava 11 ah office?

[10:19 PM] **You:** Atha thariyala😕

[10:19 PM] **Aruna HR Dvein:**
> _You: Tmr 9.30 ku pogava 11 ah office?_
Ne 9.30 poo munik Tuesday la irundhu cls vachikalam

[10:19 PM] **Aruna HR Dvein:** SERIYA

[10:19 PM] **Aruna HR Dvein:**
> _You: Selam_
Ok ok saptya?

[10:19 PM] **You:**
> _Aruna HR Dvein: Ne 9.30 poo munik Tuesday la irundhu cls vachikalam_
Tq😁

[10:19 PM] **You:**
> _Aruna HR Dvein: Ok ok saptya?_
No

[10:19 PM] **Aruna HR Dvein:**
> _You: Tq😁_
Okiee daw☺️

[10:19 PM] **Aruna HR Dvein:**
> _You: No_
Why?

[10:20 PM] **You:**
> _Aruna HR Dvein: Why?_
Travel la

[10:20 PM] **You:** Atha

[10:20 PM] **Aruna HR Dvein:** Crt dhn

[10:28 PM] **You:** Hmm

[10:28 PM] **You:** Entha week no program thana?

[10:29 PM] **Aruna HR Dvein:**
> _You: Entha week no program thana?_
Edhuku kekura ne?

[10:30 PM] **You:** Workshop

[10:41 PM] **Aruna HR Dvein:** Illa avanga 26 vachirukanga

[10:41 PM] **Aruna HR Dvein:** Coming Wednesday llama next Wednesday

---

## August 17, 2026

[3:32 AM] **You:** Hmm

[2:19 PM] **You:** Pay pannitagala

[2:19 PM] **You:** Antha pasaga

[2:20 PM] **Aruna HR Dvein:** Panitanga mrg eh

[2:55 PM] **You:** Apdiya

[2:55 PM] **You:** 😕

[2:55 PM] **You:** Tomorrow thana class

[3:25 PM] **Aruna HR Dvein:**
> _You: Tomorrow thana class_
Ama ama

[3:43 PM] **You:** Hmm

---

## August 18, 2026

[8:23 AM] **You:**
> _Aruna HR Dvein: Video_
Hay

[8:23 AM] **You:** Ethu yeppo yetuthathu

[8:23 AM] **You:** 😂

[8:45 AM] **You:** Today course eruku thana

[8:45 AM] **You:** Yenaku

[8:51 AM] **You:** Tomorrow vanthuruvigala ?

[9:00 AM] **Aruna HR Dvein:**
> _You: Today course eruku thana_
Ama ama

[9:00 AM] **Aruna HR Dvein:**
> _You: Tomorrow vanthuruvigala ?_
Ama munik ana wfh

[9:01 AM] **You:**
> _Aruna HR Dvein: Ama munik ana wfh_
Yee

[6:17 PM] **Aruna HR Dvein:** Trm jayasri v2ku ethana mani ku poringa ellarum?

[6:17 PM] **Aruna HR Dvein:** Ava kita neeye ketu sollu munik

[6:17 PM] **Aruna HR Dvein:** And Thursday epd poringa marriage ku?

[6:17 PM] **Aruna HR Dvein:** Office la irundhu porom ah lla epd?

[6:17 PM] **Aruna HR Dvein:** Kellu

[6:18 PM] **You:**
> _Aruna HR Dvein: Trm jayasri v2ku ethana mani ku poringa ellarum?_
7 clock food ah

[6:18 PM] **You:** So yeppo veturaganu thariyala

[6:18 PM] **You:** Niga tmr vanthuruvigala

[6:18 PM] **Aruna HR Dvein:**
> _You: So yeppo veturaganu thariyala_
Ok ok da

[6:19 PM] **You:**
> _Aruna HR Dvein: Office la irundhu porom ah lla epd?_
Ama yelarum

[6:19 PM] **Aruna HR Dvein:**
> _You: Niga tmr vanthuruvigala_
Nan wfh da trm adhan yosikuren enaku train mrg 8 clk enaku room vanthutu office vara mudiyala Sema body pain agudhu adhan wfh vaangikitan

[6:19 PM] **Aruna HR Dvein:** Thursday office varuvan

[6:19 PM] **Aruna HR Dvein:**
> _You: Ama yelarum_
Timing?

[6:19 PM] **Aruna HR Dvein:** Coz apodhn Thursday nan ready agitu varuvan epd poringanu therinja dhn

[6:20 PM] **Aruna HR Dvein:**
> _Aruna HR Dvein: Nan wfh da trm adhan yosikuren enaku train mrg 8 clk enaku room vanthutu office vara mudiyala Sema body pain agudhu adhan wfh vaangikitan_
Idhu yartaiyu solikatha

[6:20 PM] **Aruna HR Dvein:** SERIYA

[6:20 PM] **Aruna HR Dvein:** Pakki

[6:20 PM] **You:**
> _Aruna HR Dvein: Thursday office varuvan_
Hay vaaga

[6:20 PM] **You:** Jolly ah polam

[6:20 PM] **You:** Pls

[6:20 PM] **You:**
> _Aruna HR Dvein: Timing?_
Yenaku tharuchu 6 clock or after office

[6:20 PM] **Aruna HR Dvein:**
> _You: Pls_
Edhuku plz pakki

[6:21 PM] **Aruna HR Dvein:**
> _You: Yenaku tharuchu 6 clock or after office_
Mrg 6clk ah?

[6:21 PM] **You:**
> _Aruna HR Dvein: Coz apodhn Thursday nan ready agitu varuvan epd poringanu therinja dhn_
Ama gift vakalama?

[6:21 PM] **Aruna HR Dvein:** Ne jayasri ta ketu soluriya

[6:21 PM] **You:**
> _Aruna HR Dvein: Idhu yartaiyu solikatha_
Okay okay

[6:21 PM] **Aruna HR Dvein:**
> _You: Ama gift vakalama?_
Ama munik nan eh sollanu irunthan ne nan selva navin la oru gift vaangidalam

[6:21 PM] **Aruna HR Dvein:** Because epdiyu suriya&Co thaniya vaanguvanga

[6:21 PM] **You:**
> _Aruna HR Dvein: Pakki_
Ethu Yenna new ah😂

[6:21 PM] **Aruna HR Dvein:** And sahana&co vaanguvanga

[6:22 PM] **Aruna HR Dvein:**
> _You: Ethu Yenna new ah😂_
Chummaaa

[6:22 PM] **You:**
> _Aruna HR Dvein: Ama munik nan eh sollanu irunthan ne nan selva navin la oru gift vaangidalam_
But apdi vaaga mutiyathu yelarum vakunatha vaaga mutium problem akirum

[6:22 PM] **Aruna HR Dvein:**
> _You: But apdi vaaga mutiyathu yelarum vakunatha vaaga mutium problem akirum_
Apdinu solluriya apona nama dhn suriya&co kita kekanum enna panalam nu soli

[6:22 PM] **You:**
> _Aruna HR Dvein: Because epdiyu suriya&Co thaniya vaanguvanga_
Hyy 3 maniku 2 perum veliya ponga ennum varala

[6:22 PM] **Aruna HR Dvein:** Avanunga nama kita solla matanunga keka matanunga

[6:22 PM] **Aruna HR Dvein:** Nama dhn kekanum

[6:22 PM] **Aruna HR Dvein:** Sollanum.

[6:23 PM] **You:**
> _Aruna HR Dvein: Apdinu solluriya apona nama dhn suriya&co kita kekanum enna panalam nu soli_
Ama😂😂 super name suriya & co

[6:23 PM] **You:**
> _Aruna HR Dvein: Avanunga nama kita solla matanunga keka matanunga_
Ama

[6:23 PM] **Aruna HR Dvein:**
> _You: Hyy 3 maniku 2 perum veliya ponga ennum varala_
Rytt raaa nalla vandhurum office🤪

[6:23 PM] **You:** Tmr vaaga pls

[6:23 PM] **Aruna HR Dvein:**
> _You: Ama😂😂 super name suriya & co_
😂🤣

[6:23 PM] **Aruna HR Dvein:**
> _You: Tmr vaaga pls_
Evening ah?

[6:23 PM] **You:**
> _Aruna HR Dvein: Rytt raaa nalla vandhurum office🤪_
🤣🤣🤣🤣🤣nama page ah paaru instagram la

[6:23 PM] **Aruna HR Dvein:** Sahana evening varum ah anga?

[6:23 PM] **Aruna HR Dvein:** Trm

[6:23 PM] **You:**
> _You: 🤣🤣🤣🤣🤣nama page ah paaru instagram la_
4 clock post panurupaga

[6:23 PM] **Aruna HR Dvein:**
> _You: 🤣🤣🤣🤣🤣nama page ah paaru instagram la_
Yen

[6:24 PM] **Aruna HR Dvein:**
> _You: 4 clock post panurupaga_
Pathan karumooo mari irundhuchi content🤢

[6:24 PM] **You:**
> _Aruna HR Dvein: Sahana evening varum ah anga?_
Ama varuvaga .. yethuku una vara solurana tmr srinithi , kaviya, guru yelarum varaga

[6:24 PM] **Aruna HR Dvein:**
> _You: Ama varuvaga .. yethuku una vara solurana tmr srinithi , kaviya, guru yelarum varaga_
Apdiyaa

[6:24 PM] **You:**
> _Aruna HR Dvein: Pathan karumooo mari irundhuchi content🤢_
Course ku 75% discount

[6:24 PM] **You:**
> _Aruna HR Dvein: Apdiyaa_
Ama mass ah erukum vaa fun panalam

[6:25 PM] **Aruna HR Dvein:** [Voice message]

[6:25 PM] **Aruna HR Dvein:** Voice note ah

[6:25 PM] **Aruna HR Dvein:** Slow va kelu

[6:25 PM] **Aruna HR Dvein:** Sound kami pani

[6:25 PM] **Aruna HR Dvein:** Kellu

[6:25 PM] **You:** Okay wait

[6:25 PM] **Aruna HR Dvein:**
> _You: Ama mass ah erukum vaa fun panalam_
Pakuren da

[6:27 PM] **You:**
> _Aruna HR Dvein: Voice message_
Sahana bike la povaga leat aanalum problem illa

[6:27 PM] **You:**
> _Aruna HR Dvein: Voice message_
WFH nu solitu evening vantha kantipa yethachum solum

[6:28 PM] **You:** Travel pannikitu erutha appo yepdi work pathurupanu ketagana?

[6:29 PM] **You:** Tmr morning tha train ah

[6:33 PM] **You:** Tmr yethana maniku varuviga

[6:33 PM] **You:** Chennai

[6:34 PM] **You:** [Voice message]

[6:34 PM] **Aruna HR Dvein:** [Voice message]

[6:35 PM] **You:** Chennai ku yethana maniku varuviga

[6:35 PM] **Aruna HR Dvein:**
> _You: Voice message_
[Voice message]

[6:35 PM] **Aruna HR Dvein:**
> _You: Chennai ku yethana maniku varuviga_
[Voice message]

[6:36 PM] **You:** Tmr vaaga pls

[6:36 PM] **You:** Jolly ah erukum

[6:36 PM] **You:** Tmr matum adjust pannigoka

[6:36 PM] **Aruna HR Dvein:** [Voice message]

[6:37 PM] **Aruna HR Dvein:** [Voice message]

[6:37 PM] **Aruna HR Dvein:**
> _You: Jolly ah erukum_
Jolly ah irukum dhn nan epdinu pakuran da

[6:38 PM] **You:** [Voice message]

[6:38 PM] **You:**
> _Aruna HR Dvein: Jolly ah irukum dhn nan epdinu pakuran da_
Hmm ok

[6:39 PM] **Aruna HR Dvein:**
> _You: Voice message_
[Voice message]

[6:39 PM] **Aruna HR Dvein:** [Voice message]

[6:41 PM] **You:** Okay tmr nala saptu rest yetuga

[6:41 PM] **You:** 😂

[6:44 PM] **Aruna HR Dvein:** Pehhh

[6:44 PM] **You:** Pee

[6:45 PM] **Aruna HR Dvein:** Enna panatu afternoon polla vanthurava

[6:45 PM] **You:** Vantha nala erukum

[6:45 PM] **You:** Jolly ah yelarium kintal panikitu erukalam

[6:46 PM] **Aruna HR Dvein:**
> _You: Jolly ah yelarium kintal panikitu erukalam_
Hey odu

[6:46 PM] **Aruna HR Dvein:**
> _You: Vantha nala erukum_
Crt dhn da

[6:46 PM] **Aruna HR Dvein:** Sahana ethuvu sollum

[6:46 PM] **You:** Unga helth pathugoga

[6:46 PM] **You:**
> _Aruna HR Dvein: Sahana ethuvu sollum_
Afternoon vantha yethum Sola mataga

[6:47 PM] **Aruna HR Dvein:**
> _You: Afternoon vantha yethum Sola mataga_
Seri nan varen

[6:47 PM] **Aruna HR Dvein:** Afternoon polla

[6:47 PM] **You:** First health next jolly

[6:47 PM] **Aruna HR Dvein:**
> _You: First health next jolly_
Crt dhn da

[6:47 PM] **You:**
> _Aruna HR Dvein: Afternoon polla_
Apdiya ok vaaga jolly panalam🤩

[6:47 PM] **You:** 🙌

[6:50 PM] **Aruna HR Dvein:**
> _You: Apdiya ok vaaga jolly panalam🤩_
Pakkuran epdnu

[7:07 PM] **You:** Vaapa jolly ah polam😕

[10:01 PM] **Aruna HR Dvein:** Crt dhn nan epdinu pakkuran

[10:02 PM] **Aruna HR Dvein:** [Voice message]

[10:04 PM] **You:** [Voice message]

[10:06 PM] **Aruna HR Dvein:** Ok munik

[10:07 PM] **Aruna HR Dvein:** [Voice message]

[10:07 PM] **You:**
> _Aruna HR Dvein: Ok munik_
Okay nigalum super ah vaaga

[10:07 PM] **Aruna HR Dvein:**
> _You: Okay nigalum super ah vaaga_
Varen da

[10:08 PM] **You:**
> _Aruna HR Dvein: Voice message_
Vanthuruka

[10:08 PM] **Aruna HR Dvein:**
> _You: Vanthuruka_
Ok kk da

[10:08 PM] **You:** Mam kita Yenna solurathu

[10:09 PM] **You:** Niga eppo tha vanthiganu soluvigala

[10:09 PM] **You:** Illa

[10:09 PM] **Aruna HR Dvein:**
> _You: Mam kita Yenna solurathu_
[Voice message]

[10:09 PM] **You:**
> _You: Illa_
Morning ah vanthutanu soluvigala

[10:10 PM] **Aruna HR Dvein:** [Voice message]

[10:12 PM] **You:** Ama tomorrow niga vetam because yathachum problem varum.

[10:12 PM] **Aruna HR Dvein:**
> _You: Ama tomorrow niga vetam because yathachum problem varum._
Ama da already revenue varula nu solluchi

[10:12 PM] **Aruna HR Dvein:** Sahana

[10:12 PM] **Aruna HR Dvein:** Enaiya

[10:12 PM] **You:** Niga tomorrow night tha kelampuratha ve erukatum. Tomorrow niga varathu theriya vetam

[10:13 PM] **Aruna HR Dvein:**
> _You: Niga tomorrow night tha kelampuratha ve erukatum. Tomorrow niga varathu theriya vetam_
Ama da nan unga kita matum dhn sona ah trm nan vantu rest eduthuruvan

[10:13 PM] **You:**
> _Aruna HR Dvein: Image_
Anake katunigala

[10:13 PM] **Aruna HR Dvein:**
> _You: Anake katunigala_
Adhan adhan

[10:13 PM] **Aruna HR Dvein:** Tension agudhu

[10:14 PM] **Aruna HR Dvein:** Itha pathalae

[10:14 PM] **Aruna HR Dvein:** And

[10:14 PM] **Aruna HR Dvein:** Bayama iruku

[10:14 PM] **You:** Sari athalam vetuga

[10:14 PM] **You:** Tmr vara vetam marriage ku pokalam jolly ah

[10:14 PM] **Aruna HR Dvein:** [Voice message]

[10:14 PM] **Aruna HR Dvein:**
> _You: Tmr vara vetam marriage ku pokalam jolly ah_
Ama da adhan best ah irukum enakum

[10:14 PM] **You:**
> _Aruna HR Dvein: Voice message_
Avagalchum happy ah erukatum

[10:15 PM] **You:** 😂

[10:15 PM] **You:**
> _Aruna HR Dvein: Ama da adhan best ah irukum enakum_
Ama ungalukum tension illla free ah Thursday varalan

[10:15 PM] **Aruna HR Dvein:**
> _You: Avagalchum happy ah erukatum_
Thuuuu😤😤

[10:15 PM] **Aruna HR Dvein:**
> _You: Ama ungalukum tension illla free ah Thursday varalan_
Ama munik

[10:15 PM] **You:**
> _Aruna HR Dvein: Image_
Hayyy

[10:15 PM] **You:** Yenna evalo alaka eruka intha dress la

[10:15 PM] **You:** 🙄

[10:45 PM] **Aruna HR Dvein:** Yen da ne vera

[10:45 PM] **You:** Na yethum solla verumpala

[10:46 PM] **You:** 😂

[10:46 PM] **You:** Sonna thitiva

[10:46 PM] **Aruna HR Dvein:**
> _You: Sonna thitiva_
Enna sollu

[10:46 PM] **Aruna HR Dvein:** Kekuran

[10:46 PM] **You:** Yethuku atipa ala vetu

[10:46 PM] **You:** 🙏

[10:46 PM] **You:** 😂

[10:46 PM] **Aruna HR Dvein:** Ok ok

[10:46 PM] **You:** Hmm

[10:57 PM] **You:** Tomorrow course leave kututhutaga

[10:57 PM] **You:** 😁

[11:12 PM] **Aruna HR Dvein:** Hey enna del paniruka ah solu

[11:12 PM] **Aruna HR Dvein:**
> _You: Tomorrow course leave kututhutaga_
Aprm enna enj dhn

---

## August 19, 2026

[7:02 AM] **You:**
> _Aruna HR Dvein: Aprm enna enj dhn_
Yes😁

[7:58 AM] **You:** Train yeritiya

[8:01 AM] **Aruna HR Dvein:** Waiting da

[8:03 AM] **You:** Hmm ok water lam yetuthitiya

[8:03 AM] **You:** Breakfast complete ah?

[8:12 AM] **Aruna HR Dvein:** [Voice message]

[8:20 AM] **You:** Train driver Yenna mathiri punctuality person ah erupan pola

[8:20 AM] **You:** 😎

[8:20 AM] **Aruna HR Dvein:** 😤💦

[8:42 AM] **You:** Tq😂

[9:58 AM] **Aruna HR Dvein:** 🤣😂

[10:08 AM] **Aruna HR Dvein:** Salary potangala da unaku

[10:10 AM] **You:**
> _Aruna HR Dvein: Salary potangala da unaku_
[Sticker]

[10:11 AM] **You:** Yee atha vera kekura manasalam punna eruku🫩

[10:11 AM] **Aruna HR Dvein:**
> _You: Yee atha vera kekura manasalam punna eruku🫩_
Inu podala dhn eh?

[10:11 AM] **You:** Illa😓

[10:11 AM] **You:** Month mutuchuruchu

[10:11 AM] **You:** V2 la kevalama pesuraga

[10:12 AM] **Aruna HR Dvein:** Athunga vantha revenue ah Rent ku pay panuchingalam jayasri sona ah

[10:12 AM] **Aruna HR Dvein:**
> _You: V2 la kevalama pesuraga_
Ingaiyum dhn da

[10:12 AM] **Aruna HR Dvein:** Appa amma akka la vanthuru llana Vera parunu soluranga

[10:13 AM] **You:**
> _Aruna HR Dvein: Athunga vantha revenue ah Rent ku pay panuchingalam jayasri sona ah_
Appo solanum la . Na Yenna solurana ungaluku problem erukum naga atha understand pannikirom . Thava ilatha vesayathukalam meeting vakirigala appo salary vara intha month leat aakum nu text pota vetiyathuthana

[10:13 AM] **You:**
> _You: Appo solanum la . Na Yenna solurana ungaluku problem erukum naga atha understand pannikirom . Thava ilatha vesayathukalam meeting vakirigala appo salary vara intha month leat aakum nu text pota vetiyathuthana_
Oru varatha sonna namalum v2 la soliralam la . Yesterday poturanu sonaga salary

[10:13 AM] **Aruna HR Dvein:** [Voice message]

[10:14 AM] **Aruna HR Dvein:** [Voice message]

[10:15 AM] **Aruna HR Dvein:**
> _You: Appo solanum la . Na Yenna solurana ungaluku problem erukum naga atha understand pannikirom . Thava ilatha vesayathukalam meeting vakirigala appo salary vara intha month leat aakum nu text pota vetiyathuthana_
Adhan da loosunga mari panudhunga avaluku order potu lipstick vaangave neram pathathu

[10:15 AM] **Aruna HR Dvein:**
> _You: Oru varatha sonna namalum v2 la soliralam la . Yesterday poturanu sonaga salary_
Sahana va?

[10:17 AM] **You:**
> _Aruna HR Dvein: Voice message_
Hmm pakalam

[10:17 AM] **Aruna HR Dvein:**
> _You: Hmm pakalam_
Nan ipove solura epo venalu kelambiduvan da

[10:17 AM] **You:**
> _Aruna HR Dvein: Sahana va?_
Jaya sri kita soli vetaga yekarukutaum solu nu

[10:17 AM] **Aruna HR Dvein:** Enaku suthama pudikala

[10:18 AM] **You:** Yesterday salary vanthurum nu

[10:19 AM] **Aruna HR Dvein:**
> _You: Jaya sri kita soli vetaga yekarukutaum solu nu_
[Voice message]

[10:20 AM] **Aruna HR Dvein:** [Voice message]

[10:21 AM] **Aruna HR Dvein:** [Voice message]

[10:50 AM] **You:** Yenaku offer letter kutukala

[10:57 AM] **Aruna HR Dvein:**
> _You: Yenaku offer letter kutukala_
Vaanganum atha first llana next company pora apo prblm agum

[11:09 AM] **You:**
> _Aruna HR Dvein: Vaanganum atha first llana next company pora apo prblm agum_
Ama

[11:09 AM] **You:** Yeah offer letter tharamaturaganu thariyala

[11:09 AM] **You:** Yenga vanthuta

[11:09 AM] **Aruna HR Dvein:**
> _You: Yenga vanthuta_
Chengalpattu cross

[11:12 AM] **You:** Athukuliya

[11:12 AM] **You:** Sahana mam kanom

[11:12 AM] **You:** Ennum

[11:13 AM] **Aruna HR Dvein:** Inu varulaiya?

[11:13 AM] **Aruna HR Dvein:** Jayasri vanthurukangala

[11:13 AM] **You:**
> _Aruna HR Dvein: Jayasri vanthurukangala_
Illa

[11:13 AM] **You:**
> _Aruna HR Dvein: Inu varulaiya?_
Suriya om ennum varala

[11:14 AM] **Aruna HR Dvein:**
> _You: Suriya om ennum varala_
Apo HmmmHmmm Hmmm😅

[11:14 AM] **Aruna HR Dvein:**
> _You: Illa_
Ok da

[11:14 AM] **You:**
> _Aruna HR Dvein: Apo HmmmHmmm Hmmm😅_
Hayy chi

[11:14 AM] **You:** Peh

[11:15 AM] **Aruna HR Dvein:** 🤣😂

[11:26 AM] **You:** Yethachum snacks vaaki vaa

[11:26 AM] **You:** Sweet ah

[11:26 AM] **Aruna HR Dvein:** Odu

[11:34 AM] **You:** Peh

[11:50 AM] **Aruna HR Dvein:** Vantangala

[11:50 AM] **Aruna HR Dvein:** Avangalam

[11:51 AM] **You:** Illa

[11:51 AM] **Aruna HR Dvein:** Inum llaiya

[11:51 AM] **Aruna HR Dvein:** Ada karumo

[11:51 AM] **Aruna HR Dvein:** Oru vela avanga ipove jayasri v2ku pogirukangalo

[11:51 AM] **You:**
> _Aruna HR Dvein: Oru vela avanga ipove jayasri v2ku pogirukangalo_
Illa illa

[11:52 AM] **You:** Yethachum amount ready panna pourupaga

[11:52 AM] **Aruna HR Dvein:** Then

[11:52 AM] **Aruna HR Dvein:**
> _You: Yethachum amount ready panna pourupaga_
Nanu ninaichan da

[11:52 AM] **You:** Ama

[11:52 AM] **You:** Bike la pourupaga

[11:53 AM] **Aruna HR Dvein:**
> _You: Bike la pourupaga_
🤪

[11:53 AM] **You:** [Sticker]

[11:53 AM] **You:** [Sticker]

[11:55 AM] **Aruna HR Dvein:** [Sticker]

[11:56 AM] **You:** [Sticker]

[11:57 AM] **Aruna HR Dvein:** [Sticker]

[11:59 AM] **You:** [Sticker]

[12:06 PM] **You:** Snacks vaaki vaa pls

[12:39 PM] **Aruna HR Dvein:** Avanga vatangala

[12:55 PM] **You:** Illa

[12:55 PM] **You:** Ennum

[12:56 PM] **You:** Snacks vakunigala illa ah

[12:56 PM] **You:** Vanthacha

[12:56 PM] **Aruna HR Dvein:**
> _You: Snacks vakunigala illa ah_
Illa

[12:56 PM] **Aruna HR Dvein:** Time lla

[12:56 PM] **Aruna HR Dvein:**
> _You: Ennum_
Okiee

[12:57 PM] **You:** Hmm

[12:57 PM] **You:**
> _You: Vanthacha_
.

[1:39 PM] **Aruna HR Dvein:** Hm vantan da

[1:39 PM] **Aruna HR Dvein:**
> _Aruna HR Dvein: Avanga vatangala_
.

[1:50 PM] **You:**
> _Aruna HR Dvein: ._
Illa pa

[1:50 PM] **You:** Ennum varala

[1:52 PM] **Aruna HR Dvein:** Okiee da

[1:52 PM] **Aruna HR Dvein:** SAPTYA

[1:53 PM] **You:**
> _Aruna HR Dvein: SAPTYA_
Hmm saptu poutu erukan

[1:54 PM] **Aruna HR Dvein:** Ok da

[1:54 PM] **You:** Vanthacha room ku

[2:13 PM] **Aruna HR Dvein:** okiee da

[2:17 PM] **You:**
> _You: Vanthacha room ku_
.

[2:21 PM] **Aruna HR Dvein:**
> _You: ._
Vantan da

[2:57 PM] **You:** Hay

[2:57 PM] **You:** 4 manikalam

[2:57 PM] **You:** Kelampa solitaga

[2:57 PM] **You:** Ready aakuravaga ready akitu vaaganu

[2:58 PM] **You:** Oii

[2:58 PM] **You:** Variya

[2:58 PM] **You:** Solu

[2:58 PM] **Aruna HR Dvein:** Illa varula

[2:59 PM] **Aruna HR Dvein:** Tired ah iruku enaku prblm agum so varula

[2:59 PM] **You:** Ok

[3:02 PM] **Aruna HR Dvein:** Un resume share panu

[3:02 PM] **Aruna HR Dvein:** Saradha college la hod mam ketanga

[3:03 PM] **Aruna HR Dvein:** [Voice message]

[3:06 PM] **Aruna HR Dvein:** Avangalum varangala function ku

[3:10 PM] **You:** Course ku soliruga

[3:10 PM] **You:** Antha pasaga kita

[3:10 PM] **You:** Today tomorrow leave nu

[3:11 PM] **You:**
> _Aruna HR Dvein: Un resume share panu_
Data analyst resume venuma or data scientist venuma

[3:13 PM] **Aruna HR Dvein:**
> _You: Today tomorrow leave nu_
Nee mentor dhn eh Neeye grp la message ah podu

[3:13 PM] **Aruna HR Dvein:**
> _You: Data analyst resume venuma or data scientist venuma_
Athu thrla once sahana ta kelu

[3:13 PM] **Aruna HR Dvein:** [Forwarded] [Document] Workshop Proposal - SSCW.pdf

[3:14 PM] **Aruna HR Dvein:** Ithan proposal antha clg oda

[3:30 PM] **You:**
> _Aruna HR Dvein: Nee mentor dhn eh Neeye grp la message ah podu_
Apdiya

[3:31 PM] **You:**
> _Aruna HR Dvein: Athu thrla once sahana ta kelu_
Natha varana first atha keluga

[3:31 PM] **You:**
> _You: Apdiya_
Today matum soliruga today tomorrow no class nu pls

[5:02 PM] **Aruna HR Dvein:**
> _You: Natha varana first atha keluga_
Ama unaiya dhn sonanga needhn

[5:02 PM] **You:** Solitan

[5:03 PM] **Aruna HR Dvein:**
> _You: Solitan_
Nan sonathu resume ku

[5:03 PM] **Aruna HR Dvein:** Mam unaiya sonanganu sona ah

[5:03 PM] **Aruna HR Dvein:** V2ku pogitingala

[5:04 PM] **You:**
> _Aruna HR Dvein: V2ku pogitingala_
6.30 ku office vara solirugaga

[5:04 PM] **You:** Yelarum otuka polam nu

[5:04 PM] **Aruna HR Dvein:**
> _You: Yelarum otuka polam nu_
Spr ehhh

[5:04 PM] **Aruna HR Dvein:** Ipo ellaru enga irukinga

[5:04 PM] **You:** Na navin selvamani my pg la erukom

[5:05 PM] **Aruna HR Dvein:** [Voice message]

[5:05 PM] **Aruna HR Dvein:**
> _You: Na navin selvamani my pg la erukom_
Spr spr

[5:05 PM] **Aruna HR Dvein:** Gift? Ku enna pana ah poringa trm

[5:05 PM] **You:**
> _Aruna HR Dvein: Voice message_
Ok update pannura . Yelarum porom confirm porom

[5:06 PM] **Aruna HR Dvein:**
> _You: Ok update pannura . Yelarum porom confirm porom_
Apo ok timing matu solu da

[5:06 PM] **You:**
> _Aruna HR Dvein: Gift? Ku enna pana ah poringa trm_
Yenna soluraganu disscus pannitu solatuma

[5:06 PM] **You:**
> _Aruna HR Dvein: Apo ok timing matu solu da_
Ok kantipa

[5:06 PM] **Aruna HR Dvein:**
> _You: Yenna soluraganu disscus pannitu solatuma_
Okiee munik

[5:07 PM] **Aruna HR Dvein:**
> _You: Ok kantipa_
[Voice message]

[5:07 PM] **Aruna HR Dvein:** Mazha vara mari iruku ellaru pathu poitu vaanga

[5:07 PM] **Aruna HR Dvein:** SERIYA

[5:08 PM] **You:**
> _Aruna HR Dvein: Voice message_
Okay mam kita tmr yenna plan nu ketu update pannura

[5:08 PM] **You:**
> _Aruna HR Dvein: Mazha vara mari iruku ellaru pathu poitu vaanga_
Yenna vanthalum parava illa saptama vetamatom

[5:09 PM] **Aruna HR Dvein:**
> _You: Yenna vanthalum parava illa saptama vetamatom_
😂🤣

[5:09 PM] **Aruna HR Dvein:**
> _You: Okay mam kita tmr yenna plan nu ketu update pannura_
Ok da

[5:09 PM] **You:** Okay

[9:59 PM] **You:** Oii

[9:59 PM] **You:** Oii

[9:59 PM] **You:** Oi

[9:59 PM] **You:** Oi

[9:59 PM] **You:** Nala vela ni varala

[10:00 PM] **Aruna HR Dvein:**
> _You: Nala vela ni varala_
Yen da

[10:01 PM] **Aruna HR Dvein:** Epd solura

[10:02 PM] **You:** Mam Suriya pannunatha paathu ayyo

[10:02 PM] **You:** [Sticker]

[10:06 PM] **Aruna HR Dvein:**
> _You: Mam Suriya pannunatha paathu ayyo_
Enna pananga ellaru

[10:06 PM] **Aruna HR Dvein:** Trm timing

[10:07 PM] **You:**
> _Aruna HR Dvein: Enna pananga ellaru_
Hay mam saptu eruthaga suriya ninutu eruthan pakathula

[10:07 PM] **You:** Ooti veturaga

[10:07 PM] **You:** Suriya ku

[10:07 PM] **You:** 2 perum white dress

[10:08 PM] **Aruna HR Dvein:**
> _You: Hay mam saptu eruthaga suriya ninutu eruthan pakathula_
Karumooo

[10:09 PM] **You:** Hayy yatho yatho pannuraga

[10:09 PM] **Aruna HR Dvein:**
> _You: 2 perum white dress_
💦💦💦

[10:10 PM] **You:** Rompa over ah poraga

[10:10 PM] **You:** Yenga v2 la kaluvi othuraga ennum salary varaliya company ah vettu vanthuru pathukalam nu

[10:10 PM] **Aruna HR Dvein:**
> _You: Hayy yatho yatho pannuraga_
Enna panuranga

[10:11 PM] **You:** Sola marathutan

[10:11 PM] **Aruna HR Dvein:**
> _You: Yenga v2 la kaluvi othuraga ennum salary varaliya company ah vettu vanthuru pathukalam nu_
Crt dhn eh

[10:11 PM] **Aruna HR Dvein:**
> _You: Sola marathutan_
Sollu da

[10:11 PM] **You:** 2 perum morning la eruthu varala

[10:11 PM] **You:** Aprom evening tha vanthaga

[10:11 PM] **Aruna HR Dvein:**
> _You: 2 perum morning la eruthu varala_
Adhunga enamo panatum

[10:11 PM] **Aruna HR Dvein:**
> _You: Aprom evening tha vanthaga_
Saniyanunga

[10:11 PM] **You:**
> _Aruna HR Dvein: Adhunga enamo panatum_
6 clock

[10:11 PM] **You:** Aprom naga avagalukaka wait pannitu eruthom

[10:11 PM] **Aruna HR Dvein:**
> _Aruna HR Dvein: Trm timing_
.

[10:11 PM] **Aruna HR Dvein:**
> _You: Aprom naga avagalukaka wait pannitu eruthom_
Karumo chaiku

[10:12 PM] **You:** Aprom avaga sonaga niga poga naga varom nu 2 perum thaniya varaga

[10:12 PM] **You:**
> _Aruna HR Dvein: ._
6 clock anga pora mathiri polam nu jaya sri kita solitu eeuthaga

[10:12 PM] **You:** Rompa close ah erukaka

[10:13 PM] **Aruna HR Dvein:**
> _You: 6 clock anga pora mathiri polam nu jaya sri kita solitu eeuthaga_
Mrg 6 ah

[10:13 PM] **Aruna HR Dvein:** Sir vanthara

[10:13 PM] **Aruna HR Dvein:**
> _You: Rompa close ah erukaka_
Karumo

[10:14 PM] **You:**
> _Aruna HR Dvein: Mrg 6 ah_
Evening loosu

[10:14 PM] **You:**
> _Aruna HR Dvein: Sir vanthara_
Call yetukava illa am jaya sri call pannucham

[10:17 PM] **Aruna HR Dvein:**
> _You: Evening loosu_
Trm mrge epo?

[10:18 PM] **Aruna HR Dvein:**
> _You: Call yetukava illa am jaya sri call pannucham_
Haiyooo

[10:18 PM] **Aruna HR Dvein:** Pavaam

[10:18 PM] **You:**
> _Aruna HR Dvein: Trm mrge epo?_
Evening 4 clock

[10:18 PM] **You:**
> _Aruna HR Dvein: Pavaam_
Unga sir loosu

[10:47 PM] **Aruna HR Dvein:**
> _You: Unga sir loosu_
Yen apd sollura

[10:48 PM] **You:** Ama summa mechir saptu erutha

[11:34 PM] **Aruna HR Dvein:**
> _You: Ama summa mechir saptu erutha_
Avaru enaiku vanthara

---

## August 20, 2026

[7:44 AM] **You:**
> _Aruna HR Dvein: Avaru enaiku vanthara_
Illa

[7:45 AM] **You:** Sari normal ah office ku vara mathri va

[7:45 AM] **You:** Ready akita polam

[7:45 AM] **You:** Dress ready ah yetuthu vachutu va

[7:46 AM] **You:** Room poutu bag vachutu dress matum mathitu pora mathiri

[7:47 AM] **Aruna HR Dvein:** Apdiya sollura

[7:47 AM] **Aruna HR Dvein:** Nan dress wear panitae varen da

[7:47 AM] **Aruna HR Dvein:** [Voice message]

[7:47 AM] **Aruna HR Dvein:** Marriage time enna

[7:47 AM] **Aruna HR Dvein:** ?

[7:47 AM] **You:**
> _Aruna HR Dvein: Voice message_
Ok

[7:47 AM] **You:**
> _Aruna HR Dvein: Marriage time enna_
4

[7:48 AM] **Aruna HR Dvein:**
> _You: 4_
4 clk dhn ah?

[7:48 AM] **Aruna HR Dvein:** Evening dhn mrge ah?

[7:48 AM] **You:**
> _Aruna HR Dvein: Evening dhn mrge ah?_
Ama

[7:48 AM] **You:** Mam today varathu

[7:48 AM] **Aruna HR Dvein:** [Voice message]

[7:48 AM] **Aruna HR Dvein:**
> _You: Mam today varathu_
Yen da

[7:48 AM] **You:** Direct ah anga vanthurum marriage ku

[7:48 AM] **Aruna HR Dvein:**
> _You: Direct ah anga vanthurum marriage ku_
Yar sonanga?

[7:49 AM] **You:**
> _Aruna HR Dvein: Voice message_
Okay

[7:49 AM] **Aruna HR Dvein:** [Voice message]

[7:49 AM] **Aruna HR Dvein:**
> _You: Sari normal ah office ku vara mathri va_
Sure da

[7:49 AM] **You:** Okay navin selvamani avaga thurama erukura nala avaga ready ah tha varuvaga

[7:50 AM] **You:** Namaku pakam thana nama ingaya ready aakitu polam

[7:50 AM] **Aruna HR Dvein:**
> _You: Okay navin selvamani avaga thurama erukura nala avaga ready ah tha varuvaga_
Adhan adhan nan mam ta ketu ready aga room vanthuren seriya

[7:50 AM] **Aruna HR Dvein:**
> _You: Namaku pakam thana nama ingaya ready aakitu polam_
Adhan adhan da

[7:50 AM] **You:**
> _Aruna HR Dvein: Adhan adhan nan mam ta ketu ready aga room vanthuren seriya_
Ok

[7:50 AM] **You:** Red dress thana

[7:51 AM] **Aruna HR Dvein:**
> _You: Red dress thana_
Haan ama da

[7:51 AM] **Aruna HR Dvein:** Oorla irunthu vara apove kondu vandhutan

[7:52 AM] **You:**
> _Aruna HR Dvein: Haan ama da_
Mass pannurom🔥

[7:52 AM] **You:**
> _Aruna HR Dvein: Oorla irunthu vara apove kondu vandhutan_
Okay

[7:55 AM] **Aruna HR Dvein:** Gift vaangave llaiye da

[7:56 AM] **Aruna HR Dvein:** [Voice message]

[8:00 AM] **You:** Avaga apditha

[8:00 AM] **You:** Avagaluku Yenna na suriya om avagalum varanum

[8:30 AM] **Aruna HR Dvein:** [Image]

[8:30 AM] **Aruna HR Dvein:** 9.30 to 1clk vara dhn office ah

[8:30 AM] **Aruna HR Dvein:**
> _You: Avagaluku Yenna na suriya om avagalum varanum_
Crt dhn polla

[8:48 AM] **You:**
> _Aruna HR Dvein: 9.30 to 1clk vara dhn office ah_
🥳

[8:53 AM] **Aruna HR Dvein:** Loosu

[8:53 AM] **Aruna HR Dvein:** Unta kekuran

[8:53 AM] **Aruna HR Dvein:** Apdthan eh mean panirukanganu soli

[8:53 AM] **You:** Ama ama 1 clock varakum tha

[8:55 AM] **You:** Avaga solurathu kocham confusion ah eruku

[8:55 AM] **You:** 🙄

[8:56 AM] **You:** 9.30 to 1 office evening tea class yelam cancel

[8:56 AM] **You:** But avaga type panniruga word apdi meaning illa 9.30 to 1 jaya sri function nu eruku

[8:58 AM] **Aruna HR Dvein:** Apdiya sollura

[8:59 AM] **Aruna HR Dvein:** Navin ta kekalam iru

[8:59 AM] **You:**
> _Aruna HR Dvein: Navin ta kekalam iru_
Ketan

[8:59 AM] **Aruna HR Dvein:**
> _You: Ketan_
Ennavam

[8:59 AM] **You:**
> _Aruna HR Dvein: Ennavam_
9.30 to 1 tha office am

[9:00 AM] **You:** 1 clock v2 ku poe kalam

[9:06 AM] **Aruna HR Dvein:** [Voice message]

[9:09 AM] **You:** Okay

[10:02 AM] **Aruna HR Dvein:** apo avanga rendu per uh me vara matangala ?

[10:02 AM] **You:**
> _Aruna HR Dvein: apo avanga rendu per uh me vara matangala ?_
Mataga

[10:02 AM] **You:** 😂

[10:02 AM] **You:** Jolly ah erukatum avagalachum

[10:03 AM] **You:** Penati sasi

[10:03 AM] **You:** Brightness low

[10:04 AM] **Aruna HR Dvein:**
> _You: Penati sasi_
Patgan

[10:04 AM] **Aruna HR Dvein:** Pathan

[10:04 AM] **You:** Hmm

[10:04 AM] **Aruna HR Dvein:**
> _You: Jolly ah erukatum avagalachum_
Enga amma la asingama ketanga itha sona ah apo

[10:04 AM] **You:**
> _Aruna HR Dvein: Enga amma la asingama ketanga itha sona ah apo_
Onaku tha epdi jolly ah sutha alu illa pavam avagaluku eruku avagalachum jolly ah erukatum.

[10:05 AM] **Aruna HR Dvein:**
> _You: Onaku tha epdi jolly ah sutha alu illa pavam avagaluku eruku avagalachum jolly ah erukatum._
Suthurathu perusu lla da arivu vendam ah avan thmbi chinna paiyan avan

[10:05 AM] **Aruna HR Dvein:** Yen mrge panikitu kudathan husband oda sutham

[10:05 AM] **Aruna HR Dvein:** Ipo enna avasaram

[10:06 AM] **You:**
> _Aruna HR Dvein: Suthurathu perusu lla da arivu vendam ah avan thmbi chinna paiyan avan_
Kaadaluku age illa🥲

[10:08 AM] **Aruna HR Dvein:**
> _You: Kaadaluku age illa🥲_
Karumooo

[10:08 AM] **Aruna HR Dvein:** Asingama iruku ninaichalae

[10:08 AM] **Aruna HR Dvein:** Avan azhaga kuda lla avanum Avan moonjiyu

[10:34 AM] **Aruna HR Dvein:** selva unaiya kuptan la apo erumamadu pathuchi unaiyu avanaiyum

[10:35 AM] **You:**
> _Aruna HR Dvein: selva unaiya kuptan la apo erumamadu pathuchi unaiyu avanaiyum_
Apdiya pathutu pokuthu

[10:35 AM] **You:** Salary potaga pola selvamani ku

[10:36 AM] **Aruna HR Dvein:** Torture panura my load

[10:37 AM] **You:** 🤣

[10:37 AM] **You:** Navin selvamani ku salary potaga

[10:38 AM] **You:** Ennum yenaku varala

[10:38 AM] **Aruna HR Dvein:**
> _You: Navin selvamani ku salary potaga_
Spr

[10:38 AM] **Aruna HR Dvein:**
> _You: Ennum yenaku varala_
Unaku enaku same ah poduvanga

[10:39 AM] **You:** [Document] data analyst 1-Month_Internship_Syllabus.xlsx

[10:39 AM] **You:**
> _Aruna HR Dvein: Unaku enaku same ah poduvanga_
Pg ku ennum kutukala nanu

[10:43 AM] **Aruna HR Dvein:**
> _You: Pg ku ennum kutukala nanu_
Kadupa iruku idhula oru company ah nu

[10:44 AM] **You:**
> _Aruna HR Dvein: Kadupa iruku idhula oru company ah nu_
🫩

[10:44 AM] **You:** Namaku yeppo varumo

[10:44 AM] **Aruna HR Dvein:** ennaku work pakkave interest pogiduchi da

[10:45 AM] **You:**
> _Aruna HR Dvein: ebaky work pakkave interest pogiduchi da_
Rompa sangatama eruku

[10:45 AM] **Aruna HR Dvein:**
> _You: Rompa sangatama eruku_
seri azhugatha

[10:45 AM] **Aruna HR Dvein:** sidhhar ku potangala

[10:45 AM] **Aruna HR Dvein:** avan dhn eh ketutae irunthan

[10:45 AM] **Aruna HR Dvein:** intha erumai ku ellaru potangala?

[10:46 AM] **You:**
> _Aruna HR Dvein: intha erumai ku ellaru potangala?_
Selvamani navin ku matum tha na ketan

[10:46 AM] **Aruna HR Dvein:** okie da

[10:46 AM] **You:** Vera yarukachum ketan mam kita soliruvanuga

[10:46 AM] **You:** Laptop la mutu pannuga notified ah

[10:46 AM] **Aruna HR Dvein:**
> _You: Vera yarukachum ketan mam kita soliruvanuga_
Ik😅

[10:46 AM] **Aruna HR Dvein:**
> _You: Laptop la mutu pannuga notified ah_
puriyala

[10:46 AM] **You:** Rompa kaistama eruku

[10:47 AM] **Aruna HR Dvein:**
> _You: Rompa kaistama eruku_
ada chi vidu

[10:47 AM] **You:**
> _Aruna HR Dvein: puriyala_
Laptop la notification off pannuga

[10:47 AM] **Aruna HR Dvein:** panitan da

[10:47 AM] **You:**
> _Aruna HR Dvein: ada chi vidu_
Waste la eppo work oakurathu

[10:47 AM] **Aruna HR Dvein:** sound matu dhn varum notofications off la iruku

[10:47 AM] **You:** Nama true company la work paakala

[10:47 AM] **You:**
> _Aruna HR Dvein: sound matu dhn varum notofications off la iruku_
Hmm ok

[10:48 AM] **Aruna HR Dvein:**
> _You: Nama true company la work paakala_
ama dhn nan eh v2ku pogalam ah nu yosikuren

[10:48 AM] **You:**
> _Aruna HR Dvein: ama dhn nan eh v2ku pogalam ah nu yosikuren_
Mutiyala

[10:48 AM] **You:** I think yelarukum poturupaga

[10:49 AM] **Aruna HR Dvein:**
> _You: I think yelarukum poturupaga_
Ama ama

[10:49 AM] **You:** Ada ponga da putikava illa

[10:50 AM] **You:** Navin selvamani kum full ah potala

[10:51 AM] **Aruna HR Dvein:** Evlo poturukanga?

[11:00 AM] **You:** [Document] DATA ANALYST.pdf

[11:02 AM] **You:** [Document] MUNIYAPPAN _RESUME.pdf

[11:11 AM] **Aruna HR Dvein:**
> _Aruna HR Dvein: Evlo poturukanga?_
..

[11:11 AM] **You:** 15k

[11:11 AM] **Aruna HR Dvein:** Enna sollura

[11:11 AM] **You:** Ama

[11:11 AM] **Aruna HR Dvein:** Apo remaining

[11:11 AM] **You:** Evening poturanu songalam

[11:11 AM] **You:** Nala potuvaga

[11:11 AM] **You:** 😂

[11:12 AM] **Aruna HR Dvein:**
> _You: Evening poturanu songalam_
Ohh

[11:12 AM] **Aruna HR Dvein:**
> _You: Nala potuvaga_
Yen poda matangala?

[11:12 AM] **You:**
> _Aruna HR Dvein: Yen poda matangala?_
Vaipa illa

[11:12 AM] **Aruna HR Dvein:**
> _You: Vaipa illa_
Avanungaluku 15k na

[11:12 AM] **Aruna HR Dvein:** Apo namaku

[11:12 AM] **You:** Namaku potathuku aprom tha potuvaga

[11:12 AM] **You:**
> _Aruna HR Dvein: Apo namaku_
2k

[11:12 AM] **Aruna HR Dvein:** I mean enakula evlo varum thrla vera

[11:12 AM] **Aruna HR Dvein:**
> _You: 2k_
🤪🤣

[11:12 AM] **Aruna HR Dvein:**
> _You: Namaku potathuku aprom tha potuvaga_
Haan irukalam

[11:12 AM] **You:** 😂paani Puri sapta tha intha amount

[11:12 AM] **You:** 2k

[11:13 AM] **Aruna HR Dvein:** 🤣😂

[11:13 AM] **Aruna HR Dvein:** Yen da ne vera

[11:14 AM] **Aruna HR Dvein:** Oru month next month pakuvan llai mudiyalana kelambiduvan

[11:17 AM] **You:**
> _Aruna HR Dvein: Oru month next month pakuvan llai mudiyalana kelambiduvan_
Next month company erukuma?

[11:17 AM] **You:** 😂

[11:18 AM] **Aruna HR Dvein:**
> _You: Next month company erukuma?_
Karumoonda

[11:18 AM] **Aruna HR Dvein:** Tension agudhu

[11:20 AM] **You:** Oi

[11:20 AM] **You:** Unmya onnu kekura series ah answer pannu

[11:20 AM] **Aruna HR Dvein:**
> _You: Unmya onnu kekura series ah answer pannu_
Sollu

[11:21 AM] **You:** Ni business pananum nu aasa patura thana

[11:21 AM] **You:** ?

[11:21 AM] **Aruna HR Dvein:**
> _You: Ni business pananum nu aasa patura thana_
Yes

[11:21 AM] **You:** Appo na yennota company ah nala run pannura nala profit yetuthutu unkita proff katuna investment partner ah varuviya

[11:22 AM] **Aruna HR Dvein:** Plans iruku neriyave investment crt ah vantha pananu after akka mrge aprm dhn polla apodhn appa free agiduvaga adhan

[11:22 AM] **Aruna HR Dvein:**
> _You: Appo na yennota company ah nala run pannura nala profit yetuthutu unkita proff katuna investment partner ah varuviya_
Yeah sure

[11:22 AM] **You:**
> _Aruna HR Dvein: Yeah sure_
Na ethu veliyatuku kekala unmya tha ketan nium yeah soliruga

[11:23 AM] **You:** So na nala run pannitu full document send pannura onaku ok na partner ah join pannu

[11:26 AM] **Aruna HR Dvein:** Okiee munik ne first run panu athukulla nanu en life ku root map poturuvan so ne vaa nan pathutu solluren

[11:26 AM] **You:**
> _Aruna HR Dvein: Okiee munik ne first run panu athukulla nanu en life ku root map poturuvan so ne vaa nan pathutu solluren_
Kantipa☺️tq

[3:17 PM] **You:**
> _Aruna HR Dvein: Image_
Mass tha

[3:21 PM] **You:** Eppo yethana maniku kelampurathu

[3:21 PM] **You:** Group la solave illa

[10:00 PM] **Aruna HR Dvein:** [Forwarded] [Document] IMG_1392.JPG

[10:00 PM] **Aruna HR Dvein:** [Forwarded] [Document] IMG_1389.JPG

[10:00 PM] **Aruna HR Dvein:** [Forwarded] [Document] IMG_1387.JPG

[10:00 PM] **Aruna HR Dvein:** [Forwarded] [Document] IMG_1391.JPG

[10:00 PM] **Aruna HR Dvein:** [Forwarded] [Document] IMG_1390.JPG

[10:00 PM] **Aruna HR Dvein:** [Forwarded] [Document] IMG_1386.JPG

[10:00 PM] **Aruna HR Dvein:** [Forwarded] [Document] IMG_1388.JPG

[10:28 PM] **You:** Room poyacha

[10:32 PM] **Aruna HR Dvein:** Vantan da

[10:33 PM] **You:** Sari sorry unga friend kita matum ketu solurigala

[10:51 PM] **You:** [album message]

[10:51 PM] **You:** [Image]

[10:51 PM] **You:** [Image]

[11:08 PM] **You:** Sts paaru

[11:16 PM] **You:** Thukitiya

---

## August 21, 2026

[7:45 AM] **Aruna HR Dvein:**
> _You: Sts paaru_
Spr ah iruku da🧿❤️

[7:45 AM] **Aruna HR Dvein:**
> _You: Thukitiya_
Ama Sema body pain

[7:45 AM] **You:** Good morning

[7:46 AM] **You:**
> _Aruna HR Dvein: Ama Sema body pain_
Eppo ok ah

[7:46 AM] **You:** Night mam ku text pannuna

[7:46 AM] **You:** Amma ku ok ah nu

[7:46 AM] **You:** Critical nu soluraga

[7:46 AM] **Aruna HR Dvein:**
> _You: Amma ku ok ah nu_
Adhuku enna sonanga

[7:46 AM] **Aruna HR Dvein:**
> _You: Critical nu soluraga_
Unmaiyava

[7:47 AM] **Aruna HR Dvein:**
> _You: Eppo ok ah_
Ila da Thoongama varudhu

[7:47 AM] **Aruna HR Dvein:** Good morning ✨

[7:47 AM] **You:**
> _Aruna HR Dvein: Unmaiyava_
Ama

[7:47 AM] **You:** Pavama eruku

[7:48 AM] **Aruna HR Dvein:** Unmaiya poiyanu thrla

[7:48 AM] **Aruna HR Dvein:** Vera

[7:49 AM] **You:** Nigalum keluga

[7:49 AM] **You:** Pavama

[7:49 AM] **You:** Ethula yeah poe Sola poraga . But yenaku poe Sola mataganu thonuthu

[7:53 AM] **Aruna HR Dvein:** Nan kekuran iru

[7:53 AM] **You:** Na sonanu kekathiga

[7:53 AM] **You:** Gentral ah

[7:53 AM] **Aruna HR Dvein:**
> _You: Na sonanu kekathiga_
Illa da

[7:53 AM] **Aruna HR Dvein:** Apdthan kekuran

[7:53 AM] **You:**
> _Aruna HR Dvein: Apdthan kekuran_
Yepdi

[7:54 AM] **Aruna HR Dvein:** Vera enna sonanga sahana

[7:54 AM] **Aruna HR Dvein:** Jayasri edhuvu pesucha

[7:54 AM] **Aruna HR Dvein:** ?

[7:54 AM] **You:** Illa

[7:54 AM] **You:** Yethum pesala

[7:54 AM] **Aruna HR Dvein:** Ok da

[7:54 AM] **Aruna HR Dvein:** Aprm yen azhutha ava?

[7:55 AM] **You:** Sir thititaru nu

[8:55 AM] **You:**
> _Aruna HR Dvein: Image_
So

[8:55 AM] **You:** Ni soliru thariyala sir maybe I think bus nu nanakira sir nu soliru

[8:59 AM] **You:** Hmm

[2:47 PM] **Aruna HR Dvein:** SKP ENGINEERING COLLEGE

[2:49 PM] **Aruna HR Dvein:** [Forwarded] [Document] ALPHA COLLEGE_.pdf

[2:49 PM] **Aruna HR Dvein:** Tiruvannamalai ithu ipodhn pesuna

[2:49 PM] **Aruna HR Dvein:** proposal ketanga

[2:49 PM] **You:** Appo project la work panna mutiyathu pola last varakum

[2:49 PM] **Aruna HR Dvein:**
> _You: Appo project la work panna mutiyathu pola last varakum_
maybe

[2:52 PM] **You:**
> _Aruna HR Dvein: maybe_
Hmm

[3:01 PM] **You:** [Document] Data_Science_Workshop_Proposal.pdf

[6:16 PM] **You:** Suriya ku yentha class om illa ah

[6:16 PM] **You:** ?

[6:17 PM] **Aruna HR Dvein:** illadhn ninaikuren

[6:17 PM] **Aruna HR Dvein:** yen kkeura

[6:17 PM] **You:** Data science class vantha Avan kita thaliruga

[6:17 PM] **You:** Eni

[6:18 PM] **Aruna HR Dvein:** ok ok da

[6:18 PM] **You:** Hm

[10:47 PM] **You:** Hello

[10:50 PM] **Aruna HR Dvein:** Sollu munik

[10:51 PM] **You:** How are you

[10:52 PM] **Aruna HR Dvein:** Fine

[10:53 PM] **You:** Saptacha

[10:59 PM] **Aruna HR Dvein:** Hmm

[10:59 PM] **You:** Thirupi keka kuta maturiga🫩

[10:59 PM] **You:** 😓

[11:01 PM] **Aruna HR Dvein:** Ne saptya

[11:01 PM] **You:** Hmm sapta

[11:02 PM] **Aruna HR Dvein:** Ok Gn

[11:03 PM] **You:** Hmm hmm gn gn

---

## August 22, 2026

[10:10 AM] **You:** Course ku Yenna promotion panna songana na panna matan

[10:10 AM] **You:** Mam kita ah stright ah soliruvan

[10:10 AM] **You:** Na panna maatanu

[10:10 AM] **Aruna HR Dvein:**
> _You: Course ku Yenna promotion panna songana na panna matan_
Ur wish dhn munik unaku enna thonudho ne panu pathukalam

[10:11 AM] **You:**
> _Aruna HR Dvein: Ur wish dhn munik unaku enna thonudho ne panu pathukalam_
Hmm ama . Ethanala yavalo Periya problem vanthalum pathukalam

[10:11 AM] **Aruna HR Dvein:** Trm enaku closed one oru anna ku mrge today reception

[10:11 AM] **You:** Na IT company la work paakuranu nanachutu erukaka my family

[10:11 AM] **Aruna HR Dvein:** Nan eh enaiku leave podalam irunthan

[10:11 AM] **You:**
> _Aruna HR Dvein: Nan eh enaiku leave podalam irunthan_
Evening ponga

[10:11 AM] **You:** Nanum varava . Sapatu potuvagala

[10:11 AM] **You:** 😋

[10:11 AM] **Aruna HR Dvein:** Ipo vandhu Sahana ok sonanga nit eh call pana ah suma emergency leave mari kekalam nu aprm avanga mrg eh 6.20 polla call pananga

[10:12 AM] **Aruna HR Dvein:** Nan thoongita

[10:12 AM] **Aruna HR Dvein:** Ipo call pani ok sonanga

[10:12 AM] **You:**
> _Aruna HR Dvein: Ipo call pani ok sonanga_
Apfiya

[10:12 AM] **Aruna HR Dvein:** Nan oru 3'clk mela enaku thonuchi na kelambiduvan

[10:12 AM] **You:** Appo eppo kalampuga

[10:12 AM] **Aruna HR Dvein:**
> _You: Nanum varava . Sapatu potuvagala_
Veg dhn poduvanga da

[10:12 AM] **Aruna HR Dvein:**
> _You: Na IT company la work paakuranu nanachutu erukaka my family_
Vidu 🤧🫂

[10:12 AM] **You:** Eppo kelampuga 11 clock thana unga friends poraga

[10:12 AM] **Aruna HR Dvein:**
> _You: Hmm ama . Ethanala yavalo Periya problem vanthalum pathukalam_
Avlodhn

[10:12 AM] **Aruna HR Dvein:**
> _You: Eppo kelampuga 11 clock thana unga friends poraga_
Ama da 11.30 polla

[10:12 AM] **You:**
> _Aruna HR Dvein: Ama da 11.30 polla_
Eppo kelampuga

[10:13 AM] **Aruna HR Dvein:** [Image]

[10:13 AM] **Aruna HR Dvein:**
> _You: Eppo kelampuga_
Venam pakkalam alandur porathey time agidum

[10:13 AM] **Aruna HR Dvein:** Enaku

[10:13 AM] **You:**
> _Aruna HR Dvein: Venam pakkalam alandur porathey time agidum_
Hay pouralam rapido potu ponga sikiram pouralam

[10:29 AM] **You:** Safe ah ponga

[10:32 AM] **Aruna HR Dvein:** [Voice message]

[11:11 AM] **You:** Yekita ketan Prasanth Yenga poraganu . Na sonna emergency nu poraganu

[11:12 AM] **You:** Rapido yeritu live location send pannuga

[12:25 PM] **Aruna HR Dvein:** Van eritan da

[12:26 PM] **Aruna HR Dvein:** Reach agitan

[12:26 PM] **Aruna HR Dvein:** Things eduthu vaika crt ah irundhuchi

[12:26 PM] **You:**
> _Aruna HR Dvein: Reach agitan_
Okay

[12:27 PM] **You:** Jolly ah poutu vaanga

[12:27 PM] **You:** Enjoy your day

[12:27 PM] **You:** 🙌

[12:27 PM] **Aruna HR Dvein:** Thanks da❤️🫂🥺

[12:27 PM] **Aruna HR Dvein:** Jayasri ah call pana ah solu ipo enaiya

[12:30 PM] **You:**
> _Aruna HR Dvein: Jayasri ah call pana ah solu ipo enaiya_
Okay wait

[12:30 PM] **You:**
> _Aruna HR Dvein: Thanks da❤️🫂🥺_
🫂🩷

[1:15 PM] **Aruna HR Dvein:**
> _You: Okay wait_
Pesitan da

[5:50 PM] **You:** Ora dance ah

[5:50 PM] **You:** 😂🙌

[6:01 PM] **Aruna HR Dvein:**
> _You: Ora dance ah_
Haha ama ama

[6:01 PM] **Aruna HR Dvein:** Epo office over achi

[6:14 PM] **You:**
> _Aruna HR Dvein: Epo office over achi_
Ennum office

[6:14 PM] **You:** 😓

[7:03 PM] **Aruna HR Dvein:** 6.30 varava

[8:50 PM] **You:** Ama

[8:50 PM] **You:** [Sticker]

[9:18 PM] **You:** Saptiya

[9:18 PM] **You:** Yenga stay

[9:19 PM] **You:** Safe ah stay pannura place?

[10:20 PM] **Aruna HR Dvein:**
> _You: Safe ah stay pannura place?_
Ama ama da

[10:21 PM] **Aruna HR Dvein:**
> _You: Saptiya_
Saptan eh

[10:21 PM] **Aruna HR Dvein:** [Video] Inga dhn iruken

[10:21 PM] **Aruna HR Dvein:** Ne saptya

[10:21 PM] **Aruna HR Dvein:** [unknown message]

[10:21 PM] **You:** Mutuchutu call pannu

[10:40 PM] **You:** Night stay Yenga ?

[10:40 PM] **You:** Ponugalam vanthurugakala

[10:40 PM] **You:** ?

[10:41 PM] **Aruna HR Dvein:** Ama da 6gurls 5boys

[10:41 PM] **You:** Hmm appo ok

[10:41 PM] **You:** Safe ah eru ok ah

[10:41 PM] **You:** Nala enjoy pannu

[10:44 PM] **You:**
> _Aruna HR Dvein: Image_
Next unakutha

[10:44 PM] **You:** 😂

[10:45 PM] **You:** Today yetutha photo anupu

[10:51 PM] **Aruna HR Dvein:**
> _You: Today yetutha photo anupu_
En ph la illa enaku send panathu send pnra

[10:51 PM] **Aruna HR Dvein:**
> _You: Next unakutha_
Hmkum enga akka iruka enaku

[10:52 PM] **You:**
> _Aruna HR Dvein: Hmkum enga akka iruka enaku_
Hmm

[10:52 PM] **You:** Payathuta erutha

[10:52 PM] **Aruna HR Dvein:**
> _You: Payathuta erutha_
Puriyala

[10:52 PM] **You:** Yepdi night stay panna poriyo ponuga kuta erukakala illa ah nu thadiyala

[10:52 PM] **You:** Atha

[10:53 PM] **Aruna HR Dvein:** [Voice message]

[10:53 PM] **You:**
> _Aruna HR Dvein: Puriyala_
Payathutu eruthan

[10:53 PM] **Aruna HR Dvein:**
> _You: Yepdi night stay panna poriyo ponuga kuta erukakala illa ah nu thadiyala_
Puriyala

[10:53 PM] **You:**
> _Aruna HR Dvein: Puriyala_
Ni night Yenga stay pannuva , o kuta ponuga erukakala illa yo nu payathutu eruthan

[10:55 PM] **Aruna HR Dvein:**
> _You: Ni night Yenga stay pannuva , o kuta ponuga erukakala illa yo nu payathutu eruthan_
Illa da girls irukanga

[10:55 PM] **Aruna HR Dvein:** Ana girls eh drinks Pananga da van la pora apo

[10:55 PM] **You:**
> _Aruna HR Dvein: Illa da girls irukanga_
🤗hmm appo ok

[10:55 PM] **You:**
> _Aruna HR Dvein: Ana girls eh drinks Pananga da van la pora apo_
O kuta vanthavgala?

[10:55 PM] **Aruna HR Dvein:** Boys uh drink pananga

[10:55 PM] **Aruna HR Dvein:**
> _You: O kuta vanthavgala?_
Ama

[10:56 PM] **You:** Hay

[10:56 PM] **You:** Avaga yengaum poraga nu nium pokatha

[10:56 PM] **You:** Ok ah

[10:56 PM] **Aruna HR Dvein:** Enaku venum ah nu ketanga nan face ah thirupikitan

[10:56 PM] **You:** Stay room ah ?

[10:56 PM] **Aruna HR Dvein:**
> _You: Avaga yengaum poraga nu nium pokatha_
Adhulam enaku theryum da

[10:56 PM] **You:**
> _Aruna HR Dvein: Enaku venum ah nu ketanga nan face ah thirupikitan_
Hmm

[10:56 PM] **Aruna HR Dvein:** Nan adhula pana ah matan pudikathu

[10:56 PM] **Aruna HR Dvein:**
> _You: Stay room ah ?_
Ama da

[10:56 PM] **You:**
> _Aruna HR Dvein: Ama da_
Hmm okay safe ah eru

[10:59 PM] **You:**
> _You: Hmm okay safe ah eru_
Anga pona Inga pona avaga kuta pona nu pogatha

[10:59 PM] **You:** Unaku purium nu nampura

[10:59 PM] **Aruna HR Dvein:**
> _You: Anga pona Inga pona avaga kuta pona nu pogatha_
Kandipa da

[11:00 PM] **You:** Hmm ok safe ah eru . Fresh up akitu thuku morning kuptu

[11:11 PM] **Aruna HR Dvein:**
> _You: Hmm ok safe ah eru . Fresh up akitu thuku morning kuptu_
Ok da sure

[11:12 PM] **You:** ☺️

[11:15 PM] **You:** But yenaku kocham payama eruku

[11:15 PM] **You:** Sorry

[11:17 PM] **Aruna HR Dvein:**
> _You: But yenaku kocham payama eruku_
En da

[11:17 PM] **Aruna HR Dvein:** Nan safe ah dhn da iruken

[11:17 PM] **Aruna HR Dvein:** No worry

[11:19 PM] **You:** Hm I trust for you 🫂

[11:20 PM] **You:** 🫂

[11:25 PM] **Aruna HR Dvein:** 🫂🫂🫂🫂

[11:26 PM] **You:** 🫂

[11:51 PM] **You:** Room poutiya

---

## August 23, 2026

[8:19 AM] **You:** Oiii

[8:28 AM] **Aruna HR Dvein:** Solu da

[8:28 AM] **Aruna HR Dvein:** Ipodhn ready agitu irukom

[8:28 AM] **You:** Hmm ok

[8:28 AM] **You:** Saptu vaaga

[8:29 AM] **Aruna HR Dvein:**
> _You: Saptu vaaga_
Ama ama poganum pasikudhu enaku

[8:35 AM] **You:** 😂

[9:24 AM] **Aruna HR Dvein:** Haiya

[9:26 AM] **You:** Peah😂

[2:00 PM] **You:** Kelampiyacha

[2:17 PM] **Aruna HR Dvein:** Kelambitom da sapda porom

[5:36 PM] **You:** 😂

[9:27 PM] **You:** Yenga

[9:27 PM] **You:** Vanthacha

[10:54 PM] **You:** Hello

---

## August 24, 2026

[6:23 AM] **Aruna HR Dvein:** Hi da

[6:24 AM] **Aruna HR Dvein:** Vanthutan 8clk polla  9.30ku  la thoongitan

[8:45 AM] **You:** Hmm ok

[9:10 AM] **Aruna HR Dvein:**
> _You: So yengayachum veliya tour polam apdinu_
Revenue llatha time and avanga amma ku hospital epd ok solluvanga sollu

[9:11 AM] **You:**
> _Aruna HR Dvein: Revenue llatha time and avanga amma ku hospital epd ok solluvanga sollu_
Suriya ok sonna avaga ok soluvaga

[9:11 AM] **You:** Avaga avaga amount tha

[9:12 AM] **Aruna HR Dvein:**
> _You: Suriya ok sonna avaga ok soluvaga_
Hmkum crt dhn

[9:12 AM] **Aruna HR Dvein:** Apona suriya ta dhn plan kekanum

[9:12 AM] **Aruna HR Dvein:** Avan ta oru pecha potutu aprm ah dhn move pananum

[9:12 AM] **Aruna HR Dvein:** Mam ta pesi pakkalam ah nu soli

[9:12 AM] **You:**
> _Aruna HR Dvein: Avan ta oru pecha potutu aprm ah dhn move pananum_
Correct

[9:12 AM] **You:** Panalan

[9:12 AM] **Aruna HR Dvein:** Office vantan

[9:13 AM] **Aruna HR Dvein:** Sasi nan 2 intern matu dhn irukom

[9:13 AM] **Aruna HR Dvein:**
> _You: Panalan_
Ama ama

[9:13 AM] **You:**
> _Aruna HR Dvein: Office vantan_
Athukuliya. Yenna work enarathula office perukura work ah😂😂😂

[9:13 AM] **Aruna HR Dvein:**
> _You: Athukuliya. Yenna work enarathula office perukura work ah😂😂😂_
Certificate send pananu silla per ku adhan

[9:13 AM] **Aruna HR Dvein:**
> _You: Athukuliya. Yenna work enarathula office perukura work ah😂😂😂_
Ne dhn nit duty pakkurala aprm edhuku

[9:25 AM] **You:**
> _Aruna HR Dvein: Certificate send pananu silla per ku adhan_
Hmm

[9:25 AM] **You:**
> _Aruna HR Dvein: Ne dhn nit duty pakkurala aprm edhuku_
Ama na night duty la floor thotakiran😂😂😂

[5:26 PM] **You:** Yenna look😂

[5:26 PM] **You:** Yeruma maatu pathucha

[5:26 PM] **You:** 😂

[5:27 PM] **Aruna HR Dvein:**
> _You: Yeruma maatu pathucha_
Pathan

[5:27 PM] **You:** Alaka erukan la nanu atha pathurupan avan

[5:27 PM] **You:** 😂

[5:27 PM] **Aruna HR Dvein:**
> _You: Alaka erukan la nanu atha pathurupan avan_
Ama amaqa

[6:29 PM] **Aruna HR Dvein:** Ena del pana ah

[6:29 PM] **You:** Stricker

[6:29 PM] **You:** [Sticker]

[6:30 PM] **You:** Ethu

[6:30 PM] **You:** 🤭

[6:30 PM] **Aruna HR Dvein:** Ohh

[6:30 PM] **You:** Ama

[6:43 PM] **You:** Navin kuta pasurathu illa ah

[6:43 PM] **You:** 🙄

[6:48 PM] **Aruna HR Dvein:** Yaru enkuda pesula

[6:56 PM] **You:**
> _Aruna HR Dvein: Yaru enkuda pesula_
🙄

[6:56 PM] **You:** Avan pesalanu ni pesalaya

[7:06 PM] **Aruna HR Dvein:** Nan Saturday pora apo kuda solitu dhn pona venda verupa dhn thalai atunan Saturday vantha apo kuda avan pesula pora apo nan solitu dhn pogunan

[7:24 PM] **You:**
> _Aruna HR Dvein: Nan Saturday pora apo kuda solitu dhn pona venda verupa dhn thalai atunan Saturday vantha apo kuda avan pesula pora apo nan solitu dhn pogunan_
Yeah ni pesa vetiyathu thana

[7:24 PM] **You:** Today

[7:29 PM] **Aruna HR Dvein:** Intha qstn ah apdiye ne poitu avan ta kekalam la

[7:29 PM] **Aruna HR Dvein:** Yen enta vara

[7:31 PM] **You:**
> _Aruna HR Dvein: Intha qstn ah apdiye ne poitu avan ta kekalam la_
Kekuran Avan kitaum tha kepan

[7:31 PM] **You:** Yentha problem on illa thiter nu 2 perum pesama erutha Yenna artham

[7:31 PM] **You:** Yenaka jaya sri soli tha tharium

[7:31 PM] **You:** Niga 2 perum pesalanu

[7:32 PM] **Aruna HR Dvein:** Okiee

[7:32 PM] **You:** Hmm rest yetu po . Yesterday dance aati tired ah erupa

[7:32 PM] **You:** 😂

[7:32 PM] **Aruna HR Dvein:** Mm

[7:32 PM] **You:** Shoe vaaka pokalaya

[7:33 PM] **Aruna HR Dvein:** Illa

[7:33 PM] **You:** Hmm

[7:49 PM] **You:** Salary varuma

[7:50 PM] **You:** 😔

[7:50 PM] **You:** Yethuma Sola maturaga

---

## August 25, 2026

[10:00 AM] **Aruna HR Dvein:** intha month eh over agitu inu ennathan panuranganu therla pooo

[10:01 AM] **Aruna HR Dvein:** munik enaku oru help arsal kita neeye ketu vaangithaa da anaiku ponom la 73 rupees bus ku enkitayae savings suthama lla enimel dhn v2la kekanum nan ehhh

[10:01 AM] **Aruna HR Dvein:** avanga already v2ku vara soluranga vera

[10:23 AM] **You:**
> _Aruna HR Dvein: munik enaku oru help arsal kita neeye ketu vaangithaa da anaiku ponom la 73 rupees bus ku enkitayae savings suthama lla enimel dhn v2la kekanum nan ehhh_
Okay na ketu vaaki tharan

[10:23 AM] **You:**
> _Aruna HR Dvein: avanga already v2ku vara soluranga vera_
Unga v2 la ah

[10:27 AM] **Aruna HR Dvein:**
> _You: Unga v2 la ah_
Yes

[10:27 AM] **You:** Yenga v2 la om atha tha

[10:27 AM] **Aruna HR Dvein:** Inga nadakurathu elame solitan work place llaiyu set agala edhuvu elame sonan personal ah nan enna affect agiruken nu solitu

[10:27 AM] **Aruna HR Dvein:** So vara sonanga

[10:28 AM] **You:**
> _Aruna HR Dvein: Inga nadakurathu elame solitan work place llaiyu set agala edhuvu elame sonan personal ah nan enna affect agiruken nu solitu_
Hay loosu

[10:28 AM] **You:** Ethalam solatha

[10:28 AM] **You:** Aprom unna work ah veta mataga

[10:28 AM] **Aruna HR Dvein:** Illa enakunu family matudhn irukanga kepanga enoda sadness aah avanga kita dhn share panuvan

[10:29 AM] **Aruna HR Dvein:** So sonan vaaa nu sonanga

[10:29 AM] **Aruna HR Dvein:**
> _You: Aprom unna work ah veta mataga_
Illa I have a lots off plans in my mind so no issues

[10:29 AM] **You:** Avaga life la nariya etha mathiri pathurupaga avagaluku ethu rompa simple aana retion ah tharium. Ethuka eva eruka matura ennum periya work eva nala panna mutiyathunu nanapaga

[10:30 AM] **You:**
> _Aruna HR Dvein: Illa I have a lots off plans in my mind so no issues_
Okay good but careful move for your life

[10:31 AM] **Aruna HR Dvein:**
> _You: Avaga life la nariya etha mathiri pathurupaga avagaluku ethu rompa simple aana retion ah tharium. Ethuka eva eruka matura ennum periya work eva nala panna mutiyathunu nanapaga_
Apdlam lla munik personal ah nan inga enna face panura office and even frnds circle la nu dhn sonaah enaiya avanga edhuvu ninaika matanga solla matanga

[10:32 AM] **Aruna HR Dvein:**
> _You: Okay good but careful move for your life_
Yeah adhan yosikuren enna panalam nu soli

[10:32 AM] **You:**
> _Aruna HR Dvein: Apdlam lla munik personal ah nan inga enna face panura office and even frnds circle la nu dhn sonaah enaiya avanga edhuvu ninaika matanga solla matanga_
Okay

[10:34 AM] **You:**
> _Aruna HR Dvein: Yeah adhan yosikuren enna panalam nu soli_
Okay take time but your decision not change only for your. Your decision change in your generation.

[10:34 AM] **Aruna HR Dvein:**
> _You: Okay take time but your decision not change only for your. Your decision change in your generation._
Ik munik

[10:34 AM] **You:** 🔥

[10:42 AM] **Aruna HR Dvein:** 😇

[11:03 AM] **You:** 🩷

[2:04 PM] **You:** Oii

[2:20 PM] **Aruna HR Dvein:** Hmm

[2:24 PM] **You:** 1 thethi salary poturagalam

[2:24 PM] **You:** 2 month ku sethu

[2:24 PM] **Aruna HR Dvein:** Haan

[2:24 PM] **You:** Hmm

[7:07 PM] **You:** Yenna madam ku happy ah

[7:07 PM] **You:** 🫂

[7:08 PM] **You:** Unota kanna pathan avalo happy avaga sonathum🫂🩷

[7:08 PM] **Aruna HR Dvein:**
> _You: Unota kanna pathan avalo happy avaga sonathum🫂🩷_
Ama da evlo kasta padura theryum ah inga irundhu

[7:09 PM] **You:** Ama🫂

[7:09 PM] **Aruna HR Dvein:** Open ah solla pona enakula epd kasta patu meeting la pechi vaanganum nu avasiyam eh lla ana enoda self growth dhn vaaiya mooditu irunthan

[7:09 PM] **Aruna HR Dvein:**
> _You: Ama🫂_
🥺🥺🥺

[7:09 PM] **You:** Yenatha appa amma namaku vasathiya eruthalum namala oru vesayathuku effort potu athula success ketikurathutha unmyana feel

[7:09 PM] **You:** 🫂

[7:09 PM] **You:** Today unota kannula atha pathan

[7:09 PM] **You:** 🫂

[7:09 PM] **Aruna HR Dvein:**
> _You: Yenatha appa amma namaku vasathiya eruthalum namala oru vesayathuku effort potu athula success ketikurathutha unmyana feel_
Ama la🥺🥺

[7:10 PM] **Aruna HR Dvein:**
> _You: Today unota kannula atha pathan_
🥺🥺🥺🧎🏻‍♀️🧎🏻‍♀️🫂🫂😭

[7:10 PM] **You:** Happy ah eru unota hard work ku ennum nala success varum

[7:10 PM] **Aruna HR Dvein:** Ok agiduchina inum happy da🥺🫂

[7:10 PM] **Aruna HR Dvein:** Ana sahana ethacham paniduvalo nu dhn bayam

[7:10 PM] **You:** But unota hard work ah unakaka potu unota business ku potu

[7:10 PM] **You:** Ethu yenatha eruthalum atuthavaga company thana

[7:11 PM] **Aruna HR Dvein:** [Voice message]

[7:11 PM] **You:**
> _Aruna HR Dvein: Ana sahana ethacham paniduvalo nu dhn bayam_
Yathachum pannuna po di mairu nu thuki potu pouru

[7:11 PM] **Aruna HR Dvein:**
> _You: Happy ah eru unota hard work ku ennum nala success varum_
🥺🥺😭🫂kandipa da

[7:11 PM] **Aruna HR Dvein:**
> _You: Ethu yenatha eruthalum atuthavaga company thana_
Ama da

[7:11 PM] **Aruna HR Dvein:**
> _You: Yathachum pannuna po di mairu nu thuki potu pouru_
Ama adhan panuvan nanu

[7:12 PM] **Aruna HR Dvein:** [Voice message]

[7:12 PM] **You:**
> _Aruna HR Dvein: Voice message_
Na sahana ah erutha Yenna soluva thariuma 1500 yengaluku 500 ungaluku nu soluvan

[7:12 PM] **Aruna HR Dvein:**
> _You: Na sahana ah erutha Yenna soluva thariuma 1500 yengaluku 500 ungaluku nu soluvan_
Ama pa crt ah irukum theryum ah

[7:12 PM] **Aruna HR Dvein:** Idhuku avlo asaai

[7:12 PM] **You:** Onnu solava

[7:12 PM] **Aruna HR Dvein:** Amt mela

[7:12 PM] **Aruna HR Dvein:**
> _You: Onnu solava_
Yes da

[7:13 PM] **You:** Epdi hard work pannura aruna ah rompa putuchuruku🫂

[7:13 PM] **You:** Epdiya eru

[7:13 PM] **Aruna HR Dvein:**
> _You: Yelarukum ok ah_
Nooooooo

[7:13 PM] **Aruna HR Dvein:**
> _You: Epdi hard work pannura aruna ah rompa putuchuruku🫂_
Thanks da🥺🫂🫂

[7:13 PM] **You:**
> _Aruna HR Dvein: Nooooooo_
Vara avalotha

[7:13 PM] **Aruna HR Dvein:** Enaikula rmbave stress ah manasu avlo heavy ah irundhuchi 😭😭

[7:13 PM] **Aruna HR Dvein:** Revenue varula v2ku poganum thonuchi ingaiyu yaru pesula so rmba mind fuck achi

[7:13 PM] **Aruna HR Dvein:**
> _You: Epdi hard work pannura aruna ah rompa putuchuruku🫂_
Kandipa irupan🫂

[7:14 PM] **Aruna HR Dvein:**
> _You: Vara avalotha_
Nope noway

[7:14 PM] **You:** Today night happy ah anathum yenaka avalo happy pramiss ah yenaku avalo happy yetho yenaku success ketacha mathiri

[7:14 PM] **You:** 🫂

[7:14 PM] **Aruna HR Dvein:**
> _You: Today night happy ah anathum yenaka avalo happy pramiss ah yenaku avalo happy yetho yenaku success ketacha mathiri_
Yen epd sollura ne😭😭🧎🏻‍♀️

[7:14 PM] **You:**
> _Aruna HR Dvein: Revenue varula v2ku poganum thonuchi ingaiyu yaru pesula so rmba mind fuck achi_
Fuck ah🙄

[7:15 PM] **Aruna HR Dvein:**
> _You: Fuck ah🙄_
Hehehe ama😅😂

[7:15 PM] **You:**
> _Aruna HR Dvein: Yen epd sollura ne😭😭🧎🏻‍♀️_
Avalo efforts poturuka na kanara daily daily pathukitu thana erukan

[7:15 PM] **You:**
> _Aruna HR Dvein: Hehehe ama😅😂_
🤣

[7:16 PM] **Aruna HR Dvein:**
> _You: Avalo efforts poturuka na kanara daily daily pathukitu thana erukan_
Nan yartalam pesuvan theryum ah enakae oru mari irukum pesatha paiyan ta la pesuna enaiku enkuda mba padichan avan kita lam pesunan da🤧

[7:16 PM] **You:** Yenaka yenanu thariyala avalo happy ah eruthuchu ni avalo happy ah erukavom hard work ku ketacha Happy

[7:16 PM] **You:**
> _Aruna HR Dvein: Nan yartalam pesuvan theryum ah enakae oru mari irukum pesatha paiyan ta la pesuna enaiku enkuda mba padichan avan kita lam pesunan da🤧_
🫂

[7:16 PM] **Aruna HR Dvein:**
> _You: Yenaka yenanu thariyala avalo happy ah eruthuchu ni avalo happy ah erukavom hard work ku ketacha Happy_
Thanks da😭epd yaru sonathu lla enaku😭😭😭😭😭😭😭😭😭🫂🫂

[7:17 PM] **You:** But intha success vera yatathula onaku ketachurutha kantipa hug pannirupan🫂 today ah apditha eruthuchu but unota success avagaluku katachuruchi so atha hug panala 😂😂

[7:17 PM] **Aruna HR Dvein:** [Voice message]

[7:17 PM] **You:**
> _Aruna HR Dvein: Thanks da😭epd yaru sonathu lla enaku😭😭😭😭😭😭😭😭😭🫂🫂_
Na yepaum unmya matum tha soluvan .. putuchavagala eruthalum sari putikathavgala eruthalum sari

[7:18 PM] **Aruna HR Dvein:**
> _You: But intha success vera yatathula onaku ketachurutha kantipa hug pannirupan🫂 today ah apditha eruthuchu but unota success avagaluku katachuruchi so atha hug panala 😂😂_
Podangaa loosuuu👊🏻👊🏻👊🏻☺️☺️

[7:18 PM] **Aruna HR Dvein:** [Voice message]

[7:18 PM] **You:**
> _Aruna HR Dvein: Voice message_
First etha success panni nimathiya eru

[7:18 PM] **You:** Aprom workshop pakalam

[7:19 PM] **You:**
> _Aruna HR Dvein: Voice message_
Nama onna okathu yetho panitu eruthom so atha mam kita potu kutuklam nu eruthanuga but nama office vesayama pesuna nala amithiya poutanuga

[7:20 PM] **Aruna HR Dvein:**
> _You: First etha success panni nimathiya eru_
Ama munik🥺

[7:20 PM] **You:** But pls intha efforts ah unota business la potu ni expected pannatha alavo ni pariya yetathuku povan .. na yatho summa soluranu nanakatha unota effort pathutha solu

[7:20 PM] **Aruna HR Dvein:**
> _You: Nama onna okathu yetho panitu eruthom so atha mam kita potu kutuklam nu eruthanuga but nama office vesayama pesuna nala amithiya poutanuga_
[Voice message]

[7:21 PM] **You:**
> _You: But pls intha efforts ah unota business la potu ni expected pannatha alavo ni pariya yetathuku povan .. na yatho summa soluranu nanakatha unota effort pathutha solu_
God yeluthirutha nama 2 perum kuta business partner ah varalan🤷‍♂️

[7:22 PM] **Aruna HR Dvein:**
> _You: But pls intha efforts ah unota business la potu ni expected pannatha alavo ni pariya yetathuku povan .. na yatho summa soluranu nanakatha unota effort pathutha solu_
[Voice message]

[7:22 PM] **Aruna HR Dvein:**
> _You: God yeluthirutha nama 2 perum kuta business partner ah varalan🤷‍♂️_
Yeah sure

[7:23 PM] **Aruna HR Dvein:** Nan kandipa Antha place la iruntha partnership potupan sure ag

[7:23 PM] **Aruna HR Dvein:** Suma la sollala

[7:24 PM] **You:** 🫂

[7:24 PM] **You:** Kaalam pathil solum

[7:24 PM] **You:** Sari today nimathiya thuku tomorrow ni pesu avaga kita

[7:24 PM] **You:** 🫂

[7:27 PM] **Aruna HR Dvein:**
> _You: Kaalam pathil solum_
Kandipa

[7:27 PM] **Aruna HR Dvein:**
> _You: Sari today nimathiya thuku tomorrow ni pesu avaga kita_
🥺🥺🫂🫂ok da

[7:30 PM] **You:** Onnu sonna thita kutathu😂

[7:31 PM] **Aruna HR Dvein:**
> _You: Onnu sonna thita kutathu😂_
Sollu da 🐷

[7:31 PM] **You:**
> _Aruna HR Dvein: Sollu da 🐷_
🤨vera yathachum soliruvan

[7:31 PM] **Aruna HR Dvein:** Seri enna sollu

[7:32 PM] **Aruna HR Dvein:**
> _You: Onnu sonna thita kutathu😂_
.

[7:32 PM] **You:** Epdi hard work pannura aruna ah rompa putuchuruku🫂

[7:32 PM] **Aruna HR Dvein:**
> _You: Epdi hard work pannura aruna ah rompa putuchuruku🫂_
Adhan solitiyae da already

[7:32 PM] **You:** But ennum kocham matum unota kovatha control pannigo

[7:32 PM] **Aruna HR Dvein:** Apo evlo nal thoongita iruntha sollu?

[7:32 PM] **You:** Yarium satunu pasatha

[7:32 PM] **You:** Etha matum mathikitina rompa putikum😍🫂

[7:33 PM] **Aruna HR Dvein:**
> _You: But ennum kocham matum unota kovatha control pannigo_
Enaku enna kovaam solu yen - ah pakkuringa atha thandi evlo pasaam vachiruken nu + ah pakkalam la

[7:33 PM] **You:**
> _Aruna HR Dvein: Apo evlo nal thoongita iruntha sollu?_
Apdi illa eppo tha ni happy mood la eruka atha😂

[7:33 PM] **Aruna HR Dvein:**
> _You: Etha matum mathikitina rompa putikum😍🫂_
Seri change panikuren kandipa

[7:33 PM] **Aruna HR Dvein:** Ok

[7:33 PM] **Aruna HR Dvein:**
> _You: Apdi illa eppo tha ni happy mood la eruka atha😂_
Podanga

[7:33 PM] **You:**
> _Aruna HR Dvein: Enaku enna kovaam solu yen - ah pakkuringa atha thandi evlo pasaam vachiruken nu + ah pakkalam la_
💯

[7:33 PM] **Aruna HR Dvein:** https://youtube.com/shorts/gLUcgodg2u4?si=ZmCO8FpsaciPpmvz

[7:33 PM] **Aruna HR Dvein:** Intha shorts dhn pathutu iruken

[7:34 PM] **You:** Unota pasam purucha nalatha solura. Thitirunu ni kovama pasura atha matum mathiko😍

[7:34 PM] **You:** 🫂

[7:34 PM] **You:**
> _Aruna HR Dvein: https://youtube.com/shorts/gLUcgodg2u4?si=ZmCO8FpsaciPpmvz_
Vaaki kutu nanum varan😂

[7:34 PM] **Aruna HR Dvein:**
> _You: Unota pasam purucha nalatha solura. Thitirunu ni kovama pasura atha matum mathiko😍_
Kandipa change panikuren seriya🫂

[7:34 PM] **Aruna HR Dvein:**
> _You: Vaaki kutu nanum varan😂_
Haha vaa vaa salary podatum

[7:34 PM] **You:** Tea kutika polama 9.30 k

[7:34 PM] **You:**
> _Aruna HR Dvein: Haha vaa vaa salary podatum_
Appo natakathu

[7:34 PM] **You:** 😂

[7:35 PM] **Aruna HR Dvein:**
> _You: Tea kutika polama 9.30 k_
9.30 ah enakae tired ah iruku da nan eh thoongalam iruken en room ponnu kupta nan varula nu solitan

[7:35 PM] **Aruna HR Dvein:** Saturday Sunday ponathey inu tired ah iruku

[7:35 PM] **You:**
> _Aruna HR Dvein: 9.30 ah enakae tired ah iruku da nan eh thoongalam iruken en room ponnu kupta nan varula nu solitan_
Hmm ok

[7:35 PM] **Aruna HR Dvein:** Trm pogalam ah

[7:35 PM] **Aruna HR Dvein:** Sollu

[7:36 PM] **Aruna HR Dvein:**
> _You: Appo natakathu_
Moodu adhulam nadakum

[7:36 PM] **You:**
> _Aruna HR Dvein: Trm pogalam ah_
Tmr madam Yenna mood la erukigalo 🤣 sahana yathum solana ni happy ah varuva illa na avalotha

[7:36 PM] **Aruna HR Dvein:** [Voice message]

[7:36 PM] **Aruna HR Dvein:**
> _You: Tmr madam Yenna mood la erukigalo 🤣 sahana yathum solana ni happy ah varuva illa na avalotha_
[Sticker]

[7:37 PM] **Aruna HR Dvein:** Ithan nadakum😂

[7:37 PM] **You:**
> _Aruna HR Dvein: Sticker_
Mutu mutu

[7:37 PM] **You:** Today happy ah eruthappo yennota kannuku alaka tharucha😍

[7:38 PM] **You:** 😂unmya

[7:38 PM] **Aruna HR Dvein:**
> _You: Today happy ah eruthappo yennota kannuku alaka tharucha😍_
[Voice message]

[7:39 PM] **You:**
> _Aruna HR Dvein: Voice message_
Athu unma tha but yenanu thariyala ni happy ah suthum pothu alaka erutha

[7:39 PM] **You:** 🙈

[7:39 PM] **Aruna HR Dvein:**
> _You: Athu unma tha but yenanu thariyala ni happy ah suthum pothu alaka erutha_
Haiyoodaa

[7:40 PM] **Aruna HR Dvein:** [Voice message]

[7:40 PM] **You:** Work kututhutan

[7:40 PM] **You:** 😂

[7:40 PM] **You:** Ice vachalum onnum natakathu pola

[7:40 PM] **You:** 😂

[7:41 PM] **Aruna HR Dvein:** Nangalam yaru😎😎😎

[7:41 PM] **You:** Sater ah saathu

[7:41 PM] **You:** Full trim panna nala eruka yenaku

[7:42 PM] **You:** ?

[7:45 PM] **You:** Snap it solu

[8:54 PM] **You:** Yenna pannuriga madam

[8:58 PM] **You:** Oii

[8:58 PM] **You:** Unkita onnu katanum

[9:00 PM] **Aruna HR Dvein:**
> _You: Full trim panna nala eruka yenaku_
Haan ama

[9:00 PM] **Aruna HR Dvein:**
> _You: Snap it solu_
I'd ah?

[9:00 PM] **Aruna HR Dvein:**
> _You: Yenna pannuriga madam_
Ipodhn saptan da

[9:00 PM] **Aruna HR Dvein:** Ne saptya

[9:01 PM] **Aruna HR Dvein:**
> _You: Unkita onnu katanum_
Enathu

[9:05 PM] **You:** _You deleted this message_

[9:05 PM] **You:** Paarh

[9:05 PM] **You:** Paaru

[9:07 PM] **You:**
> _Aruna HR Dvein: I'd ah?_
Ama

[9:13 PM] **Aruna HR Dvein:**
> _You: Image_
Unga ala ah?

[9:13 PM] **You:** Ama

[9:13 PM] **You:** 😔

[9:13 PM] **Aruna HR Dvein:** Add me on Snapchat! Username: aruna_vp https://www.snapchat.com/add/aruna_vp?share_id=RnPUS7BUYdk&locale=en-GB

[9:14 PM] **You:** Hmma add akitan

[9:14 PM] **Aruna HR Dvein:**
> _You: 😔_
Cher vidu feel panatha ne🫂nama Kai la enna iruku munik namaku god enna mudichi potu vachirukangalo athu padithan nadakum

[9:14 PM] **You:**
> _Aruna HR Dvein: Cher vidu feel panatha ne🫂nama Kai la enna iruku munik namaku god enna mudichi potu vachirukangalo athu padithan nadakum_
🫂

[9:14 PM] **Aruna HR Dvein:**
> _You: 🫂_
Crt dhn eh

[9:14 PM] **Aruna HR Dvein:** ?

[9:15 PM] **You:** Correct tha🫂

[9:15 PM] **You:** Saturday oluga vaa

[9:15 PM] **You:** Ok ah

[9:17 PM] **Aruna HR Dvein:**
> _You: Saturday oluga vaa_
Haiyoo venam da

[9:17 PM] **Aruna HR Dvein:** Kochikatha Seriously nan vara matan

[9:17 PM] **Aruna HR Dvein:**
> _You: Correct tha🫂_
🫂🫂🫂

[9:18 PM] **You:** Hmm

[9:18 PM] **You:** Trim pannirava

[9:18 PM] **You:** 😂

[9:18 PM] **Aruna HR Dvein:** 😅😅panidu

[9:18 PM] **You:** 😂

[10:10 PM] **You:** Thukiyacha

---

## August 26, 2026

[10:11 AM] **Aruna HR Dvein:** [Image]

[10:11 AM] **Aruna HR Dvein:** Nan sonan la eva epdthan panuvanu soli

[2:40 PM] **You:** Pesunigala

[2:41 PM] **Aruna HR Dvein:** Suriya ta pesuna avanum nambala mari ok sona a

[2:41 PM] **Aruna HR Dvein:** Trm sahana varum ahm afternoon mela

[2:41 PM] **Aruna HR Dvein:** Apo nerula pesunga

[2:41 PM] **Aruna HR Dvein:** Ph na avangaluku puriyathunu sona ah

[2:42 PM] **You:** Hmm suriya sonna ok tha

[2:42 PM] **You:** 😂

[2:42 PM] **Aruna HR Dvein:** Avan ta sona ah avanga alu ok sollum

[2:42 PM] **Aruna HR Dvein:**
> _You: Hmm suriya sonna ok tha_
Exactly💯

[2:42 PM] **You:**
> _Aruna HR Dvein: Avan ta sona ah avanga alu ok sollum_
Ama😂

[2:42 PM] **Aruna HR Dvein:**
> _You: Ama😂_
Adhan silent ah vitutan

[2:42 PM] **You:** Kochuvaga apdi illa suriya athu correct ah varuma

[2:42 PM] **You:**
> _Aruna HR Dvein: Adhan silent ah vitutan_
Hmm ok

[2:43 PM] **Aruna HR Dvein:** Sahana no sonuchina Revenue kondu vantha podhum la nan pathukuren nu solitu antha anna ta nan eh ok soliduvan

[2:43 PM] **You:** Na loan apply panna reject akiruchu😓

[2:43 PM] **You:**
> _Aruna HR Dvein: Sahana no sonuchina Revenue kondu vantha podhum la nan pathukuren nu solitu antha anna ta nan eh ok soliduvan_
Hmm ok

[2:43 PM] **Aruna HR Dvein:**
> _You: Kochuvaga apdi illa suriya athu correct ah varuma_
Puriyala

[2:43 PM] **Aruna HR Dvein:**
> _You: Na loan apply panna reject akiruchu😓_
Yen apx

[2:43 PM] **Aruna HR Dvein:** Apd

[2:43 PM] **You:**
> _Aruna HR Dvein: Puriyala_
Avaga 2 perum konchuvaga nu sonna

[2:43 PM] **You:**
> _Aruna HR Dvein: Yen apx_
Thariyala

[2:45 PM] **You:** Intha dress munatiya potu vanthurukiya illa eppo tha first ah

[2:45 PM] **You:** 🙄

[3:42 PM] **You:** Over ah panuraga

[3:43 PM] **Aruna HR Dvein:** Ik

[3:44 PM] **Aruna HR Dvein:** Enna sona ah

[3:45 PM] **You:** Oru mathiri kelvi kekuraj

[3:45 PM] **You:** Athu ye vanthuchu

[3:45 PM] **You:** Ethu ye epdi eruku

[3:45 PM] **You:** Apdi yeah pannuriga

[3:45 PM] **You:** Epdi yeah pannuriga

[3:46 PM] **Aruna HR Dvein:** Vidu

[3:46 PM] **Aruna HR Dvein:** Avanga avlodhn

[3:46 PM] **Aruna HR Dvein:** Apo enaiyalam enna solluva

[3:46 PM] **Aruna HR Dvein:** Sollu

[3:46 PM] **Aruna HR Dvein:** [Image]

[3:46 PM] **Aruna HR Dvein:**
> _Aruna HR Dvein: Image_
Ithu mari talk varave varathu today varudhu

[3:47 PM] **Aruna HR Dvein:** Suriya va pathuka sollurangana

[3:47 PM] **Aruna HR Dvein:** Enaku puriyala

[3:47 PM] **You:**
> _Aruna HR Dvein: Image_
Kevalama pu*** mathiri pannuraga chi

[3:47 PM] **Aruna HR Dvein:**
> _You: Epdi panatha yelarum povaganu epdi pannuraga_
No issues pogidalam don't worry aprm puduguvanga ivanungala vachi

[3:47 PM] **Aruna HR Dvein:**
> _You: Kevalama pu*** mathiri pannuraga chi_
Vidu vidu

[3:47 PM] **Aruna HR Dvein:** Nan yesterday sonan la epdiyu kuttaiya kolapuvanu soli

[3:48 PM] **Aruna HR Dvein:** Adhan yesterday happy agala nanu epdiyu ok solla matanu ik

[3:48 PM] **Aruna HR Dvein:** Nanu dhn Jun month la 2lks eduthan onume sollala

[3:48 PM] **Aruna HR Dvein:** Ipo ivaluku sollura ava

[3:48 PM] **Aruna HR Dvein:** Sahana kita nan kelichi dhn viduvan pora apo elame soliduvan sir enta ennalam ketarunu

[3:49 PM] **Aruna HR Dvein:** Ipo ava ta kekavu dhn Kai kal ah pudikura sahana

[3:49 PM] **Aruna HR Dvein:** Illana yen epd sollanu solu

[3:49 PM] **You:** But rompa feel pannuvaga

[3:49 PM] **Aruna HR Dvein:** Inga iva ok sollalana nan emc coo ta call pani pesiduvan llaiya paper poturuvan en frnd refer ethacham pana ah kelambiduvan

[3:50 PM] **Aruna HR Dvein:**
> _You: But rompa feel pannuvaga_
Rmbave anupa vaipa paru

[3:50 PM] **You:**
> _Aruna HR Dvein: Inga iva ok sollalana nan emc coo ta call pani pesiduvan llaiya paper poturuvan en frnd refer ethacham pana ah kelambiduvan_
Nagalum atha mind latha erukom

[3:50 PM] **You:**
> _Aruna HR Dvein: Rmbave anupa vaipa paru_
Appo tharium

[3:50 PM] **You:** Rompa heart akuthu

[3:50 PM] **Aruna HR Dvein:**
> _You: Nagalum atha mind latha erukom_
Haan 4 per pogitu jayasri uh pogidum ne venam ah paru

[3:50 PM] **Aruna HR Dvein:**
> _You: Rompa heart akuthu_
Vidu da

[3:50 PM] **Aruna HR Dvein:** Vidu

[3:50 PM] **Aruna HR Dvein:** 🫂🫂

[3:50 PM] **You:**
> _Aruna HR Dvein: Haan 4 per pogitu jayasri uh pogidum ne venam ah paru_
Ama

[3:52 PM] **You:** Pesama evagaluku oposite ah nama start paniralama

[3:52 PM] **Aruna HR Dvein:**
> _You: Pesama evagaluku oposite ah nama start paniralama_
Enanu

[3:53 PM] **Aruna HR Dvein:** Evanga evlo panalu nama kandukama dhn poganum pogidum pakkalam

[3:53 PM] **Aruna HR Dvein:** Reason thedurangapolla

[3:53 PM] **Aruna HR Dvein:** Avanagalae sendoff pana ah

[3:53 PM] **Aruna HR Dvein:** Epd pana ah namalaaae pogiduvom

[3:53 PM] **Aruna HR Dvein:** Nu panuranga

[3:53 PM] **You:**
> _Aruna HR Dvein: Enanu_
Placement training intership antha mathiri

[3:53 PM] **Aruna HR Dvein:**
> _You: Placement training intership antha mathiri_
Yes

[3:53 PM] **You:**
> _Aruna HR Dvein: Avanagalae sendoff pana ah_
💯

[3:53 PM] **You:**
> _Aruna HR Dvein: Epd pana ah namalaaae pogiduvom_
Atha avaga thought

[3:54 PM] **Aruna HR Dvein:**
> _You: Atha avaga thought_
Intha naiyunga munadi nalla vandhu kattanum da💯💯💯

[3:54 PM] **Aruna HR Dvein:** Ivanga Business epdiyu mela varathu

[3:54 PM] **Aruna HR Dvein:** Atha vida neriya mela varanum

[3:54 PM] **You:** Salary kutuka vali pu***** Ilana soliranum namala pouralam

[3:55 PM] **You:** Ni sari na solu atha pathi discussion panalam

[4:12 PM] **You:** Friend ah

[4:13 PM] **Aruna HR Dvein:** Akka da

[4:13 PM] **You:** Okay

[5:11 PM] **Aruna HR Dvein:** munik enaku ethachm idea kudu da suthama oru mari iruku aprm ah cls over agiyu pesu

[6:01 PM] **You:** Hmm Yenna achu

[6:01 PM] **You:** Yenna idea

[6:02 PM] **Aruna HR Dvein:** Epo pogatum nanu

[6:02 PM] **Aruna HR Dvein:** Inga irundhu

[6:02 PM] **Aruna HR Dvein:** Salary vanthatu pogava

[6:02 PM] **You:** Confirm papar pota porigala

[6:03 PM] **Aruna HR Dvein:**
> _You: Confirm papar pota porigala_
Hey yena qstn idhu

[6:03 PM] **Aruna HR Dvein:** Enala mudiyala Ivala oru alu mairunu evlo scene podura

[6:03 PM] **Aruna HR Dvein:** Onu lla inga idhuku evlo scene

[6:05 PM] **You:** Ama yethuku alutha

[6:05 PM] **You:** Yesterday thana sonna

[6:05 PM] **You:** Your hard work nu

[6:06 PM] **You:** Epdi alutha failure matum tha aluvaga

[6:06 PM] **Aruna HR Dvein:**
> _You: Ama yethuku alutha_
Akka oru mari solita enaiya adhan

[6:06 PM] **You:**
> _Aruna HR Dvein: Akka oru mari solita enaiya adhan_
Yenna songa

[6:06 PM] **You:** Success people yepaum ala mataga next Yenna panalam nu think panuvaga

[6:06 PM] **You:** Yenaku ni aluthathu suthama putikala

[6:07 PM] **Aruna HR Dvein:** Suma un office veshiyatha vidu already headache ah iruku Athunga enna epd panuthunganu kathuna office la nadakuratha pathi aprm sahana va pudichi kathuna illana vanthuru

[6:07 PM] **Aruna HR Dvein:** Apd onu iruka venam nu sona ah

[6:07 PM] **Aruna HR Dvein:** Onu llatha naiyungalae evlo scene poduthungalanu keta

[6:08 PM] **Aruna HR Dvein:** Navin selvamani ta soniya Discord la jayasri ah sonatha

[6:08 PM] **You:** Ama

[6:08 PM] **Aruna HR Dvein:**
> _Aruna HR Dvein: Image_
.

[6:08 PM] **You:** Sonna

[6:08 PM] **Aruna HR Dvein:** [Image]

[6:08 PM] **Aruna HR Dvein:**
> _You: Sonna_
Enna sonanga

[6:08 PM] **You:**
> _Aruna HR Dvein: Enna sonanva_
Yeah arunavom thana daily update pannuthu

[6:10 PM] **You:** Atha Mathiri jaya sri yethum revanu yetuthu vanthathuku onnum epdi solala just work pathurukan today nu normal ah update panathku yeah eppo epdi poturugaganu sona

[6:10 PM] **Aruna HR Dvein:** Update ah vida nanu dhn eh Jun month la lam 2lk kondu vanthan apolam Discord la potan apola  edhumey sollala intha naiyunga

[6:11 PM] **You:** Avagalam apdi tha

[6:11 PM] **You:** Eppo new ah yetho yetho pannuraga

[6:11 PM] **Aruna HR Dvein:**
> _You: Atha Mathiri jaya sri yethum revanu yetuthu vanthathuku onnum epdi solala just work pathurukan today nu normal ah update panathku yeah eppo epdi poturugaganu sona_
Ama revenue ku update panala ava day work ah dhn poturuka

[6:11 PM] **Aruna HR Dvein:**
> _You: Eppo new ah yetho yetho pannuraga_
Enanu da

[6:11 PM] **You:** Suriya ah vetu update keka vakiraga

[6:11 PM] **You:**
> _Aruna HR Dvein: Ama revenue ku update panala ava day work ah dhn poturuka_
Ama

[6:11 PM] **Aruna HR Dvein:** Nan pora apo sahana va kandipa kepan

[6:11 PM] **Aruna HR Dvein:** Epdlam iruntha Seriously mela vara matinganu kepan

[6:11 PM] **Aruna HR Dvein:** Business strategy eh thrla ma unaku nu solitu poguvan

[6:12 PM] **Aruna HR Dvein:** Promise ah nadakum paru

[6:12 PM] **You:** Vetam vetu namaku putikalana nama pouralam

[6:12 PM] **You:** Avagala yethum Sola vetam

[6:12 PM] **Aruna HR Dvein:** lap la mess panu ph pakkatha

[6:12 PM] **Aruna HR Dvein:** avanunga pakuvanga dhu matum llama thaniya theriyudhu ne ph pakurathu

[6:12 PM] **You:** Thiternu avagaluku nama solura word puruchu sari pannita avaga pariya ala akiruvaga

[6:13 PM] **Aruna HR Dvein:**
> _You: Avagala yethum Sola vetam_
ama nan la decent ah kelambiduvan

[6:13 PM] **You:**
> _Aruna HR Dvein: avanunga pakuvanga dhu matum llama thaniya theriyudhu ne ph pakurathu_
Tharuchutu pokuthu

[6:13 PM] **You:**
> _Aruna HR Dvein: ama nan la decent ah kelambiduvan_
Ama .

[6:13 PM] **Aruna HR Dvein:**
> _You: Thiternu avagaluku nama solura word puruchu sari pannita avaga pariya ala akiruvaga_
ama ama nama success dhn pesanum

[6:13 PM] **You:** Ama

[6:13 PM] **Aruna HR Dvein:** ava la mela varave vaippu lla ik oru ponna ah evlo iruka kudathu ebhaa

[6:14 PM] **Aruna HR Dvein:** salary vandhuta nan pesiruka ella college llaiyu cancel panitu dhn poguvan

[6:14 PM] **You:** Yepaum brin soluratha ketu panna kutathu. Brin poi solum but manasu apdi illa poi solathu

[6:14 PM] **You:** Na yepaum manasu solura ketutha deccion yetupan

[6:15 PM] **You:** Bad words ah vai la varuthu

[6:15 PM] **You:** Chi

[6:19 PM] **Aruna HR Dvein:**
> _You: Yepaum brin soluratha ketu panna kutathu. Brin poi solum but manasu apdi illa poi solathu_
Enaku manasu dhn solludhu intha atmosphere la enala learn panika mudiyathu growth lla nu pona month eh soliduchi inga podura effort ah enoda real time Business la pota nan mela varuvan learn panipan growth kedaikum nu thonudhu

[6:20 PM] **You:**
> _Aruna HR Dvein: Enaku manasu dhn solludhu intha atmosphere la enala learn panika mudiyathu growth lla nu pona month eh soliduchi inga podura effort ah enoda real time Business la pota nan mela varuvan learn panipan growth kedaikum nu thonudhu_
💯

[6:21 PM] **You:** Yepaum unota manasu soluratha ketina success tha. Mind ah nampatha

[6:21 PM] **You:** Ni kantipa success aava yenaku nampika eruku

[6:21 PM] **You:** Chinna chinna vesayatha mathikitina unota success ah yaralium thatuka mutiyathu

[6:21 PM] **You:** So nampikayota move pannu

[6:21 PM] **Aruna HR Dvein:**
> _You: Yepaum unota manasu soluratha ketina success tha. Mind ah nampatha_
Enaku theryum da

[6:22 PM] **Aruna HR Dvein:**
> _You: So nampikayota move pannu_
Kandipa

[6:22 PM] **Aruna HR Dvein:** Poitu varen sry poren😁🫡

[6:22 PM] **You:**
> _Aruna HR Dvein: Poitu varen sry poren😁🫡_
🥺 happy ah poe . Intha world rompa persu

[6:22 PM] **You:** So freedom ah parathu po unaku putuchatha pannu

[6:22 PM] **You:** 🫂

[6:23 PM] **You:** Next jenmathula nama nala company la onna work panalam 🫂

[6:23 PM] **Aruna HR Dvein:**
> _You: Next jenmathula nama nala company la onna work panalam 🫂_
Kandipa munik🫡🫡

[6:23 PM] **Aruna HR Dvein:**
> _You: So freedom ah parathu po unaku putuchatha pannu_
🫂🫂🫂

[6:24 PM] **Aruna HR Dvein:**
> _You: 🥺 happy ah poe . Intha world rompa persu_
Ama ama IK it's painful nu

[6:24 PM] **You:** Yenga eruthalum Happy ah eru evagala mathiri yarium natathatha

[6:24 PM] **Aruna HR Dvein:** But yaru nan poguna feel pana ah alu lla so nan athoda dhn move panuren ellathaiyum learn panikitu

[6:24 PM] **Aruna HR Dvein:**
> _You: Yenga eruthalum Happy ah eru evagala mathiri yarium natathatha_
Haiyoo uyire ah kuduthu pathupan workers ah

[6:24 PM] **Aruna HR Dvein:** Ne vera

[6:24 PM] **You:**
> _Aruna HR Dvein: But yaru nan poguna feel pana ah alu lla so nan athoda dhn move panuren ellathaiyum learn panikitu_
Apdilam illa nigala etha nanacha Yenna panna mutiuma

[6:25 PM] **You:**
> _Aruna HR Dvein: Haiyoo uyire ah kuduthu pathupan workers ah_
🫂

[6:28 PM] **Aruna HR Dvein:**
> _You: Apdilam illa nigala etha nanacha Yenna panna mutiuma_
Ama apdthan eh inga sollu

[6:28 PM] **You:**
> _Aruna HR Dvein: Ama apdthan eh inga sollu_
Apdialma illa

[6:30 PM] **Aruna HR Dvein:** Apdthan paa

[6:30 PM] **You:** Yanakulam avalo kaistama eruku🫂but open ah pesa mutiyala

[6:30 PM] **You:** Avalotha

[6:30 PM] **You:** 🫂

[6:30 PM] **Aruna HR Dvein:** But nalla Memories ku unga 3per ku rmbave thanks☺️❤️antha grp la irukura dp pto va nan lifelong marakka matan💯🧿

[6:30 PM] **You:**
> _Aruna HR Dvein: But nalla Memories ku unga 3per ku rmbave thanks☺️❤️antha grp la irukura dp pto va nan lifelong marakka matan💯🧿_
Nanum🫂

[6:32 PM] **Aruna HR Dvein:** ☺️☺️

[6:32 PM] **Aruna HR Dvein:**
> _You: Yanakulam avalo kaistama eruku🫂but open ah pesa mutiyala_
Viduraaaaa

[6:33 PM] **You:** Hmm

[6:34 PM] **You:** Room poutu msg pannu

[7:07 PM] **You:** Yesterday happy ah eruthom la

[7:07 PM] **You:** 😔

[7:08 PM] **You:** God ka porukala pola

[7:10 PM] **Aruna HR Dvein:**
> _You: Yesterday happy ah eruthom la_
Ada apdlam lla munik

[7:10 PM] **Aruna HR Dvein:** Edhu nadakanum ohh adhan nadakum

[7:10 PM] **You:** Kaistama eruku

[7:11 PM] **You:** Na Yenga orula depration ah erukunutha Inga vanth

[7:11 PM] **You:** But inga atha veta depression ah eruku

[7:18 PM] **Aruna HR Dvein:** [Image]

[7:18 PM] **Aruna HR Dvein:** [Voice message]

[7:24 PM] **You:**
> _Aruna HR Dvein: Image_
🤣

[7:25 PM] **You:**
> _Aruna HR Dvein: Voice message_
Hmm

[7:25 PM] **You:** Na update panathuku react panirukaka

[7:36 PM] **You:** Oii

[7:36 PM] **You:** Oru help

[7:37 PM] **Aruna HR Dvein:** Sollu

[7:37 PM] **You:** Yarukitayachum loan vaaka mutiuma

[7:37 PM] **You:** Tharuchavaga erukakala

[9:31 PM] **You:** Hello

[9:31 PM] **Aruna HR Dvein:**
> _You: Yarukitayachum loan vaaka mutiuma_
Enaku apd yaraiyu theriyathu munik

[9:32 PM] **Aruna HR Dvein:** Just try venam ah panura frnds ta ketu ok va

[9:32 PM] **You:**
> _Aruna HR Dvein: Just try venam ah panura frnds ta ketu ok va_
Hmm ok

---

## August 27, 2026

[11:08 AM] **You:** Yenna achu ok akirucha intership

[11:08 AM] **You:** ?

[11:09 AM] **Aruna HR Dvein:** Internship ah yesterday pesunangala antha paiyana kekuriya

[11:09 AM] **Aruna HR Dvein:** Sahana ok slitanga nama pota amt ku

[11:09 AM] **Aruna HR Dvein:** Ana antha anna inu call edukala

[11:10 AM] **You:**
> _Aruna HR Dvein: Sahana ok slitanga nama pota amt ku_
Apdiya

[11:10 AM] **You:** Super

[11:11 AM] **Aruna HR Dvein:** V2la enga amma uh vara solitanga salary vanthathum

[11:13 AM] **You:**
> _Aruna HR Dvein: V2la enga amma uh vara solitanga salary vanthathum_
Apdita

[11:14 AM] **You:** Appo intership putuchu kututhutu povigala

[11:14 AM] **You:** Sari antha app ku pasuga

[11:15 AM] **Aruna HR Dvein:**
> _You: Sari antha app ku pasuga_
Ketu sollurem

[11:15 AM] **Aruna HR Dvein:**
> _You: Appo intership putuchu kututhutu povigala_
Nan pogita antha anna ta emc dhn refer panuvan coo number iruku nan pesitu kuduthuruvan

[11:22 AM] **You:**
> _Aruna HR Dvein: Nan pogita antha anna ta emc dhn refer panuvan coo number iruku nan pesitu kuduthuruvan_
Hmm ok

[2:33 PM] **You:** Yenna saptiga

[2:33 PM] **You:** Yethuku orunu otkathurukiga

[2:33 PM] **You:** Nalava illa

[2:34 PM] **Aruna HR Dvein:** work paru pooo

[2:34 PM] **You:**
> _Aruna HR Dvein: work paru pooo_
Ah ah😂 right ra

[3:51 PM] **You:** Yenna madam busy ah ve erukiga

[3:51 PM] **Aruna HR Dvein:**
> _Aruna HR Dvein: work paru pooo_
.

[3:52 PM] **You:** Hay this time is break

[3:52 PM] **You:** 🤷‍♂️

[4:00 PM] **Aruna HR Dvein:** Ok

[5:49 PM] **Aruna HR Dvein:** Intha prasanth uh epd da jadam mari okanthiruka  apdiye enakula suthama mudiyala backpain agudhu,thoongam varudhu suthama mudiyala

[5:49 PM] **Aruna HR Dvein:** Ellaraiyu note panikitae okanthiruka

[5:49 PM] **Aruna HR Dvein:** Thoongamae varatha ivanuku

[5:49 PM] **You:**
> _Aruna HR Dvein: Intha prasanth uh epd da jadam mari okanthiruka  apdiye enakula suthama mudiyala backpain agudhu,thoongam varudhu suthama mudiyala_
Hay Avan yeruma maatu okathukita thukuvan😂

[5:50 PM] **Aruna HR Dvein:** Afternoon ana prasanth,nivash la enaku biscuit kuduthanga

[5:50 PM] **Aruna HR Dvein:**
> _You: Hay Avan yeruma maatu okathukita thukuvan😂_
Loosu mari panuran

[5:50 PM] **Aruna HR Dvein:** Human ah avan

[5:50 PM] **You:**
> _Aruna HR Dvein: Afternoon ana prasanth,nivash la enaku biscuit kuduthanga_
Alaka erukigala atha ice vakiranuga😂

[5:50 PM] **Aruna HR Dvein:**
> _You: Alaka erukigala atha ice vakiranuga😂_
Apdlam lla

[5:50 PM] **You:**
> _Aruna HR Dvein: Human ah avan_
Ava kaatu yeruma

[5:50 PM] **You:**
> _Aruna HR Dvein: Apdlam lla_
Sumatha sonna seen potatha🤣

[5:51 PM] **Aruna HR Dvein:**
> _You: Sumatha sonna seen potatha🤣_
ne sollala nallu nan azhagathan iruken seriya

[5:51 PM] **Aruna HR Dvein:** certificate yaru kuduka venam epovu avanga avangaluku avanga azhagu dhn

[5:52 PM] **You:**
> _Aruna HR Dvein: ne sollala nallu nan azhagathan iruken seriya_
Apdiya atha Prasanth ungalava pakuran pola😂

[5:52 PM] **You:**
> _Aruna HR Dvein: certificate yaru kuduka venam epovu avanga avangaluku avanga azhagu dhn_
Tharium na alakunu🙈

[5:53 PM] **Aruna HR Dvein:**
> _You: Apdiya atha Prasanth ungalava pakuran pola😂_
okiee pakkatum

[5:53 PM] **Aruna HR Dvein:** thmbi dhn eh pathutu pogatum vidu

[5:53 PM] **You:**
> _Aruna HR Dvein: thmbi dhn eh pathutu pogatum vidu_
Avanukunu oru rasana illa paru🤦‍♂️

[5:53 PM] **You:**
> _You: Tharium na alakunu🙈_
Ethuku matum reply varatheeeeeee?????

[5:54 PM] **Aruna HR Dvein:**
> _You: Avanukunu oru rasana illa paru🤦‍♂️_
Avanukacham iruku silla perku la athu kuda lla

[5:54 PM] **You:**
> _Aruna HR Dvein: Avanukacham iruku silla perku la athu kuda lla_
Mutu mutu

[5:54 PM] **You:** Athu yeruma na Human

[5:55 PM] **Aruna HR Dvein:** Unakula kjm acham arivu iruka ah kal vachiruken theriyatha unaku othachitu pora

[5:55 PM] **You:**
> _Aruna HR Dvein: Unakula kjm acham arivu iruka ah kal vachiruken theriyatha unaku othachitu pora_
Venum tha othacha🤨

[5:55 PM] **You:**
> _Aruna HR Dvein: Avanukacham iruku silla perku la athu kuda lla_
Ethu sonathuku🍴

[5:56 PM] **You:** 🔪

[5:56 PM] **Aruna HR Dvein:** en limit enanu eni pakuva

[5:56 PM] **Aruna HR Dvein:** edhuku mela unta irundhu oru mess vanthalu meeting poduvan

[5:58 PM] **You:** Hey

[5:58 PM] **You:** Na veliyatukuthana panna

[5:58 PM] **You:** 🙄

[5:58 PM] **You:** Ethuku yeah epdi pesitu poriga

[5:58 PM] **You:** 🙄

[6:02 PM] **You:** Na  veliyatukutha panna

[6:02 PM] **You:** Ama veliyatuku pana kutathunalum soluga na panala

---

## August 30, 2026

[12:30 AM] **You:** Hiii

[12:31 AM] **You:** Reached ah ni

[12:42 AM] **Aruna HR Dvein:**
> _You: Reached ah ni_
Nan ah?

[12:42 AM] **Aruna HR Dvein:** Na vantan da

[12:42 AM] **Aruna HR Dvein:** Ne

[12:42 AM] **You:**
> _Aruna HR Dvein: Nan ah?_
Illa unga aaya

[12:42 AM] **You:**
> _Aruna HR Dvein: Ne_
Hmm vanthutan eppo tha kukuchutu vantha

[12:42 AM] **Aruna HR Dvein:**
> _You: Hmm vanthutan eppo tha kukuchutu vantha_
Ok ok da

[12:43 AM] **You:** Thank you 🫂

[12:43 AM] **Aruna HR Dvein:**
> _You: Illa unga aaya_
Nan ipodhn da freshup agitu vanthan

[12:43 AM] **Aruna HR Dvein:**
> _You: Thank you 🫂_
Thank you too🫂✨

[12:43 AM] **You:** Today happy ah eruthathuku nigalum tha rompa important person

[12:43 AM] **You:** 🫂

[12:43 AM] **You:** But na anaki orimailatha methucha

[12:43 AM] **You:** Yarum pakuragalanu paathutu tha avalo orimaila othacha

[12:44 AM] **You:** But heart pannirutha sorry 🫂

[12:44 AM] **Aruna HR Dvein:**
> _You: Today happy ah eruthathuku nigalum tha rompa important person_
Really

[12:44 AM] **Aruna HR Dvein:**
> _You: Yarum pakuragalanu paathutu tha avalo orimaila othacha_
Enaku enana antha eruma madu paiyan la Ulla dhn irukan enaiya kaviya mari thappa pesiduvano nu bayam adhn

[12:46 AM] **You:**
> _Aruna HR Dvein: Really_
Pramiss ah

[12:47 AM] **You:**
> _Aruna HR Dvein: Enaku enana antha eruma madu paiyan la Ulla dhn irukan enaiya kaviya mari thappa pesiduvano nu bayam adhn_
Pesuna pesitu poran .. but na avalo loosu lam illa na pathutu atha yarukum thariyatha mathiri serupu kita othach

[12:51 AM] **Aruna HR Dvein:**
> _You: Pesuna pesitu poran .. but na avalo loosu lam illa na pathutu atha yarukum thariyatha mathiri serupu kita othach_
Loosu lla dhn oru ponnu ku character wise bad name la vantha evlo asingam theryum ah adhula unaku sona ah puriyathu da munik adhan enaku tension la Loosu mari nan dhn panitan

[12:51 AM] **Aruna HR Dvein:**
> _You: Pramiss ah_
Thanks da🫂

[12:52 AM] **You:**
> _Aruna HR Dvein: Loosu lla dhn oru ponnu ku character wise bad name la vantha evlo asingam theryum ah adhula unaku sona ah puriyathu da munik adhan enaku tension la Loosu mari nan dhn panitan_
Athalam vetuga

[12:52 AM] **You:** But avalo feel panna yeah black pannura alavo Yenna panitan nanu apdinu

[12:53 AM] **Aruna HR Dvein:**
> _You: But avalo feel panna yeah black pannura alavo Yenna panitan nanu apdinu_
Nan apdthan  loosu dhn kovaam vantha ctrl pana ah mudiyala but change panikuren

[12:53 AM] **Aruna HR Dvein:** Panipan

[12:53 AM] **You:**
> _Aruna HR Dvein: Nan apdthan  loosu dhn kovaam vantha ctrl pana ah mudiyala but change panikuren_
🫂

[12:53 AM] **You:** Thank you

[12:54 AM] **You:** Selvamani sts vachutan

[12:54 AM] **You:** 🤭

[12:54 AM] **You:** 🤣

[12:55 AM] **Aruna HR Dvein:**
> _You: Selvamani sts vachutan_
Enna sollura

[12:56 AM] **You:** Ama

[12:56 AM] **You:** Unota step tha mass

[12:56 AM] **You:** 🤣

[12:57 AM] **Aruna HR Dvein:**
> _You: Unota step tha mass_
Adeii🤪😅

[12:57 AM] **Aruna HR Dvein:** [Voice message]

[12:58 AM] **You:** Ama avanota phone laum yetuthom

[12:58 AM] **Aruna HR Dvein:** Ok da nan send pana ah soliruken

[1:00 AM] **You:** Hmm ok

[9:41 AM] **Aruna HR Dvein:**
> _You: Video_
😍

[9:42 AM] **You:** 😍

[9:44 AM] **Aruna HR Dvein:** [Sticker]

[9:44 AM] **You:** [Sticker]

[8:14 PM] **You:**
> _Aruna HR Dvein: Video_
Yenna unna kaanom🤣

[8:15 PM] **Aruna HR Dvein:**
> _You: Yenna unna kaanom🤣_
Ada ama la

[8:15 PM] **You:** 😂

---

## August 31, 2026

[2:47 PM] **You:** Yenna enaku alaka erukiga

[2:47 PM] **You:** 😂

[3:43 PM] **Aruna HR Dvein:**
> _You: Yenna enaku alaka erukiga_
Poda

[3:49 PM] **You:** Yenna megala mani magala

[3:49 PM] **You:** 😂

[3:50 PM] **Aruna HR Dvein:** [Sticker]

[3:54 PM] **You:** 😂

[4:21 PM] **Aruna HR Dvein:** Pathala unga ayya enta solitu poraru

[4:22 PM] **You:**
> _Aruna HR Dvein: Pathala unga ayya enta solitu poraru_
Ama alaka erukigala atha unga kita yela porupium kututhutu poraru

[4:23 PM] **You:** 🥲

[4:24 PM] **Aruna HR Dvein:**
> _You: Ama alaka erukigala atha unga kita yela porupium kututhutu poraru_
Hmkum

[4:24 PM] **Aruna HR Dvein:**
> _You: 🥲_
Avaru solitu pona unaku yen bro feelings uhh😅

[4:26 PM] **You:**
> _Aruna HR Dvein: Avaru solitu pona unaku yen bro feelings uhh😅_
Possessive 🤣

[4:26 PM] **Aruna HR Dvein:** Kelichaaa

[4:27 PM] **You:**
> _Aruna HR Dvein: Kelichaaa_
🤣

[6:22 PM] **You:** [Document] Dvein_Innovation_My_Sql_Test.pdf

[6:29 PM] **You:** Yenna today alaka erukuga

[6:29 PM] **You:** 😂

---

## September 1, 2026

[9:59 AM] **Aruna HR Dvein:** [Document] en vazhlkai llaiyae enaiku dhn keturukanga ivanga

[10:03 AM] **You:**
> _Aruna HR Dvein: Document: en vazhlkai llaiyae enaiku dhn keturukanga ivanga_
🤣

[10:07 AM] **Aruna HR Dvein:** Yesterday avanga alu ta sollavu dhn epd kekuranga polla

[10:07 AM] **You:**
> _Aruna HR Dvein: Yesterday avanga alu ta sollavu dhn epd kekuranga polla_
🤣

[10:08 AM] **Aruna HR Dvein:** Ivaru emc coo avarta ketan da

[10:08 AM] **Aruna HR Dvein:** Irukam Business Development Executive ku

[10:30 AM] **You:** 🙄

[10:30 AM] **You:** Yenna evalo fast ah eruka

[10:35 AM] **Aruna HR Dvein:**
> _You: Yenna evalo fast ah eruka_
Vera enna pana ah sollura

[10:35 AM] **Aruna HR Dvein:** Openings irukura apove odiranum

[10:35 AM] **Aruna HR Dvein:** Illatha apo pogitu enna pnrathu sollu

[10:35 AM] **Aruna HR Dvein:** Navin ku unaku dhn theryum selva ku nan inu solala ne katikatha seriya

[10:35 AM] **You:** Appo pora mind set ku vanthutiya

[10:35 AM] **You:**
> _Aruna HR Dvein: Navin ku unaku dhn theryum selva ku nan inu solala ne katikatha seriya_
Hmm ok

[10:38 AM] **Aruna HR Dvein:**
> _You: Appo pora mind set ku vanthutiya_
Ama da

[10:38 AM] **Aruna HR Dvein:** Epd target oda enala stress handle pana ah mudiyathu da salary podama epd face pananum ah sollu

[10:42 AM] **You:**
> _Aruna HR Dvein: Epd target oda enala stress handle pana ah mudiyathu da salary podama epd face pananum ah sollu_
Sari okay

[10:42 AM] **You:** Yeppo interview attend panna pora

[11:07 AM] **Aruna HR Dvein:** Thrla

[11:08 AM] **You:** Mass

[11:15 AM] **You:** Vela ilanu summa ninu vetika pakuriga

[11:15 AM] **You:** 😂2 perum

[4:35 PM] **Aruna HR Dvein:** enna black black soli vachi potingala vrooo

[4:37 PM] **You:**
> _Aruna HR Dvein: enna black black soli vachi potingala vrooo_
Ada pavigala

[4:37 PM] **You:** Na Inga erukurathu putikala apdithana😂

[4:37 PM] **You:** Na yennota ala thavira yarium nanachathu illa 😓

[4:38 PM] **Aruna HR Dvein:**
> _You: Na yennota ala thavira yarium nanachathu illa 😓_
Just fun fun

[4:38 PM] **Aruna HR Dvein:**
> _You: Na Inga erukurathu putikala apdithana😂_
[Sticker]

[4:38 PM] **You:**
> _Aruna HR Dvein: Sticker_
[Sticker]

[5:28 PM] **You:** Inga eruthu siddraj class ponna pakuranuga

[5:28 PM] **You:** Red shirt om green shirt om

[5:29 PM] **You:** Unga penati erukuravanuga

[5:29 PM] **Aruna HR Dvein:**
> _You: Red shirt om green shirt om_
Door close panu

[5:29 PM] **Aruna HR Dvein:** Ne

[5:29 PM] **You:** Hr erukaka avagala paakama vera ponna pakuranuga😂

[5:30 PM] **Aruna HR Dvein:** Nan thirumbi pathathukae green shirt oru side ah enaiya pathu frnds ta solluran

[5:30 PM] **You:**
> _Aruna HR Dvein: Image_
🥲

[5:30 PM] **Aruna HR Dvein:** Enaku pressure ah iruku munik

[5:30 PM] **Aruna HR Dvein:** Suthama mudiyala

[5:30 PM] **You:**
> _Aruna HR Dvein: Enaku pressure ah iruku munik_
Sari vetuga pathukalam

[5:30 PM] **Aruna HR Dvein:** Trm nan sahana ta sollathan poren

[5:30 PM] **You:** Na yapdiyachum thiruvanamali hod number vaaki tharan

[5:30 PM] **You:**
> _Aruna HR Dvein: Trm nan sahana ta sollathan poren_
Wait pannuga avasara patathiga

[5:31 PM] **Aruna HR Dvein:**
> _You: Wait pannuga avasara patathiga_
Yen apd sollura ne

[5:31 PM] **You:**
> _Aruna HR Dvein: Yen apd sollura ne_
Solura

[5:31 PM] **You:** Eppo avaga salary potanum atha unga side pressure poturaga . Avagalum pressure latha erukaka

[5:32 PM] **You:** So ungala corner panala atha understand panikoga

[5:32 PM] **Aruna HR Dvein:**
> _You: Eppo avaga salary potanum atha unga side pressure poturaga . Avagalum pressure latha erukaka_
Revenue illatha company ah enna mairuku nadathura antha maira

[5:32 PM] **You:** Selvamani vera amount kekuran atha unga kita kekuraga

[5:32 PM] **You:**
> _Aruna HR Dvein: Image_
Hay yepdi meet pannuva

[5:32 PM] **Aruna HR Dvein:**
> _You: Selvamani vera amount kekuran atha unga kita kekuraga_
Avanuku kuduka vakku illana enna dash ku vaanganu solu ne

[5:32 PM] **You:**
> _Aruna HR Dvein: Revenue illatha company ah enna mairuku nadathura antha maira_
Athum correct tha

[5:32 PM] **Aruna HR Dvein:** SEPTEMBER month ipodhn start agiruku athukulla workshop epd ok agum

[5:33 PM] **Aruna HR Dvein:** 3 to 5 dy agum dhn

[5:33 PM] **You:**
> _Aruna HR Dvein: SEPTEMBER month ipodhn start agiruku athukulla workshop epd ok agum_
Ama kantipa

[5:33 PM] **You:**
> _Aruna HR Dvein: 3 to 5 dy agum dhn_
Kantipa aakum

[5:33 PM] **Aruna HR Dvein:**
> _You: Hay yepdi meet pannuva_
Adhan thrla avaruku call pani pesitu dhn move panuvan edhuva irunthalum

[5:33 PM] **You:**
> _Aruna HR Dvein: Adhan thrla avaruku call pani pesitu dhn move panuvan edhuva irunthalum_
Okay kocham pathukoga because pakathula pakathula eruku

[5:34 PM] **Aruna HR Dvein:**
> _You: Kantipa aakum_
New Prince clg la mou ku intern+workshop sign panikalam sonanga ana principal oda appa death

Saradha clg la intha month dhn ana date sollala

Roever college la mou ku solluranu solirukanga

Nanu pathutu dhn munik ketutu dhn iruken suma theva llama vara

[5:34 PM] **Aruna HR Dvein:**
> _You: Okay kocham pathukoga because pakathula pakathula eruku_
Adhan da bayam eh

[5:34 PM] **Aruna HR Dvein:** Bayam nu lla dvein eh enaiya send-off panalu enaku no issues dhn

[5:35 PM] **Aruna HR Dvein:** Tagore clg pogunom la adhuku hod call eduka matranga

[5:35 PM] **You:**
> _Aruna HR Dvein: New Prince clg la mou ku intern+workshop sign panikalam sonanga ana principal oda appa death

Saradha clg la intha month dhn ana date sollala

Roever college la mou ku solluranu solirukanga

Nanu pathutu dhn munik ketutu dhn iruken suma theva llama vara_
Yenaku tharium niga potura efforts nanum pathukitutuana erukan

[5:35 PM] **Aruna HR Dvein:** Eni nan oorku poitu scl pudichathan undu

[5:35 PM] **You:**
> _Aruna HR Dvein: Eni nan oorku poitu scl pudichathan undu_
Na yapdiyachum Thiruvanathapuram clg okay paniran

[5:35 PM] **You:** Don't worry

[5:36 PM] **Aruna HR Dvein:**
> _You: Na yapdiyachum Thiruvanathapuram clg okay paniran_
Nan sahana ta soliduvan oorku poren scl acham pudikuren nu soli

[5:36 PM] **Aruna HR Dvein:** Idhulam velaikae agathu da

[5:45 PM] **You:** Hmm ok

[5:45 PM] **You:** Yetha eruthalum just Ora decesion matum yetuga

[5:45 PM] **You:** Already I told you

[5:46 PM] **Aruna HR Dvein:** epdiyu intha month ku inga dhn irukura mari irukum polla adhan solluren scl workshops acham pudchi tharalam nu thonudhu

[5:47 PM] **You:** Okay

[5:47 PM] **Aruna HR Dvein:** Hmm

[5:47 PM] **You:** Nanum yenota side ungalukaka workshop and placement pakuran

[5:47 PM] **Aruna HR Dvein:**
> _You: Nanum yenota side ungalukaka workshop and placement pakuran_
Thank yu da

[5:47 PM] **You:** Ungalukaka matum okay ah life la piriya ala anathuku aprom marathura kutathu yenaya

[5:48 PM] **You:** 😂

[5:48 PM] **Aruna HR Dvein:** moodu vanthutan pehhhhhhhh👻👻

[5:48 PM] **You:**
> _Aruna HR Dvein: moodu vanthutan pehhhhhhhh👻👻_
🙄

[5:53 PM] **Aruna HR Dvein:**
> _You: Image_
Pakkalam da avan enna solluranu solitu

[6:00 PM] **You:** Munik ah yavalo thitirupuga

[6:00 PM] **You:** 🥲

[6:00 PM] **You:** Eppo munik ungaluku nalathu panna poran

[6:00 PM] **You:** 🥲

[6:00 PM] **Aruna HR Dvein:**
> _You: Eppo munik ungaluku nalathu panna poran_
First number varatum aprm solluva ne

[6:00 PM] **Aruna HR Dvein:**
> _You: Eppo munik ungaluku nalathu panna poran_
Illa pa enaku apd venam ne unga jayasri amma ku kudu

[6:00 PM] **Aruna HR Dvein:** THANKS

[6:00 PM] **You:** [Forwarded] 9360220954
Venkatarathinam HOD (IT)

[6:01 PM] **Aruna HR Dvein:** Enaku ne sonathey podhum

[6:01 PM] **You:** சுற்றி நின்று ஊரே 🥲

[6:03 PM] **Aruna HR Dvein:** [Sticker]

[6:03 PM] **You:** [Sticker]

[6:07 PM] **You:** placement ku kuluga

[6:08 PM] **Aruna HR Dvein:** trm dhn pesanum intha time la venam

[6:11 PM] **You:** Price kamiya ve soluga

[6:11 PM] **You:**
> _Aruna HR Dvein: trm dhn pesanum intha time la venam_
Hmm okay

[6:11 PM] **Aruna HR Dvein:**
> _You: Price kamiya ve soluga_
ne  vera anaiku sahana ennama solluchi low price la nan allow pana ah matanu enaiya sonaah

[6:12 PM] **Aruna HR Dvein:** vandhuruchi eruma

[6:12 PM] **Aruna HR Dvein:** gandamirugam

[6:17 PM] **You:**
> _Aruna HR Dvein: ne  vera anaiku sahana ennama solluchi low price la nan allow pana ah matanu enaiya sonaah_
Niga pesuga athuku aprom avaga vetam sonna po di venna nu solitu papar poturuga

[6:17 PM] **You:** Ethuku melam yaralium evalo work lam panna mutiyathu

[6:17 PM] **You:**
> _Aruna HR Dvein: gandamirugam_
Unga Thampi 😂

[6:18 PM] **Aruna HR Dvein:**
> _You: Ethuku melam yaralium evalo work lam panna mutiyathu_
anaiku revenue kekura apo suriya munadi eh apd sollura theryum ah tension achi enaiya pathu dhn sonanah

[6:18 PM] **Aruna HR Dvein:** intha company ah promote panalam ninaicha paru enaiya serupala adikanum

[6:19 PM] **Aruna HR Dvein:** promote panama epd ne 1lks,2lks ku workshops r internship ku kepa sollu

[6:20 PM] **You:**
> _Aruna HR Dvein: promote panama epd ne 1lks,2lks ku workshops r internship ku kepa sollu_
Ama

[6:20 PM] **You:** Sari vetu

[6:20 PM] **You:** Pathukalam

[6:21 PM] **You:** Admin Yenna aana

[6:21 PM] **You:** Intership ku

[6:22 PM] **Aruna HR Dvein:** avan oru loosu kamunadi ah irupan polla naiyuu edho busy ah irukan ahm personal life and work life la etha pakurathunu thrla nu sollura aprm enna pudungurathuku ketan ahm sollu

[6:22 PM] **You:**
> _Aruna HR Dvein: avan oru loosu kamunadi ah irupan polla naiyuu edho busy ah irukan ahm personal life and work life la etha pakurathunu thrla nu sollura aprm enna pudungurathuku ketan ahm sollu_
🤣🤣unakunu varanuga paaru

[6:22 PM] **You:** 🤣

[6:22 PM] **Aruna HR Dvein:** chaiku adhan

[6:22 PM] **You:** Sari today full ah research pannitu va

[6:23 PM] **Aruna HR Dvein:**
> _You: Sari today full ah research pannitu va_
etha pathi

[6:23 PM] **You:** Placement ku yevalo price solalam per person ku nu

[6:23 PM] **You:** Avaga kepaga

[6:23 PM] **Aruna HR Dvein:** 200 dhn

[6:23 PM] **You:** Normal ah erukanum price appo tha varuvaga

[6:23 PM] **You:**
> _Aruna HR Dvein: 200 dhn_
Loosu

[6:23 PM] **Aruna HR Dvein:** sahana 500 sollum apd management side la vangura marina 1lks sollum

[6:23 PM] **You:** 20 days ku per person ku 2k antha mathiri

[6:24 PM] **Aruna HR Dvein:**
> _You: 20 days ku per person ku 2k antha mathiri_
adhuva nan 3 days workshop nu ninaichan

[6:24 PM] **Aruna HR Dvein:** 20 days ok panuvangala?

[6:24 PM] **You:**
> _Aruna HR Dvein: adhuva nan 3 days workshop nu ninaichan_
😂

[6:24 PM] **You:**
> _Aruna HR Dvein: 20 days ok panuvangala?_
Hmm panuvaga but price tha

[6:24 PM] **You:** Per person ku 1500 antha mathiri nalum ok tha

[6:24 PM] **You:** Atha matum research pannuga

[6:25 PM] **Aruna HR Dvein:** sure da

[6:25 PM] **You:** Hmm ok

[6:26 PM] **You:** Final year pasaga yelarum attend pannuvaga because passout aaka poragala atha

[6:26 PM] **Aruna HR Dvein:** 20 days na adhuku name workshop lla bootcamp dhn eh

[6:26 PM] **Aruna HR Dvein:**
> _You: Final year pasaga yelarum attend pannuvaga because passout aaka poragala atha_
haan ama

[6:26 PM] **You:** Eppo nama management matum ok Sola vachuta pothum

[6:26 PM] **You:**
> _Aruna HR Dvein: 20 days na adhuku name workshop lla bootcamp dhn eh_
No no

[6:26 PM] **Aruna HR Dvein:**
> _You: Eppo nama management matum ok Sola vachuta pothum_
idhunga kedakuthunga loosunga

[6:26 PM] **You:** Placement training

[6:26 PM] **You:** Unga clg la vachagala

[6:26 PM] **You:** Placement training

[6:26 PM] **Aruna HR Dvein:** 120 into 1500 na 1,80,000 varudhu

[6:26 PM] **Aruna HR Dvein:** ama ama adhuku pesuren nan trm mrg eh antha sir ta

[6:27 PM] **You:**
> _Aruna HR Dvein: 120 into 1500 na 1,80,000 varudhu_
Katipa 1500 sonalum 100 peru varuvaga

[6:27 PM] **You:** 1.5 laks

[6:27 PM] **You:**
> _Aruna HR Dvein: ama ama adhuku pesuren nan trm mrg eh antha sir ta_
Okay

[6:27 PM] **Aruna HR Dvein:** haan nan trm pesuran antha sir ta

[6:27 PM] **You:** Okay

[7:32 PM] **You:** Antha clg okay akiruchuna sawarma vaaki kutuga

[7:32 PM] **You:** 😁

---

## September 2, 2026

[9:36 AM] **Aruna HR Dvein:**
> _You: 9360220954
Venkatarathinam HOD (IT)_
Clg name enna

[9:36 AM] **Aruna HR Dvein:** ?

[9:37 AM] **You:** 😁 sorry ketu soluran

[9:37 AM] **Aruna HR Dvein:** ok ketu sollu

[9:38 AM] **Aruna HR Dvein:** rmba pesa venam sir irukaru

[9:50 AM] **You:** [Forwarded] Sri Balaji Chockalingam Engineering College

[9:50 AM] **You:** [Forwarded] Thiruvannamalai Arani

[9:50 AM] **Aruna HR Dvein:** Ok pa

[9:53 AM] **Aruna HR Dvein:** 2500 for java and python 

3000 for data analytics, data science and ai

[10:01 AM] **Aruna HR Dvein:** [Forwarded] Yes pa technical + placement assistance serthu irukkum

[10:02 AM] **You:** Super

[3:42 PM] **You:** Yenga eruthalum nala eruka

[3:42 PM] **You:** Nala work pannuga

[3:42 PM] **You:** God bless you

[3:42 PM] **You:** Happy ah eruka ...

[3:42 PM] **Aruna HR Dvein:**
> _You: Nala work pannuga_
Avaru 1hr aprm kupdurangalanu pakkalam munik

[3:42 PM] **Aruna HR Dvein:** Bayama iruku🥺

[3:42 PM] **Aruna HR Dvein:**
> _You: God bless you_
🙏🏻✨

[3:43 PM] **You:** Hay athalam payapatatha pathukalam

[3:43 PM] **Aruna HR Dvein:** Positive ah solluvangalanu sokitu

[3:43 PM] **You:** Athalam soluvaga

[3:43 PM] **Aruna HR Dvein:**
> _You: Athalam soluvaga_
Nan navin sona ah maridhn pesiruken but we will see

[3:44 PM] **You:** Over ah yethum solathiga intha company pathi rompa nagative ah Sola kutathu because avagalum owner tha so appo nama company om epditha soluvaga nu unga mela thapana thought varum

[3:44 PM] **You:**
> _Aruna HR Dvein: Nan navin sona ah maridhn pesiruken but we will see_
Hmm ok

[3:44 PM] **You:** Ungalota achivement lam soluga

[3:45 PM] **You:** Atha Mathiri next niga yenalam plan vachurukiganu soluga antha plan posible ah erukanum

[3:47 PM] **Aruna HR Dvein:**
> _You: Over ah yethum solathiga intha company pathi rompa nagative ah Sola kutathu because avagalum owner tha so appo nama company om epditha soluvaga nu unga mela thapana thought varum_
Apdlam edhuveme vaiya thorakkala da

[3:47 PM] **Aruna HR Dvein:**
> _You: Atha Mathiri next niga yenalam plan vachurukiganu soluga antha plan posible ah erukanum_
sure da

[3:47 PM] **Aruna HR Dvein:**
> _You: Ungalota achivement lam soluga_
Solitan nanu

[3:49 PM] **You:**
> _Aruna HR Dvein: Apdlam edhuveme vaiya thorakkala da_
Okay

[3:49 PM] **You:**
> _Aruna HR Dvein: Solitan nanu_
Hmm super

[3:53 PM] **Aruna HR Dvein:** Analu bayama iruku

[3:54 PM] **You:** Payathu payathu Yenna sathuchutom nama yelarum .. thariyama poga pathukalam

[4:11 PM] **Aruna HR Dvein:** ok da

[4:12 PM] **Aruna HR Dvein:** crt dhn ne sollurathum

[4:17 PM] **You:** Hmm ama

[7:05 PM] **You:** Yethum Sola vanthiga

[7:06 PM] **You:** Jaya sree vanthathum pouta

[9:21 PM] **Aruna HR Dvein:** [Voice message]

[9:22 PM] **You:** Ama

[9:22 PM] **You:** Just 1 month

[9:22 PM] **Aruna HR Dvein:** Ana mudiyala

[9:23 PM] **You:** Sari etha pathi tmr pesalam

[9:23 PM] **You:** Eppo free ah saptu thuku

[9:23 PM] **You:** Yenga veliya poriya eppo

[9:35 PM] **Aruna HR Dvein:**
> _You: Sari etha pathi tmr pesalam_
Yen epd sollura ipove sollu

[9:35 PM] **You:** https://youtube.com/shorts/Th9-xlQ_qBg?si=bBYvM0vGWBeYkKK8

[9:35 PM] **Aruna HR Dvein:**
> _You: Eppo free ah saptu thuku_
Ipove solu ne

[9:35 PM] **Aruna HR Dvein:** Ennanu

[9:36 PM] **You:** Na my alakana voice la patuna song

[9:36 PM] **Aruna HR Dvein:**
> _You: Sari etha pathi tmr pesalam_
Ne ipove sollu enanu

[9:36 PM] **Aruna HR Dvein:**
> _You: Na my alakana voice la patuna song_
Loosu

[9:36 PM] **Aruna HR Dvein:** Etha sollu

[9:36 PM] **You:**
> _Aruna HR Dvein: Ne ipove sollu enanu_
Okay saptu soluran 🥲

[9:36 PM] **Aruna HR Dvein:**
> _You: Okay saptu soluran 🥲_
Ok

---

## September 3, 2026

[11:34 AM] **Aruna HR Dvein:** Arignar Anna Higher Secondary School, sendurai 

5days workshop on AI sparks: Igniting future innovators 8/6/2026 - 12/6/2026

[11:34 AM] **Aruna HR Dvein:** [album message]

[11:35 AM] **Aruna HR Dvein:** [Image]

[11:35 AM] **Aruna HR Dvein:** [Image]

[11:35 AM] **Aruna HR Dvein:** [unknown message]

[11:35 AM] **Aruna HR Dvein:** [unknown message]

[11:35 AM] **Aruna HR Dvein:** St.theresa Matriculation Higher Secondary School,Sendurai 

5days workshop on AI sparks: Igniting future innovators 22/6/2026 - 27/6/2026

[11:35 AM] **Aruna HR Dvein:** [Image]

[11:35 AM] **Aruna HR Dvein:** [Image]

[11:35 AM] **Aruna HR Dvein:** [Image]

[11:35 AM] **Aruna HR Dvein:** [unknown message]

[11:35 AM] **Aruna HR Dvein:** [unknown message]

[11:35 AM] **Aruna HR Dvein:** [unknown message]

[11:35 AM] **Aruna HR Dvein:** Vetri vinayaga one day AI awareness session one day 30/6/2026

[11:35 AM] **Aruna HR Dvein:** [album message]

[11:35 AM] **Aruna HR Dvein:** [Image]

[11:35 AM] **Aruna HR Dvein:** [Image]

[11:35 AM] **Aruna HR Dvein:** [unknown message]

[11:35 AM] **Aruna HR Dvein:** [unknown message]

[11:35 AM] **Aruna HR Dvein:** Bishop Heber College,Trichy 
01/07/2026

[11:35 AM] **Aruna HR Dvein:** [album message]

[11:35 AM] **Aruna HR Dvein:** [Image]

[11:35 AM] **Aruna HR Dvein:** [Image]

[11:35 AM] **Aruna HR Dvein:** [unknown message]

[11:35 AM] **Aruna HR Dvein:** [unknown message]

[11:36 AM] **Aruna HR Dvein:** Jeppiaar college of Arts & science 08/07/2026

[11:36 AM] **Aruna HR Dvein:** [Image]

[11:36 AM] **Aruna HR Dvein:** [unknown message]

[11:36 AM] **Aruna HR Dvein:** Hindustan university
08/7/26

[11:36 AM] **Aruna HR Dvein:** _This message was deleted_

[11:36 AM] **Aruna HR Dvein:** [Image]

[11:36 AM] **Aruna HR Dvein:** _This message was deleted_

[11:36 AM] **Aruna HR Dvein:** [unknown message]

[11:36 AM] **Aruna HR Dvein:** Padma adarsh higher sec school
9/7/2026

[11:36 AM] **Aruna HR Dvein:** [Image]

[11:36 AM] **Aruna HR Dvein:** [unknown message]

[11:36 AM] **Aruna HR Dvein:** Prof. Dhanapalan college of science & management 9/7/2026

[11:36 AM] **Aruna HR Dvein:** [Image]

[11:36 AM] **Aruna HR Dvein:** [unknown message]

[11:37 AM] **Aruna HR Dvein:** Kcg college - 21/7/26

[11:37 AM] **Aruna HR Dvein:** [Image]

[11:37 AM] **Aruna HR Dvein:** [Image]

[11:37 AM] **Aruna HR Dvein:** [unknown message]

[11:37 AM] **Aruna HR Dvein:** [unknown message]

[11:37 AM] **Aruna HR Dvein:** Agni college of technology 
22/7/26

[11:37 AM] **Aruna HR Dvein:** [Image]

[11:37 AM] **Aruna HR Dvein:** [unknown message]

[11:43 AM] **Aruna HR Dvein:** Dhanaraj Baid Jain college 
30/7/26

[11:43 AM] **Aruna HR Dvein:** [Image]

[11:43 AM] **Aruna HR Dvein:** [Image]

[11:43 AM] **Aruna HR Dvein:** [unknown message]

[11:43 AM] **Aruna HR Dvein:** [unknown message]

[11:43 AM] **Aruna HR Dvein:** Tagore Engineering college 
6/8/26

[11:43 AM] **Aruna HR Dvein:** [album message]

[11:44 AM] **Aruna HR Dvein:** [Image]

[11:44 AM] **Aruna HR Dvein:** [Image]

[11:44 AM] **Aruna HR Dvein:** Alpha College of Engineering- Industrial visit 13/8/2026

[11:44 AM] **Aruna HR Dvein:** [Image]

[11:44 AM] **Aruna HR Dvein:** [unknown message]

[12:42 PM] **Aruna HR Dvein:** [Image]

[12:44 PM] **Aruna HR Dvein:** [Document] Dvein Workshop Presentation (2) (NEW)_compressed.pdf

[3:29 PM] **Aruna HR Dvein:** 📢 INTERNSHIP & CERTIFICATION COURSE OPPORTUNITIES – DVein Innovations Pvt. Ltd.

Dear Students,

DVein Innovations Pvt. Ltd. is pleased to offer Internship and Industry-Oriented Certification Course Opportunities for students seeking to enhance their technical knowledge, professional skills, and industry exposure. These programs are designed to provide hands-on learning, real-time project experience, and career-oriented training through Remote and Hybrid modes.

🎯 Available Domains

Technical Domains:
• Full Stack Java
• Full Stack Python
• Data Science & AI
• AI & Machine Learning
• Data Analytics
• Business Analytics
• DevOps
• Cloud Computing
• MERN Stack
• UI/UX Design & Prototyping
• Web Development
• Internet of Things (IoT)
• Embedded Systems
• Cyber Security
• Big Data Analytics
• Software Testing

Management Domains:
• HR – Marketing
• HR – Finance & Accounting
• Digital Marketing
•Social Media Marketing
•SEO & SEM
•Content Marketing
•Google Ads / Performance Marketing
•Branding & Marketing Strategy

Internship Opportunities

• 15 Days Internship-1,500
• 1 Month Internship-2,000 
• 2 to 6 Months Internship – Available

🎓 Certification Course Opportunities

• 3-Month Industry-Oriented Certification Programs
• Practical & Hands-on Learning
• Real-Time Project Exposure
• Course Completion Certificate

🏠 Mode of Training

• Remote
• Hybrid

💳 Registration Process

Students can confirm their registration by paying an initial amount of ₹500. The remaining balance fee can be paid during the internship/course period.

📝 Registration Link

https://apply.dveininnovation.com

📩 Offer Letter & Course Confirmation

Upon successful registration, candidates will receive their Internship Offer Letter or Course Confirmation Letter.

📍 Office Address

3rd Floor, Gamma Block, SSPDL - Alpha City, Navalur, Chennai, Tamil Nadu.

Take advantage of this opportunity to gain valuable industry experience, strengthen your skills, and enhance your career prospects.

Warm Regards,
Arunadevi
HR & Business Development Executive
DVein Innovations Pvt. Ltd.
+91 63849 00541

[3:29 PM] **Aruna HR Dvein:** Intha mess ah unaku therinja Students ku share panu munik

[3:43 PM] **You:** Hmm ok

[3:56 PM] **Aruna HR Dvein:**
> _You: Image_
Ipo athuku enna panalam sollu

[4:19 PM] **You:** 🫩porama

[6:20 PM] **Aruna HR Dvein:** dei

[6:20 PM] **Aruna HR Dvein:** trm 9 clk interview iruku enaku

[6:21 PM] **Aruna HR Dvein:** mode :Virtual interview

[6:21 PM] **Aruna HR Dvein:** HR message pananga

[6:21 PM] **You:** Super

[6:21 PM] **You:** All the best 🤩

[6:21 PM] **Aruna HR Dvein:** bayama iruku da

[6:21 PM] **You:**
> _Aruna HR Dvein: bayama iruku da_
Yethuku

[6:21 PM] **You:** 🙄

[6:22 PM] **Aruna HR Dvein:**
> _You: All the best 🤩_
thanks alots da 🥹

[6:22 PM] **Aruna HR Dvein:**
> _You: Yethuku_
thrla nalla panuvan ah nu dhn bayama iruku

[6:22 PM] **Aruna HR Dvein:** oru mari nervous ah

[6:22 PM] **You:**
> _Aruna HR Dvein: thanks alots da 🥹_
Athalam niga nala pannirukiga.. nala pannitu tha varanum . Okay ah

[6:22 PM] **Aruna HR Dvein:**
> _You: Athalam niga nala pannirukiga.. nala pannitu tha varanum . Okay ah_
kandipa nalla panuvan munik

[6:22 PM] **You:**
> _Aruna HR Dvein: thrla nalla panuvan ah nu dhn bayama iruku_
Namaku tharucha tha Sola porom athula yanna payam

[6:23 PM] **Aruna HR Dvein:** mrg matu permission vaangiduvan ivanga kita 10clk dhn r 10:30 ku vara mari dhn varuvan

[6:23 PM] **You:** Avaga Yenna question kepaga thariuma yeah intha role ah choos paniga

[6:23 PM] **You:** Yethanala unga company vetu Inga variga

[6:23 PM] **Aruna HR Dvein:**
> _You: Avaga Yenna question kepaga thariuma yeah intha role ah choos paniga_
already antha role la dhn da iruken

[6:23 PM] **You:** Intha 2 question tha important

[6:23 PM] **You:** 2nd question 100% kepaga

[6:23 PM] **Aruna HR Dvein:**
> _You: Yethanala unga company vetu Inga variga_
ama ama kepanga nit prepare pananum nanu

[6:23 PM] **You:** Niga dvein pathi thappa Sola kutathu atha nala thaduchukoga

[6:24 PM] **Aruna HR Dvein:**
> _You: 2nd question 100% kepaga_
ama da ik nan nit prepare paniduvan idhukulam qstn

[6:24 PM] **Aruna HR Dvein:**
> _You: Niga dvein pathi thappa Sola kutathu atha nala thaduchukoga_
ure da evlo conversation la negavtive ah sollave lla adhan

[6:24 PM] **Aruna HR Dvein:** sure*

[6:24 PM] **You:** Hmm atha unota character papaga

[6:25 PM] **You:** Ni thappa sonina appo evala yetutha nama company om thapa tha soluva nu nanapaga

[6:26 PM] **Aruna HR Dvein:** ama ama crt da

[6:26 PM] **Aruna HR Dvein:** i agrree this one

[6:26 PM] **You:** Hmm ama

[6:26 PM] **You:** Athuku yetha mathiri solu

[6:27 PM] **You:** Select akita Yenna vaki tharuva

[6:27 PM] **Aruna HR Dvein:**
> _You: Select akita Yenna vaki tharuva_
trm inream la result vanthurum so athuku aprm solluran enanu

[6:28 PM] **You:** Hmm ok avagalum human tha

[6:28 PM] **You:** So payapathatha

[6:28 PM] **You:** Easy ah interview crack panna Ora vali

[6:28 PM] **You:** Avaga place la eruthu ni think pannu

[6:28 PM] **You:** Eppo una vera company la eruthutha avaga hire pannuraga

[6:28 PM] **Aruna HR Dvein:** sure da kandipa nan trm epd pananu solluren seriya

[6:28 PM] **Aruna HR Dvein:**
> _You: Eppo una vera company la eruthutha avaga hire pannuraga_
ama

[6:29 PM] **You:** Avagaluku yenalam doubt erukum atha niya create pannu epdilam kepaga nu

[6:29 PM] **Aruna HR Dvein:**
> _You: Avagaluku yenalam doubt erukum atha niya create pannu epdilam kepaga nu_
ok da

[6:29 PM] **You:** Eppo nu una mathiri person ah hire panna porana na avaga kita yenalam kepayo atha matum preperation panna pothum

[6:29 PM] **Aruna HR Dvein:** analu lita bayama iruku simple ah keta nalla irukum la

[6:30 PM] **Aruna HR Dvein:**
> _You: Eppo nu una mathiri person ah hire panna porana na avaga kita yenalam kepayo atha matum preperation panna pothum_
kandipa da

[6:30 PM] **You:** Payatha ingaya erukanum parava illa ah

[6:30 PM] **Aruna HR Dvein:** amtha hr spr ah english pesunanga

[6:30 PM] **You:**
> _Aruna HR Dvein: analu lita bayama iruku simple ah keta nalla irukum la_
Hay simpl ah tha kepaga

[6:30 PM] **Aruna HR Dvein:**
> _You: Payatha ingaya erukanum parava illa ah_
Noooo:)

[6:30 PM] **You:**
> _Aruna HR Dvein: amtha hr spr ah english pesunanga_
Namala vetava

[6:30 PM] **You:** Why u choose for our company

[6:31 PM] **You:** Intha question ku valid ah answer vachuko

[6:31 PM] **You:** Why u suddenly change your company?

[6:33 PM] **Aruna HR Dvein:**
> _You: Intha question ku valid ah answer vachuko_
Sure da

[6:33 PM] **Aruna HR Dvein:**
> _You: Why u suddenly change your company?_
Kandipa prepare panuvan

[6:48 PM] **You:** Oii

[6:48 PM] **You:** Ni ingaya eru

[6:48 PM] **You:** Na bad vaki vanthuratuma

[6:49 PM] **You:** Niga rompa thuram natakanum

[7:31 PM] **You:** Eppo okay ah

[7:53 PM] **Aruna HR Dvein:**
> _You: Eppo okay ah_
Ok dhn da ana leg pain semaiya iruku

[8:04 PM] **You:** Hmm

[8:04 PM] **You:** _You deleted this message_

---

## September 4, 2026

[7:12 AM] **You:** Gm

[7:31 AM] **You:** Niga yeluthuna clg name matum send pannuga photo yetuthikala

[7:37 AM] **Aruna HR Dvein:**
> _You: Niga yeluthuna clg name matum send pannuga photo yetuthikala_
Puriyala da

[7:37 AM] **Aruna HR Dvein:**
> _You: Gm_
Gm✨

[7:37 AM] **You:** Yesterday

[7:37 AM] **You:** Niga work Shop details write panigala

[7:37 AM] **You:** Antha photo anupuga

[7:38 AM] **Aruna HR Dvein:** [album message]

[7:38 AM] **Aruna HR Dvein:** [Image]

[7:38 AM] **Aruna HR Dvein:** [Image]

[7:40 AM] **You:** Bishop la work Shop panigala

[7:40 AM] **You:** Or just visit ah?

[8:02 AM] **Aruna HR Dvein:** just visit da

[8:03 AM] **You:** Hmm

[8:34 AM] **You:** All the best 😍

[8:34 AM] **You:** 🫂

[8:34 AM] **You:** Good news solu

[8:34 AM] **You:** First yenaku tha happy news solanum

[8:34 AM] **You:** Okay ah

[8:34 AM] **Aruna HR Dvein:**
> _You: All the best 😍_
Thank you munik🫂

[8:35 AM] **You:** 🫂

[8:35 AM] **Aruna HR Dvein:**
> _You: First yenaku tha happy news solanum_
Kandipa da munik

[8:35 AM] **Aruna HR Dvein:** Solluren

[8:35 AM] **You:** Hmm

[12:05 PM] **You:** Bleed akuthu

[12:05 PM] **Aruna HR Dvein:** Dress la paturuchi neriya adhan

[12:06 PM] **Aruna HR Dvein:** Over flow adhigama iruku

[12:06 PM] **Aruna HR Dvein:** Enaku

[12:06 PM] **Aruna HR Dvein:** Adhan mam kelamba solitanga jayasri dhn patha Bleed ah dress la pattatha

[12:14 PM] **You:** Hmm

[12:14 PM] **You:** Vara matigala

[12:14 PM] **Aruna HR Dvein:**
> _You: Vara matigala_
Nooo

[1:10 PM] **Aruna HR Dvein:** Saami kumbutingala

[1:10 PM] **Aruna HR Dvein:** Ne sapda kelambitiya da

[1:31 PM] **Aruna HR Dvein:** Deii

[1:31 PM] **You:**
> _Aruna HR Dvein: Ne sapda kelambitiya da_
Hmm kelmapitan

[1:31 PM] **You:** [Image]

[1:31 PM] **You:**
> _Aruna HR Dvein: Saami kumbutingala_
Kumpututom

[1:32 PM] **You:** Snacks kututhaga

[1:32 PM] **Aruna HR Dvein:**
> _You: Snacks kututhaga_
Ok ok da

[1:32 PM] **Aruna HR Dvein:**
> _You: Image_
Parraahhh

[1:32 PM] **You:**
> _Aruna HR Dvein: Parraahhh_
Yepdi

[1:32 PM] **Aruna HR Dvein:**
> _You: Yepdi_
Sprb

[1:32 PM] **Aruna HR Dvein:** ✨✨✨

[1:32 PM] **You:** Eppo parava illa ah

[11:03 PM] **Aruna HR Dvein:** Munik

[11:03 PM] **Aruna HR Dvein:** Unkita news paper iruka ah?

---

## September 5, 2026

[8:00 AM] **You:** Ye

[8:01 AM] **You:** Rompa important ah Venum na soluga katila vakikalam

[8:01 AM] **Aruna HR Dvein:**
> _You: Rompa important ah Venum na soluga katila vakikalam_
Illa lla da ketan

[8:01 AM] **You:** Hmm

[8:02 AM] **You:** Yethuku News paper

[8:14 AM] **Aruna HR Dvein:**
> _You: Yethuku News paper_
Venum da

[8:15 AM] **You:** Hmm

[8:18 AM] **Aruna HR Dvein:** https://www.instagram.com/reel/Dc3mtSABEJo/?igsi=OTM0eXptMHRxd2g1

[8:36 AM] **You:**
> _Aruna HR Dvein: https://www.instagram.com/reel/Dc3mtSABEJo/?igsi=OTM0eXptMHRxd2g1_
Mam om dhanush raasi tha I think so

[8:36 AM] **You:** 🤣🤣🤣🤣

[8:40 AM] **Aruna HR Dvein:**
> _You: Mam om dhanush raasi tha I think so_
Apdiya

[8:41 AM] **Aruna HR Dvein:** [Voice message]

[8:43 AM] **Aruna HR Dvein:** Inga noodles da mrg sapdave lla nanu tea dhn kudichitu varuvan

[8:49 AM] **You:**
> _Aruna HR Dvein: Voice message_
Nanum simam tha

[8:49 AM] **You:** 🦁

[8:49 AM] **You:**
> _Aruna HR Dvein: Inga noodles da mrg sapdave lla nanu tea dhn kudichitu varuvan_
Okay

[8:50 AM] **You:** Na vata yetuthu varan

[8:50 AM] **Aruna HR Dvein:**
> _You: Na vata yetuthu varan_
Thanks alot vaa vaaa

[8:50 AM] **Aruna HR Dvein:**
> _You: Nanum simam tha_
Enga amma simma rasi dhn

[8:52 AM] **You:**
> _Aruna HR Dvein: Thanks alot vaa vaaa_
🙌

[8:53 AM] **You:**
> _Aruna HR Dvein: Enga amma simma rasi dhn_
Simma rasi pura nachathiram

[9:07 AM] **Aruna HR Dvein:**
> _You: Simma rasi pura nachathiram_
Enga amma odathu unodathu same

[9:08 AM] **You:** Coconut satni putikam

[9:09 AM] **Aruna HR Dvein:**
> _You: Coconut satni putikam_
Venam venam da

[9:09 AM] **Aruna HR Dvein:** Nan office vantan

[9:15 AM] **You:** Hmm

[9:52 AM] **You:** Tmr cricket match paaka poalma

[9:52 AM] **You:** Chepauk ku

[9:52 AM] **Aruna HR Dvein:**
> _You: Tmr cricket match paaka poalma_
Tickets?

[9:52 AM] **Aruna HR Dvein:** Price

[9:52 AM] **You:** Free

[9:53 AM] **Aruna HR Dvein:**
> _You: Free_
Apo na kuttama irukum da

[9:53 AM] **Aruna HR Dvein:** Periods oda venam enaku comfortable ah irukathu

[9:55 AM] **You:**
> _Aruna HR Dvein: Apo na kuttama irukum da_
Avalova lam kutam erukathu

[9:55 AM] **You:**
> _Aruna HR Dvein: Periods oda venam enaku comfortable ah irukathu_
Sari sari niga varatha eruthalum soluga

[9:55 AM] **Aruna HR Dvein:**
> _You: Sari sari niga varatha eruthalum soluga_
Ok munik solluran

[9:55 AM] **You:** Hmm ok

[10:15 AM] **Aruna HR Dvein:** Rent eh enga appa ta dhn kekuran da😭🤧

[10:15 AM] **Aruna HR Dvein:** Kastama iruku

[10:16 AM] **You:**
> _Aruna HR Dvein: Image_
Emd na

[10:17 AM] **Aruna HR Dvein:**
> _You: Emd na_
Appa 2 number vachirukanga so athu enga office name AMD Transportation oda name

[10:17 AM] **Aruna HR Dvein:** Ariyalur mahadevan dhanalakshmi thatha Patti name

[10:18 AM] **You:** Hmm

[10:18 AM] **You:** Sari feel panathiga pathukalam

[12:42 PM] **Aruna HR Dvein:** Enaku irukave pudikala

[12:54 PM] **You:** Yeah

[12:54 PM] **You:** Yenna achu

[12:54 PM] **Aruna HR Dvein:** Suma

[1:00 PM] **You:** Soluga

[1:00 PM] **You:** Yenna achu

[1:00 PM] **Aruna HR Dvein:** Kadupa irukj

[1:01 PM] **Aruna HR Dvein:** Thala suthudhu,tired ah iruku,mood swings agudhu yen da porandhom nu iruku🥲

[1:02 PM] **You:**
> _Aruna HR Dvein: Thala suthudhu,tired ah iruku,mood swings agudhu yen da porandhom nu iruku🥲_
Atha Yenna potu atipikala atika atuchutu normal akuka

[1:07 PM] **Aruna HR Dvein:**
> _You: Atha Yenna potu atipikala atika atuchutu normal akuka_
Puriyala

[2:27 PM] **You:** Yenna aticha normal avigala yepaum atha mathiri epaum atuchutu normal aakuga nu sonna😂

[2:28 PM] **Aruna HR Dvein:** Poi velaiya paru bro

[2:35 PM] **You:**
> _Aruna HR Dvein: Poi velaiya paru bro_
[Sticker]

[2:37 PM] **You:** Nala thukam pola

[2:37 PM] **You:** 😂

[2:37 PM] **Aruna HR Dvein:** Ama ctrl pana ah mudiyala

[2:37 PM] **Aruna HR Dvein:** Back pain neck pain ah iruku

[2:38 PM] **You:** Ungalukaka oru song

[2:38 PM] **Aruna HR Dvein:** haiyooo ala vidura saami

[2:38 PM] **You:** https://youtube.com/shorts/_615t6YkIT8?si=00TNm9cva3b3nwG5

[2:39 PM] **You:** Kanna ni thuku da kanna ni thuku da

[2:39 PM] **Aruna HR Dvein:**
> _You: Kanna ni thuku da kanna ni thuku da_
😅🫡😴

[2:39 PM] **You:** Kila veluthuratha thuki

[2:40 PM] **You:** Aprom asikama pourum😂

[2:40 PM] **You:** Jaya sree mathiri thuka palakiko

[2:40 PM] **Aruna HR Dvein:** Chi odu

[2:42 PM] **You:** Yenna thitannum na matum thukam varathu

[2:45 PM] **Aruna HR Dvein:** 😅🤪😹

[3:07 PM] **You:** Nanum pathukitatha erukan Ora folder la mouse thalikita erukiga

[3:08 PM] **You:** 😂

[3:09 PM] **Aruna HR Dvein:** Dei loosu elqme del panitu iruken

[3:09 PM] **Aruna HR Dvein:** Offer Letter and certificate

[3:09 PM] **Aruna HR Dvein:** Unaiya mari Vty ah nan onu pesitu lla

[3:10 PM] **You:**
> _Aruna HR Dvein: Unaiya mari Vty ah nan onu pesitu lla_
Ama ama paathalum TCS company ku offer letter panikitu erukaka🤣🤣

[3:11 PM] **You:** Otatha company ku offer letter 🤣🤣🤣

[3:17 PM] **You:** Yenna reels payakarama thaluriga

[3:17 PM] **You:** 🤣

[3:26 PM] **You:** Yengalalam pathigala work ah ilatium yetho 1000 work erukura mathiri erupom

[3:26 PM] **You:** 😂

[3:26 PM] **You:** [Sticker]

[4:00 PM] **You:** [Forwarded] [Audio]

[4:06 PM] **Aruna HR Dvein:** Odiru

[4:06 PM] **Aruna HR Dvein:** Work pa ru

[4:06 PM] **You:** Airbotes kutuga

[4:06 PM] **You:** Song keka

[4:06 PM] **Aruna HR Dvein:** Suma👊🏻

[4:06 PM] **You:**
> _Aruna HR Dvein: Suma👊🏻_
[Sticker]

[4:06 PM] **Aruna HR Dvein:**
> _You: Song keka_
Nan kekaporen bro

[4:06 PM] **You:**
> _Aruna HR Dvein: Nan kekaporen bro_
Onu kutuga

[4:06 PM] **Aruna HR Dvein:** Enala thongatha Ctrl pana ah mudiyala

[4:06 PM] **Aruna HR Dvein:**
> _You: Onu kutuga_
Pehhh

[4:06 PM] **You:** Nigala song potuga

[4:07 PM] **You:** Ungaluku vetama

[4:07 PM] **Aruna HR Dvein:** noo

[4:08 PM] **You:** Na song poturan

[4:08 PM] **You:** Unga phone la disconnect pannuga

[4:08 PM] **You:** Name yenna airbotes

[4:08 PM] **Aruna HR Dvein:** CNF PRO

[4:09 PM] **Aruna HR Dvein:**
> _You: Unga phone la disconnect pannuga_
disconnect la dhn iruku

[6:59 PM] **Aruna HR Dvein:** Pg vantan

[7:02 PM] **You:** Hmm eppo tha call panni kekalam nu pathan

[7:03 PM] **Aruna HR Dvein:** Vantan da

[7:03 PM] **Aruna HR Dvein:** Heavy flow Vera Sema fast ah walk pani vanthan

[7:03 PM] **Aruna HR Dvein:** Kulikanum poitu

[7:03 PM] **Aruna HR Dvein:** Tata

[7:03 PM] **You:** Hayy

[7:04 PM] **You:** Apdi solirutha auto la vanthurukalam la

[7:04 PM] **You:** Na marathutan

[7:04 PM] **You:** Sorry

[7:34 PM] **Aruna HR Dvein:** Paravala irukatu da pavaam jayasri uh gpay la enta lla suthama 500 ah dhn cash irundhuchi so walk mari pogalam ninaichan

[7:34 PM] **Aruna HR Dvein:** Ipodhn kulichitu dress wash panitu paduthan sema tired

[7:35 PM] **You:** Saptu thukuga

[7:36 PM] **Aruna HR Dvein:** Ok ok munik

[10:09 PM] **You:** Jaya sri next week leave nu soluthu

[10:10 PM] **You:** Saturday

[10:10 PM] **Aruna HR Dvein:** Apdiya apona nan 1week v2la iruka poren

[10:10 PM] **Aruna HR Dvein:** Full ah complete panitu varulam iruken epudi

[10:10 PM] **You:** Hmm okay

[10:10 PM] **You:** But unmya nu thariyala

[10:11 PM] **Aruna HR Dvein:** Illanalu enalu time agum varathuku

[10:11 PM] **Aruna HR Dvein:** Scl workshop ku dhn pesa poren

[10:11 PM] **You:** Hmm ok

---

## September 6, 2026

[6:54 AM] **You:** Oii

[6:54 AM] **You:** Saturday Sunday Monday holiday

[6:54 AM] **You:** 🤩

[8:13 AM] **Aruna HR Dvein:**
> _You: Saturday Sunday Monday holiday_
Cnfrm ah?

[8:14 AM] **Aruna HR Dvein:** Yaru sona ah?

[8:14 AM] **You:** Tuesday work from home 🤩

[8:15 AM] **You:**
> _You: Saturday Sunday Monday holiday_
Monday holiday aprom work from home

[8:15 AM] **Aruna HR Dvein:**
> _Aruna HR Dvein: Yaru sona ah?_
.

[8:17 AM] **You:** Jaya sree

[8:24 PM] **Aruna HR Dvein:** 1lk ku keturuken da

[8:24 PM] **Aruna HR Dvein:** En frnd ta

[8:25 PM] **You:**
> _Aruna HR Dvein: ._
Hayyy

[8:25 PM] **You:** Hayy

[8:25 PM] **You:** Ni marathutanu nanacha

[8:25 PM] **You:** 🙇‍♂️

[8:25 PM] **You:** Yenakaka napakam vachu keturuka🙇‍♂️

[8:26 PM] **You:** Na kantipa ethalam my life memory la save pannipan.. yanaku yaralam help panuragalo avagala maraka matan

[8:26 PM] **You:** 🙇‍♂️

[8:29 PM] **Aruna HR Dvein:** [Voice message]

[8:30 PM] **You:** 🫂

[8:30 PM] **You:** Intrest yavalo

[8:33 PM] **Aruna HR Dvein:** [Voice message]

[8:36 PM] **You:** Okay thank you 🫂🙌

[8:42 PM] **Aruna HR Dvein:** 🫂✨

[8:43 PM] **You:** Amount vanthalum ok varatium ok but yenakaka efforts pota antha one ah maraka maatan pramiss ah

[8:43 PM] **You:** 🫂

[8:44 PM] **Aruna HR Dvein:**
> _You: Amount vanthalum ok varatium ok but yenakaka efforts pota antha one ah maraka maatan pramiss ah_
Kandipa nan help pnuvan en side la ana thanks nu soli asinga paduthatha

[8:44 PM] **Aruna HR Dvein:** Pls

[8:44 PM] **You:**
> _Aruna HR Dvein: Kandipa nan help pnuvan en side la ana thanks nu soli asinga paduthatha_
😂 okay okay

[8:44 PM] **You:** Na periya ala akitu unga name soluvan stage la😂😂😂

---

## September 7, 2026

[9:58 AM] **Aruna HR Dvein:** always welcome n thanks vro

[10:24 AM] **You:** [Sticker]

[5:21 PM] **Aruna HR Dvein:** Munik

[5:22 PM] **Aruna HR Dvein:** Mess pani kekava sir ta

[5:22 PM] **Aruna HR Dvein:** Coo ta

[5:22 PM] **You:** Yenanu

[5:22 PM] **Aruna HR Dvein:** Sir update solluranu soningala sir ennachi r direct ah varava ungala meet pana ah after 6.30 mela office over anathunu soli

[5:23 PM] **You:**
> _Aruna HR Dvein: Sir update solluranu soningala sir ennachi r direct ah varava ungala meet pana ah after 6.30 mela office over anathunu soli_
Hmm kelufa

[5:23 PM] **You:** But the rompa

[5:23 PM] **Aruna HR Dvein:**
> _You: Hmm kelufa_
Iru kekuran

[5:23 PM] **You:** Thola pannura mathiri feel akirana

[5:23 PM] **You:** Intha week matum kuta wait panjuga

[5:23 PM] **Aruna HR Dvein:**
> _You: Thola pannura mathiri feel akirana_
Enaku apdthan iruku da

[5:23 PM] **Aruna HR Dvein:** Kekava venam ah ipo?

[5:23 PM] **You:** Vetam

[5:24 PM] **You:** Next week niga chennai vanthutu keluga

[5:24 PM] **Aruna HR Dvein:** Ok da

[5:24 PM] **You:** Correct ah erukum

[5:24 PM] **Aruna HR Dvein:**
> _You: Next week niga chennai vanthutu keluga_
Oru 3 dys aprm kuda kekuren

[5:24 PM] **Aruna HR Dvein:** 1 week la venam

[5:24 PM] **You:** Avarum nanaparu ama nama 2 week ah update panava illa nu

[5:24 PM] **Aruna HR Dvein:**
> _You: Avarum nanaparu ama nama 2 week ah update panava illa nu_
Okiee da

[5:24 PM] **You:**
> _Aruna HR Dvein: Oru 3 dys aprm kuda kekuren_
One week na correct ah erukum

[5:24 PM] **Aruna HR Dvein:**
> _You: One week na correct ah erukum_
Haan okiee

[5:24 PM] **Aruna HR Dvein:** Jayasree enna solludhu😬😹

[5:25 PM] **You:**
> _Aruna HR Dvein: Jayasree enna solludhu😬😹_
Yennanu

[5:25 PM] **Aruna HR Dvein:**
> _You: Yennanu_
Ph la

[5:25 PM] **You:** Yenna soluchu

[5:26 PM] **Aruna HR Dvein:** nothing

[5:26 PM] **Aruna HR Dvein:** vidu

[5:26 PM] **You:** Sola mutium mutiyathu

[5:29 PM] **Aruna HR Dvein:** mudiyathu hey ava unkita dhn eh phone la enamo ipo katuna aprn enkita loosu mari kekura

[5:30 PM] **You:**
> _Aruna HR Dvein: mudiyathu hey ava unkita dhn eh phone la enami ipo katuna aprn enkita loosu mari kekura_
😂

[5:35 PM] **You:** Oruku porakinu jolly ah erukiga

[5:35 PM] **Aruna HR Dvein:**
> _You: Oruku porakinu jolly ah erukiga_
Nan unta ipo itha ketan ah

[5:35 PM] **You:** Munik enterpreneur nu potathum amount vanthuruchu nu nanacha

[5:36 PM] **You:**
> _Aruna HR Dvein: Nan unta ipo itha ketan ah_
😂

[5:42 PM] **You:** Yesterday keturuthigala amount

[5:42 PM] **You:** Yeppo soluranu sonaga

[5:44 PM] **Aruna HR Dvein:** epo nu crt ah sollala solluranu matudhn solirukan

[5:44 PM] **You:** Hmm ok

[6:20 PM] **You:** Ennum. Minutes tha

[6:21 PM] **You:** 😂

[6:21 PM] **Aruna HR Dvein:**
> _You: Ennum. Minutes tha_
Puriyala

[6:21 PM] **You:** Ennum 9 minutes tha

[6:21 PM] **You:**
> _Aruna HR Dvein: Puriyala_
10 minutes tha

[6:21 PM] **Aruna HR Dvein:**
> _You: Ennum 9 minutes tha_
Athuvaa

[6:21 PM] **Aruna HR Dvein:** Ama ama

[6:21 PM] **You:**
> _Aruna HR Dvein: Athuvaa_
😂

[6:21 PM] **Aruna HR Dvein:** Robin mess eh pakkave lla

[6:21 PM] **You:** Hmm

---

## September 8, 2026

[8:47 AM] **You:** Kelampiyacha

[8:53 AM] **Aruna HR Dvein:** 1:45ku dhn train da

[8:53 AM] **Aruna HR Dvein:** Nan things eh ipodhn pack panitu iruken

[8:54 AM] **You:**
> _Aruna HR Dvein: 1:45ku dhn train da_
Hayy

[8:54 AM] **You:** One day ah wast pannitiga

[8:54 AM] **You:** Night ah kelampirukalam la

[8:54 AM] **You:** Enarum v2 la eruthurupuga

[8:59 AM] **Aruna HR Dvein:**
> _You: One day ah wast pannitiga_
Idhula enna iruku nan slow va enchi kelambuvan

[8:59 AM] **Aruna HR Dvein:**
> _You: Night ah kelampirukalam la_
Night appa ku pudikathu travel pani varathu

[9:00 AM] **You:** Hmm

[1:47 PM] **Aruna HR Dvein:** Train eritan da

[2:55 PM] **You:** Hmm pathu ponga

[2:55 PM] **You:** Yeppo reach aviga

[2:59 PM] **Aruna HR Dvein:** Sahana vanthurukangala

[3:00 PM] **Aruna HR Dvein:** Ne office reach agitiya

[3:00 PM] **You:** Eppo tha

[3:00 PM] **You:**
> _Aruna HR Dvein: Sahana vanthurukangala_
Illa

[3:00 PM] **You:** Karana akitan

[3:00 PM] **You:** 🫩

[3:00 PM] **Aruna HR Dvein:**
> _You: Karana akitan_
Puriyapq

[3:00 PM] **Aruna HR Dvein:** Puriyala

[3:00 PM] **Aruna HR Dvein:**
> _You: Eppo tha_
Ok da

[3:00 PM] **Aruna HR Dvein:**
> _You: Yeppo reach aviga_
Nan 5clk reach agiduvan

[3:01 PM] **You:**
> _Aruna HR Dvein: Puriyapq_
Karupa akitan nanu

[3:02 PM] **You:**
> _Aruna HR Dvein: Image_
Yenna progress

[3:02 PM] **Aruna HR Dvein:**
> _You: Yenna progress_
Ava kedakura

[3:02 PM] **Aruna HR Dvein:** Enaku matudhn salary podala

[3:02 PM] **Aruna HR Dvein:** Salary varatu paru aprm iruku intha saniyanuku

[3:03 PM] **You:** Sari vetu

[3:03 PM] **You:** Saptu poniya

[3:04 PM] **Aruna HR Dvein:**
> _You: Saptu poniya_
Illa

[3:04 PM] **You:** Y

[3:11 PM] **Aruna HR Dvein:** Trm I have a final round interview session to Robin sir da

[3:13 PM] **You:**
> _Aruna HR Dvein: Image_
Intership matuma

[3:13 PM] **You:**
> _Aruna HR Dvein: Trm I have a final round interview session to Robin sir da_
Tmr ah

[3:13 PM] **You:** Online ah

[3:22 PM] **Aruna HR Dvein:**
> _You: Online ah_
Ama

[3:27 PM] **You:** All the best

[3:27 PM] **You:** Select akiruva ni

[3:27 PM] **You:** Kavala patatha

[3:27 PM] **Aruna HR Dvein:**
> _You: Kavala patatha_
Ok da munik🥺🫂

[3:29 PM] **You:**
> _Aruna HR Dvein: Image_
Pu##

[3:29 PM] **You:** Evagaluka asikama illa ah chi

[3:29 PM] **You:** Avana keta evaga soluran

[3:29 PM] **You:** Evagala keta avana soluraga

[3:30 PM] **You:** Ethu oru polapu

[3:30 PM] **Aruna HR Dvein:** [Voice message]

[3:32 PM] **You:** Niga matum emc la select akita solitu pouru

[3:32 PM] **You:** Salary potatium no problem but sariya niga resaption panala

[3:32 PM] **You:** So na pornu soliru

[3:32 PM] **Aruna HR Dvein:** Adhan panuvan da munik sure ah asingama ketu dhn poguvan

[3:33 PM] **Aruna HR Dvein:** [Voice message]

[3:36 PM] **You:** Unga appa solurathu IT company la

[3:36 PM] **You:** Ethu nighty company

[3:36 PM] **You:** 😂

[3:36 PM] **Aruna HR Dvein:**
> _You: Ethu nighty company_
😹😅

[3:36 PM] **You:** Appo today salary pota 3 school putuchutuvigala

[3:37 PM] **Aruna HR Dvein:** [Voice message]

[3:37 PM] **Aruna HR Dvein:**
> _You: Appo today salary pota 3 school putuchutuvigala_
[Voice message]

[3:37 PM] **Aruna HR Dvein:** [Voice message]

[3:38 PM] **You:** Sir mam kita ketan v2 la salary kekuraganu mam unga kita keka sonaga sir

[3:39 PM] **You:** Epdi matum kelu antha velakenna yethachum reply pannuvan

[3:39 PM] **Aruna HR Dvein:**
> _You: Epdi matum kelu antha velakenna yethachum reply pannuvan_
Avanuku seri avan alu ku seri nalla saave varathu

[3:39 PM] **Aruna HR Dvein:** PaRu

[3:39 PM] **Aruna HR Dvein:** 💯

[3:51 PM] **You:**
> _Aruna HR Dvein: Avanuku seri avan alu ku seri nalla saave varathu_
Vetuga yearium nama sapam veta vetam

[3:51 PM] **You:**
> _Aruna HR Dvein: Image_
Hmm super

[3:52 PM] **Aruna HR Dvein:** [Voice message]

[4:12 PM] **Aruna HR Dvein:** [album message]

[4:12 PM] **Aruna HR Dvein:** [Image]

[4:12 PM] **Aruna HR Dvein:** [Image]

[4:12 PM] **Aruna HR Dvein:** [Image]

[4:21 PM] **You:** Epdilam pesuran

[4:21 PM] **You:** Avan

[4:25 PM] **Aruna HR Dvein:**
> _You: Avan_
Avan kita kasu lla so pichakaran epdlam pesuran

[6:13 PM] **You:**
> _Aruna HR Dvein: Image_
Yepdi pesirukan paaru💦

[6:13 PM] **You:**
> _Aruna HR Dvein: Avan kita kasu lla so pichakaran epdlam pesuran_
Thu

[6:14 PM] **Aruna HR Dvein:** Adhan enaku pudikave lla

[6:14 PM] **Aruna HR Dvein:** Nan v2la solitan da

[6:15 PM] **You:** Evanukalam down akurathuku yelama pannuraga

[6:16 PM] **You:** Poutiya v2 ku

[6:17 PM] **You:** Etha manasula vachukitu TMR best ah pannu interview la select aakitu evaga kannu munati mass kaatu

[6:17 PM] **You:** Tmr ni boold ah pesu interview la

[6:18 PM] **You:** Athula ok anathum select aakititu offer letter vakitu evanuka munati mass pannu

[8:01 PM] **You:** Hello

[8:23 PM] **Aruna HR Dvein:** Yes

[8:23 PM] **Aruna HR Dvein:**
> _You: Athula ok anathum select aakititu offer letter vakitu evanuka munati mass pannu_
Kandipa munik

[8:23 PM] **You:** Hmm nimathiya thukuga

[8:24 PM] **You:** Morning pesalam

[10:17 PM] **Aruna HR Dvein:** Munik

[10:17 PM] **Aruna HR Dvein:** Sahana 4times call panuranga continue va

[10:17 PM] **You:** Hmm soluga

[10:17 PM] **You:**
> _Aruna HR Dvein: Sahana 4times call panuranga continue va_
Keluga

[10:17 PM] **You:** Yenna nu

[10:17 PM] **Aruna HR Dvein:** Venam venam

[10:17 PM] **You:** Keluga

[10:17 PM] **You:**
> _Aruna HR Dvein: Venam venam_
Yeah

[10:17 PM] **Aruna HR Dvein:** Lokesh ethacham solirupan

[10:17 PM] **You:** Avaga Yenna tha soluraganu keluga

[10:17 PM] **Aruna HR Dvein:** So athuku vara venam nu solla edhuvu solluralo enamo

[10:18 PM] **Aruna HR Dvein:** Kekuren iru kjm neram aprm

[10:18 PM] **You:** Avaga Yenna sonalum strong ah pesuga kovama pesathiga

[10:18 PM] **Aruna HR Dvein:**
> _You: Avaga Yenna sonalum strong ah pesuga kovama pesathiga_
Seri da

[10:18 PM] **Aruna HR Dvein:** Pesuren

[10:18 PM] **You:** Hmm

[10:18 PM] **You:** Vai ah putukum

[10:18 PM] **You:** Sahana

[10:18 PM] **You:** Atha kathula vakatha

[10:18 PM] **Aruna HR Dvein:**
> _You: Atha kathula vakatha_
Edhuku unwanted ah ipo pesura ava

[10:18 PM] **Aruna HR Dvein:** Avan cl eh pana ah mata enaku epdlam

[10:19 PM] **You:**
> _Aruna HR Dvein: Edhuku unwanted ah ipo pesura ava_
Avaga pesurathuku matum nama kita erukura answer kutu

[10:19 PM] **Aruna HR Dvein:**
> _You: Avaga pesurathuku matum nama kita erukura answer kutu_
Okiee da

[10:20 PM] **Aruna HR Dvein:** [Voice message]

[10:21 PM] **You:**
> _Aruna HR Dvein: Voice message_
Kuluga yenatha soluraganu

[10:21 PM] **You:** Apdi vara vetam nu sonna okay mam thank you

[10:21 PM] **Aruna HR Dvein:** Ok da pesitu unaku voice note poduren

[10:21 PM] **You:** Yenaku vara vetiya peper yelam proper ah head over panniruga

[10:21 PM] **You:** Na paper poturan

[10:21 PM] **Aruna HR Dvein:**
> _You: Yenaku vara vetiya peper yelam proper ah head over panniruga_
Apdinu solla solluriya ne

[10:22 PM] **You:** Yenaku yevalo days time nu soluga na erukan

[10:22 PM] **Aruna HR Dvein:**
> _You: Yenaku yevalo days time nu soluga na erukan_
Ok da solluren

[10:22 PM] **You:** Athukula yenaku sera vetiya yelam kututhutukanu cool ah pesu

[10:22 PM] **You:** Ethu oru comp pu**

[10:22 PM] **Aruna HR Dvein:**
> _You: Athukula yenaku sera vetiya yelam kututhutukanu cool ah pesu_
Ok iru da pesitu varen

[10:22 PM] **You:** Ethuku payathukitu eruka vetam

[10:22 PM] **Aruna HR Dvein:**
> _You: Ethu oru comp pu**_
Adhan eh

[10:23 PM] **You:** But niga kovam matum pattu answer Sola start panathiga

[10:23 PM] **You:**
> _Aruna HR Dvein: Ok iru da pesitu varen_
Hmm

[10:23 PM] **You:** He'll

[10:23 PM] **You:** Record

[10:23 PM] **You:** Pannikoga

[10:23 PM] **You:** Call ah

[10:23 PM] **You:** Hello

[10:24 PM] **Aruna HR Dvein:**
> _You: But niga kovam matum pattu answer Sola start panathiga_
Ok da nan pesitu solluren

[10:24 PM] **Aruna HR Dvein:**
> _You: Pannikoga_
Done record panikuren

[10:24 PM] **You:** Call recording panna

[10:24 PM] **Aruna HR Dvein:** Pesitu solluren

[10:24 PM] **You:** Avagaluku kekum

[10:24 PM] **Aruna HR Dvein:** Iru

[10:24 PM] **You:** Call recording nu

[10:24 PM] **You:** Atha off paniruga

[10:24 PM] **Aruna HR Dvein:**
> _You: Avagaluku kekum_
[Voice message]

[10:25 PM] **You:**
> _Aruna HR Dvein: Voice message_
Okay

[10:28 PM] **Aruna HR Dvein:** [Voice message]

[10:29 PM] **You:**
> _Aruna HR Dvein: Voice message_
Ama

[10:29 PM] **You:** Eppo kuta thukitanu solalam

[10:29 PM] **You:** But 12 mani varakum tmr reply illa na atha oru koriya pesun

[10:30 PM] **Aruna HR Dvein:** [Voice message]

[10:30 PM] **You:** Tmr morning pesa vetam

[10:30 PM] **You:** Onnum eppo pesuga

[10:30 PM] **You:** Illa na interview mutuchutu pesuga

[10:31 PM] **Aruna HR Dvein:** [Voice message]

[10:31 PM] **You:** Kantipa morning pesuna avaga yethachum sonathu tha otum

[10:31 PM] **Aruna HR Dvein:**
> _You: Kantipa morning pesuna avaga yethachum sonathu tha otum_
[Voice message]

[10:32 PM] **You:** Yenna porutha alavo Yenna na

[10:32 PM] **You:** Eppo pesuga

[10:32 PM] **You:** Ava Yenna Venum nalum pasatum

[10:32 PM] **You:** Veliya vetu kuta thukatum

[10:32 PM] **You:** Eppo unna kaistama pesuna tmr rompa very oota interview attend pannuva

[10:33 PM] **You:** Eva company la eruka kutathu namala asikama pesita nu morning very oota interview la vera level ah pesuviga

[10:33 PM] **Aruna HR Dvein:** [Voice message]

[10:34 PM] **You:** Athatha nanum solura

[10:34 PM] **You:** Pesiru

[10:34 PM] **You:** Appo tha tmr clear mind la interview attend panna mutium

[10:34 PM] **You:** Ni vara vetam nu solita ennum strong ah ni interview attend pannuva

[10:35 PM] **You:** Ethu mnc ah erutha tha ni Ava thituna mind la vachukitu interview sariya panna mutiyathu

[10:35 PM] **You:** Inga eruthu niya pora mind la tha eruka

[10:35 PM] **You:** Aprom Yenna ni Ava kita pesitu morning clear ah interview attend pannu

[10:36 PM] **Aruna HR Dvein:** [Voice message]

[10:38 PM] **You:** Ungaluku yethu thonuthu

[10:38 PM] **You:** Yethu athika %

[10:39 PM] **You:** Brain pecha matum kekathiga heart Yenna soluthu

[10:39 PM] **You:** Antha mutiva yetuga yetha eruthalum parava illa

[10:39 PM] **Aruna HR Dvein:**
> _You: Brain pecha matum kekathiga heart Yenna soluthu_
[Voice message]

[10:39 PM] **You:** Morning pesunalum ok eppo pesunalum ok

[10:39 PM] **You:**
> _Aruna HR Dvein: Voice message_
Appo keturuga

[10:40 PM] **Aruna HR Dvein:** [Voice message]

[10:41 PM] **You:** Okay

[10:41 PM] **You:** Avalotha

[10:41 PM] **You:** Morning kupta pesuga

[10:41 PM] **You:** Illa na interview mutuchutu pesuga

[10:42 PM] **You:** 🫂

[10:42 PM] **You:** Na saami ah kumpututu erukan niga select akiti Ava munatiya happy ah suthanum

[10:42 PM] **Aruna HR Dvein:** [Voice message]

[10:43 PM] **You:**
> _Aruna HR Dvein: Voice message_
Yenna ketalum summa strong ah pesuga

[10:43 PM] **You:** Atha pathi nanakathiga

[10:43 PM] **You:** Inga eruthu pokanum niga so 10 minutes interview la pesita happy ah erukum

[10:44 PM] **Aruna HR Dvein:** [Voice message]

[10:45 PM] **Aruna HR Dvein:**
> _You: Na saami ah kumpututu erukan niga select akiti Ava munatiya happy ah suthanum_
[Voice message]

[10:45 PM] **You:**
> _Aruna HR Dvein: Voice message_
Kantipa🫂🫂

[10:46 PM] **You:** Yenaku tharuchu easy ah unna yetuthupaga nitha thava ilama payaputura

[10:46 PM] **Aruna HR Dvein:**
> _You: Yenaku tharuchu easy ah unna yetuthupaga nitha thava ilama payaputura_
Epd sollura ne

[10:49 PM] **You:** Onnu nala yosuchu paru

[10:49 PM] **You:** Avaga hire panna ready ah erukaka

[10:50 PM] **You:** Nium willing ah eruka

[10:50 PM] **You:** Unkita personal ah pesirukaru

[10:50 PM] **You:** So unna hire pannura idea illa na 2nd round kupta mataga

[10:51 PM] **Aruna HR Dvein:**
> _You: Unkita personal ah pesirukaru_
Ama dhn

[10:51 PM] **You:**
> _Aruna HR Dvein: Ama dhn_
Kantipa ni pesuna select panniruvaga

[10:51 PM] **Aruna HR Dvein:**
> _You: So unna hire pannura idea illa na 2nd round kupta mataga_
[Voice message]

[10:52 PM] **Aruna HR Dvein:**
> _You: Kantipa ni pesuna select panniruvaga_
🥺🫂Thanks da nee navin la irukavum dhn boost ah iruku and feel good ah iruku😭

[10:52 PM] **You:**
> _Aruna HR Dvein: Voice message_
Nana erutha payapata matan because avaga hire panna ready ah erukaka na ennum yenalam solam nu yosuchu vachu best ah soluvan ennum

[10:53 PM] **You:**
> _Aruna HR Dvein: 🥺🫂Thanks da nee navin la irukavum dhn boost ah iruku and feel good ah iruku😭_
Naga yethium yethir pakatha uravo

[10:53 PM] **You:** 🫂

[10:53 PM] **You:** Yengaluku unmya eruthiga niga so nagalum ungaluku life long unnaya erupom

[10:59 PM] **Aruna HR Dvein:**
> _You: Nana erutha payapata matan because avaga hire panna ready ah erukaka na ennum yenalam solam nu yosuchu vachu best ah soluvan ennum_
Enaku kjm solu munik nan ennalam trm prepare ah irukanum nu

[10:59 PM] **Aruna HR Dvein:**
> _You: Naga yethium yethir pakatha uravo_
🥺🫂

[10:59 PM] **Aruna HR Dvein:**
> _You: Yengaluku unmya eruthiga niga so nagalum ungaluku life long unnaya erupom_
🧿😭😭😭😭🫂

[11:03 PM] **You:**
> _Aruna HR Dvein: Enaku kjm solu munik nan ennalam trm prepare ah irukanum nu_
Na anaki sonna question tha eppaum kepaga

[11:04 PM] **You:** Yeah eppo work pakura company la eruthu switch pannuriganu. Intha question vachutha character ah papaka

[11:05 PM] **Aruna HR Dvein:** [Document] JULY_MONTH - Sheet1.pdf

[11:05 PM] **Aruna HR Dvein:** [Document] MAY_MONTH - Sheet1.pdf

[11:05 PM] **Aruna HR Dvein:** [Document] JUN_MONTH_ - Sheet1.pdf

[11:05 PM] **You:** Niga matum nama company ah thappa pesana kantipa select panna mataga

[11:05 PM] **Aruna HR Dvein:**
> _You: Yeah eppo work pakura company la eruthu switch pannuriganu. Intha question vachutha character ah papaka_
Nan Elame Solitan da robin sir ta final round salary pathi dhn irukum pakkalam

[11:05 PM] **Aruna HR Dvein:**
> _You: Niga matum nama company ah thappa pesana kantipa select panna mataga_
Ik da munik

[11:06 PM] **You:**
> _Aruna HR Dvein: Nan Elame Solitan da robin sir ta final round salary pathi dhn irukum pakkalam_
Hmm ok

[11:06 PM] **Aruna HR Dvein:** [Voice message]

[11:06 PM] **You:** Niga select nu oru word soluriga Inga company ah atuchu otikurom😂

[11:07 PM] **Aruna HR Dvein:**
> _You: Niga select nu oru word soluriga Inga company ah atuchu otikurom😂_
🥺🥺🫂☺️☺️

[11:07 PM] **Aruna HR Dvein:** Kandipa nan trm first unaku dhn solluvan munik

[11:07 PM] **You:**
> _Aruna HR Dvein: Voice message_
Avan oru mana ketavan

[11:07 PM] **You:** Avana pathi pesatha

[11:07 PM] **Aruna HR Dvein:**
> _You: Avan oru mana ketavan_
Naiyu erichal panuran

[11:07 PM] **Aruna HR Dvein:**
> _You: Avana pathi pesatha_
Ok da

[11:07 PM] **You:** Ni TMR yenalam sonna select avom nu matum mind set vachuko

[11:07 PM] **Aruna HR Dvein:** Ok nan poitu thoonguren tired ah iruku back pain ah

[11:08 PM] **Aruna HR Dvein:** Enakaga vendiko pls🥺🤌🏻

[11:08 PM] **You:**
> _Aruna HR Dvein: Kandipa nan trm first unaku dhn solluvan munik_
🫂nanum nala pray pannikiran nala news varum nu

[11:08 PM] **Aruna HR Dvein:**
> _You: Ni TMR yenalam sonna select avom nu matum mind set vachuko_
Sure da mrg dhn panuvan ipo nalla thoongiduvan

[11:08 PM] **You:**
> _Aruna HR Dvein: Enakaga vendiko pls🥺🤌🏻_
Na vetitan mass pannurom 💥🙌

[11:08 PM] **Aruna HR Dvein:** Fresh ah prepare panuvan

[11:08 PM] **Aruna HR Dvein:**
> _You: 🫂nanum nala pray pannikiran nala news varum nu_
🥺😭🤌🏻🫂🧿

[11:08 PM] **You:** Na vetuna natakum

[11:08 PM] **Aruna HR Dvein:**
> _You: Na vetitan mass pannurom 💥🙌_
Kandipa da

[11:08 PM] **You:**
> _You: Na vetuna natakum_
Intha word ah napakam vachuko

[11:08 PM] **Aruna HR Dvein:**
> _You: Na vetuna natakum_
🥺🙏🏻✨🪬

[11:08 PM] **You:** Ethu summa word ah solala

[11:08 PM] **Aruna HR Dvein:**
> _You: Ethu summa word ah solala_
Aprm

[11:09 PM] **You:** Yenaku epdi vetuna natakum

[11:09 PM] **Aruna HR Dvein:**
> _You: Yenaku epdi vetuna natakum_
😭🥺🫂Thanks da munik

[11:09 PM] **Aruna HR Dvein:** Trm pakkalam munik🥺❤️🫂

[11:09 PM] **You:** Ni select akura same floor la mass ah walk vara🙌😂eva atha pathu savatum

[11:09 PM] **Aruna HR Dvein:** Neeyu nalla rest edu daily clg la un best ah kudu en side la unaku nalla result nan kudukuren unoda enterprise ku💯

[11:09 PM] **You:**
> _Aruna HR Dvein: Trm pakkalam munik🥺❤️🫂_
Unga call kaka waiting

[11:10 PM] **Aruna HR Dvein:**
> _You: Ni select akura same floor la mass ah walk vara🙌😂eva atha pathu savatum_
🥺😅

[11:10 PM] **Aruna HR Dvein:**
> _You: Unga call kaka waiting_
Kandipa panuran🥺🫂

[11:10 PM] **You:**
> _Aruna HR Dvein: Neeyu nalla rest edu daily clg la un best ah kudu en side la unaku nalla result nan kudukuren unoda enterprise ku💯_
Athu aprom papom first namaku TMR tha focus

[11:10 PM] **Aruna HR Dvein:**
> _You: Athu aprom papom first namaku TMR tha focus_
🫂💯🥺

[11:10 PM] **You:** Tmr same time happy ah pasuvom paaru

[11:10 PM] **Aruna HR Dvein:** Aft holidays meet panalam nama ok va

[11:10 PM] **Aruna HR Dvein:**
> _You: Tmr same time happy ah pasuvom paaru_
🥺🥺🥺🧿😭🫂

[11:10 PM] **Aruna HR Dvein:** Hope da

[11:10 PM] **You:**
> _You: Na vetuna natakum_
Etha marathuratha select akitu intha word ah mention pannu

[11:11 PM] **You:**
> _Aruna HR Dvein: Aft holidays meet panalam nama ok va_
Kantipa🙌🤩

[11:11 PM] **You:** Gn

[11:11 PM] **Aruna HR Dvein:**
> _You: Etha marathuratha select akitu intha word ah mention pannu_
Kandipa da

[11:11 PM] **You:**
> _Aruna HR Dvein: Kandipa da_
🫂gn

[11:11 PM] **Aruna HR Dvein:** Gn✨

---

## September 9, 2026

[7:03 AM] **Aruna HR Dvein:** [Voice message]

[7:04 AM] **Aruna HR Dvein:** [Voice message]

[7:31 AM] **You:** Okay

[8:49 AM] **Aruna HR Dvein:** Sahana ta pesita

[8:51 AM] **You:** Yenna soluchu

[8:52 AM] **Aruna HR Dvein:** [Voice message]

[8:52 AM] **Aruna HR Dvein:** [Voice message]

[8:54 AM] **Aruna HR Dvein:** [Voice message]

[8:54 AM] **You:** _You deleted this message_

[8:56 AM] **You:**
> _Aruna HR Dvein: Voice message_
Okay mostly Yenga kita keka mataga

[8:58 AM] **Aruna HR Dvein:** [Voice message]

[8:59 AM] **You:** Hmm ok

[2:46 PM] **Aruna HR Dvein:** Munik

[2:47 PM] **Aruna HR Dvein:** Nan ipodhn saptu vanthan da cal vanthathu thrla ph room la irundhuchi

[2:47 PM] **Aruna HR Dvein:** Ne saptya

[2:47 PM] **Aruna HR Dvein:** Office vantiya

[2:58 PM] **You:** Hmm

[2:58 PM] **You:** Call pannuga

[3:08 PM] **Aruna HR Dvein:** Ellaru irukanga polla nan evn ah unaku kupduran da

[3:16 PM] **You:**
> _Aruna HR Dvein: Ellaru irukanga polla nan evn ah unaku kupduran da_
Hmm ok

---

## September 10, 2026

[7:28 AM] **You:** Rompa busy pola

[7:41 AM] **You:** Today yenakum aral kum 8.30 ku meeting

[7:42 AM] **You:** Yenna panna poragalo

[8:43 AM] **Aruna HR Dvein:**
> _You: Today yenakum aral kum 8.30 ku meeting_
Enna sollura

[8:43 AM] **Aruna HR Dvein:** Yen meeting ahhh

[8:43 AM] **Aruna HR Dvein:** Gmeet llaiya ?

[8:43 AM] **You:** Arsal nala

[8:43 AM] **You:**
> _Aruna HR Dvein: Gmeet llaiya ?_
Live

[8:43 AM] **Aruna HR Dvein:**
> _You: Arsal nala_
Ama avan enna panaah

[8:43 AM] **You:**
> _Aruna HR Dvein: Ama avan enna panaah_
Sariya panala

[8:44 AM] **Aruna HR Dvein:**
> _You: Sariya panala_
Onu sollura mari lla anaiku dhn apd panaah aprm yennalla pana ah vendiyadhu dhn eh

[8:44 AM] **Aruna HR Dvein:**
> _You: Live_
Office poganum ah ne

[8:44 AM] **You:**
> _Aruna HR Dvein: Office poganum ah ne_
Vanthutan

[8:44 AM] **You:** Unga mam ennum varala

[8:45 AM] **You:** Yenna madam Busy ah erukiga pola

[8:45 AM] **Aruna HR Dvein:**
> _You: Unga mam ennum varala_
Ava vara mata

[8:45 AM] **You:** Ora jolly tha

[8:45 AM] **You:**
> _Aruna HR Dvein: Ava vara mata_
😂

[8:45 AM] **Aruna HR Dvein:**
> _You: Ora jolly tha_
Yen ne vera erichal kelapatha

[8:45 AM] **Aruna HR Dvein:** Solitan

[8:45 AM] **You:** 🫩

[8:45 AM] **Aruna HR Dvein:** Intha saniyanunga inu salary podala

[8:45 AM] **Aruna HR Dvein:** Yesterday uh jayasri 15k kondu vanthuruku

[8:45 AM] **Aruna HR Dvein:** Inu podala

[8:45 AM] **You:**
> _Aruna HR Dvein: Intha saniyanunga inu salary podala_
Avanuka kita porumiya pesi 10 days la kelampiruga

[8:45 AM] **Aruna HR Dvein:** Appa va vachi pesalam iruken

[8:46 AM] **You:**
> _Aruna HR Dvein: Appa va vachi pesalam iruken_
Eppo yethum pana vetam because salary slip vakanum

[8:46 AM] **Aruna HR Dvein:**
> _You: Eppo yethum pana vetam because salary slip vakanum_
Tension ah iruku

[8:47 AM] **You:** Eppo porumiya erutha super ah pouralam

[8:47 AM] **Aruna HR Dvein:** Yesterday athai v2ku pogirunthan evening

[8:48 AM] **Aruna HR Dvein:** Athai paiyan avanuku already oru girl baby iruku

[8:48 AM] **Aruna HR Dvein:** Ipo boy baby born agirukan 26 days achi

[8:48 AM] **Aruna HR Dvein:** Pathutu vanthan

[8:48 AM] **Aruna HR Dvein:** Ivan la yaraiyu apd pakkave matan ahm

[8:48 AM] **You:**
> _Aruna HR Dvein: Image_
Yenna apdi paakura unna

[8:48 AM] **Aruna HR Dvein:** Enaiya dhn epd pathanu Ellaru sonanga

[8:49 AM] **You:**
> _Aruna HR Dvein: Image_
Yaara intha Aunt nu paakuran🤣🤣🤣🤣

[8:49 AM] **Aruna HR Dvein:**
> _You: Yaara intha Aunt nu paakuran🤣🤣🤣🤣_
Nan avanuku chithi da

[8:49 AM] **Aruna HR Dvein:**
> _You: Yenna apdi paakura unna_
Ama ama

[8:49 AM] **You:**
> _Aruna HR Dvein: Nan avanuku chithi da_
Morila chithi tha age la aunty thana🤣🤣🤣🤣🤣

[8:51 AM] **Aruna HR Dvein:**
> _You: Morila chithi tha age la aunty thana🤣🤣🤣🤣🤣_
Podangaaa

[8:52 AM] **You:**
> _Aruna HR Dvein: Podangaaa_
😂hayy

[8:52 AM] **You:** Peah

[8:52 AM] **Aruna HR Dvein:** Edhuku meeting

[8:52 AM] **Aruna HR Dvein:** Ne saptya

[8:52 AM] **Aruna HR Dvein:** Antha naiyu vara mata ne vera

[8:52 AM] **Aruna HR Dvein:** Arasal vantan ah

[8:52 AM] **You:**
> _Aruna HR Dvein: Edhuku meeting_
Arsal om yenaum atika

[8:52 AM] **Aruna HR Dvein:** Yaru iruka ah office la ipo

[8:52 AM] **You:**
> _Aruna HR Dvein: Arasal vantan ah_
Hmm

[8:52 AM] **Aruna HR Dvein:**
> _You: Arsal om yenaum atika_
Unaiya edhuvu solla mata

[8:52 AM] **You:** Avan evalo problem la leave vera keturukan Friday

[8:52 AM] **Aruna HR Dvein:** Avana dhn kepa

[8:53 AM] **You:** 🤣

[8:53 AM] **You:**
> _Aruna HR Dvein: Yaru iruka ah office la ipo_
Nanum Arsal om

[8:53 AM] **Aruna HR Dvein:**
> _You: Avan evalo problem la leave vera keturukan Friday_
Ama ama passport ku poganum ahm

[8:53 AM] **Aruna HR Dvein:** Sona ah anaikae

[8:53 AM] **Aruna HR Dvein:**
> _You: Nanum Arsal om_
Ok da

[8:53 AM] **You:**
> _Aruna HR Dvein: Ama ama passport ku poganum ahm_
😂

[8:53 AM] **Aruna HR Dvein:** Ava la vara mata epdthan wait pana ah vaipa

[8:53 AM] **Aruna HR Dvein:** Naiyu IT mari

[8:53 AM] **You:** Group la theliva potaga no leave nu

[8:53 AM] **Aruna HR Dvein:** Onuthuku lla ava saniyan

[8:53 AM] **Aruna HR Dvein:**
> _You: Group la theliva potaga no leave nu_
Ama ama

[8:53 AM] **You:** Hayy

[8:54 AM] **You:** Sola marathutan

[8:54 AM] **Aruna HR Dvein:**
> _You: Sola marathutan_
Soĺlu da

[8:54 AM] **You:**
> _You: Na vetuna natakum_
.

[8:54 AM] **You:** 🤩

[8:54 AM] **You:** Marathutiya

[8:54 AM] **Aruna HR Dvein:**
> _You: ._
Ama munik nan amma ta ve sona ah unaiya🥺

[8:55 AM] **Aruna HR Dvein:** Avangaluku avlo happy chni evlo periya city la epd oru frnds oru bond ah nu ketanga

[8:55 AM] **Aruna HR Dvein:**
> _You: Marathutiya_
Noway nan marakkave llaiye da

[8:55 AM] **You:** 🤩🙌

[8:56 AM] **You:** Inga pota efforts ah veta athiga anga potu

[8:57 AM] **You:** Unaku nariya benifit ketikum

[8:57 AM] **Aruna HR Dvein:**
> _You: Inga pota efforts ah veta athiga anga potu_
Kandipa munik🥺🫂

[8:57 AM] **Aruna HR Dvein:**
> _You: Unaku nariya benifit ketikum_
Ama da munik

[8:57 AM] **Aruna HR Dvein:** Ipo salary inu varula enna panalam soĺllu

[8:57 AM] **You:** Inga ni yevalo efforts potalum ni onnum panala nu sokuvaga

[8:57 AM] **You:** But anga apdi illa avaga welcome pannuvaga

[8:57 AM] **Aruna HR Dvein:** Aprm payslip la vaanganum

[8:57 AM] **You:**
> _Aruna HR Dvein: Ipo salary inu varula enna panalam soĺllu_
Eppo tha ni puthisali thanama think pananum

[8:58 AM] **You:** Porumiya move pannu

[8:58 AM] **Aruna HR Dvein:**
> _You: But anga apdi illa avaga welcome pannuvaga_
Ama munik avanga wayoff eh spr ah irundhuchi

[8:58 AM] **Aruna HR Dvein:**
> _You: Porumiya move pannu_
Okiee da adhan oru School ah cnfrm panitu salary kekalam iruken

[8:58 AM] **You:** Ni soliru sir yenala mutiya yenaku office side la eruthu yentha problem om illa yenala revanu yetuthu vara mutiyala sir

[8:59 AM] **You:** Na na leave akuran nu porumiya pavama pesu

[8:59 AM] **You:** Appo tha avaga kita vaaka mutium 10days la avagala unna ok poutu va aruna nu yelam proper ah kutupaga

[8:59 AM] **You:** Ni kova pata avanuka kita vaakava mutiyathu

[9:00 AM] **Aruna HR Dvein:**
> _You: Na na leave akuran nu porumiya pavama pesu_
Okiee da

[9:00 AM] **Aruna HR Dvein:**
> _You: Ni kova pata avanuka kita vaakava mutiyathu_
Okiee da

[9:00 AM] **You:**
> _Aruna HR Dvein: Ama munik avanga wayoff eh spr ah irundhuchi_
Hmm ama unota idea yelathium solu ennum avaga company ah periya level ku yetuthu poka unota Brain ah use pannu

[9:00 AM] **Aruna HR Dvein:** Enaku nan apd sona ah prblm dhn salary delay paniruvanva

[9:00 AM] **Aruna HR Dvein:** ADhan yosikuren

[9:01 AM] **You:** Sari atha yosuchu nama panalam

[9:01 AM] **You:** Eppothiku nimathiya eru

[9:02 AM] **Aruna HR Dvein:** Okiee munik

[9:02 AM] **Aruna HR Dvein:** Ava enna meeting la solluranu paru

[9:02 AM] **Aruna HR Dvein:** Aprm pesulam

[9:02 AM] **You:** Once again best wishes for you

[9:02 AM] **You:** 🫂

[9:02 AM] **Aruna HR Dvein:** Nanu enaiku kudiyasaami kovil poren poitu vantu pesuren

[9:02 AM] **You:**
> _You: Once again best wishes for you_
Yesterday pesa mutiyala tired atha

[9:02 AM] **Aruna HR Dvein:**
> _You: Once again best wishes for you_
Thanks alots da😽🧿🫂🥺

[9:03 AM] **You:**
> _Aruna HR Dvein: Nanu enaiku kudiyasaami kovil poren poitu vantu pesuren_
Hmm okay

[9:03 AM] **Aruna HR Dvein:**
> _You: Yesterday pesa mutiyala tired atha_
Okiee munik nanu thmbi ya pakka kelambita pesa mudiyala

[9:03 AM] **You:**
> _Aruna HR Dvein: Thanks alots da😽🧿🫂🥺_
🙌🤩🫂

[9:03 AM] **Aruna HR Dvein:** Munik

[9:03 AM] **You:**
> _Aruna HR Dvein: Okiee munik nanu thmbi ya pakka kelambita pesa mudiyala_
Hmm ok

[9:03 AM] **You:** Free akitu pesuga

[9:03 AM] **Aruna HR Dvein:** Neeyu instagram open pani da

[9:03 AM] **Aruna HR Dvein:**
> _You: Free akitu pesuga_
Sure da

[9:03 AM] **You:**
> _Aruna HR Dvein: Neeyu instagram open pani da_
Vetam😂

[9:03 AM] **Aruna HR Dvein:**
> _You: Vetam😂_
Pana ahh

[9:03 AM] **Aruna HR Dvein:** Enakaga

[9:03 AM] **You:** Ponuga nariya peru aprom propose pannuvaga

[9:03 AM] **You:** Atha na instgram open pannurathu illa

[9:04 AM] **Aruna HR Dvein:**
> _You: Ponuga nariya peru aprom propose pannuvaga_
💦💦open eh ne pana ah venam odipoo

[9:04 AM] **You:**
> _Aruna HR Dvein: 💦💦open eh ne pana ah venam odipoo_
🤣🤣🤣🤣

[9:05 AM] **Aruna HR Dvein:** 💦🤷🏻‍♀️🤦🏻‍♀️

[9:05 AM] **You:** Mutu mutu

[9:05 AM] **Aruna HR Dvein:** Seri seri

[9:06 AM] **Aruna HR Dvein:** Antha manakettava enn solluranu pathutu sollu ne

[9:06 AM] **You:**
> _Aruna HR Dvein: Antha manakettava enn solluranu pathutu sollu ne_
Yaru

[9:09 AM] **Aruna HR Dvein:**
> _You: Yaru_
Sahana

[9:11 AM] **You:** Ennum varala

[9:11 AM] **You:**
> _You: Ennum varala_
Unota sakalathi🤣🤣🤣

[9:12 AM] **Aruna HR Dvein:**
> _You: Unota sakalathi🤣🤣🤣_
Chii karumooo 🤢🤮🤮🤮

[9:12 AM] **Aruna HR Dvein:** Ava alu oru mairandi avanuku la enaaiya vachi pesatha karumo

[9:12 AM] **Aruna HR Dvein:** Onuthuku llatha rendu naiyunga

[9:12 AM] **Aruna HR Dvein:** Adhunga

[9:13 AM] **You:**
> _Aruna HR Dvein: Onuthuku llatha rendu naiyunga_
🤣🤣ni pesa va pa unota owner emc

[9:13 AM] **You:** Yengaluku evaga tha pa owner

[9:13 AM] **You:** 😂

[9:13 AM] **Aruna HR Dvein:**
> _You: 🤣🤣ni pesa va pa unota owner emc_
Robin🙈

[9:13 AM] **Aruna HR Dvein:** COO

[9:14 AM] **Aruna HR Dvein:**
> _You: Yengaluku evaga tha pa owner_
🤩😁

[9:14 AM] **You:**
> _Aruna HR Dvein: Robin🙈_
Ayyo valiyatha pothum

[9:14 AM] **You:** 😂

[10:07 AM] **Aruna HR Dvein:** Ennachi all ok va

[10:12 AM] **You:** Yelam okay tha

[10:12 AM] **You:** Eppo tha mam vanthutukaka

[10:12 AM] **Aruna HR Dvein:**
> _You: Eppo tha mam vanthutukaka_
Ipodhn ah spr uh

[10:12 AM] **Aruna HR Dvein:** Sir uh mess read panitanga

[10:12 AM] **You:**
> _Aruna HR Dvein: Ipodhn ah spr uh_
😂

[10:12 AM] **Aruna HR Dvein:** Nan crt ah dhn eh keturuken

[10:12 AM] **Aruna HR Dvein:** Sir ta

[10:12 AM] **You:**
> _Aruna HR Dvein: Sir uh mess read panitanga_
Mam eppo phone pesikitu veliya ponaga

[10:12 AM] **You:** Appo sir ah tha erukum

[10:13 AM] **Aruna HR Dvein:**
> _You: Appo sir ah tha erukum_
Ama ama crt dhn

[10:13 AM] **You:**
> _Aruna HR Dvein: Nan crt ah dhn eh keturuken_
Hmm correct tha

[10:13 AM] **You:** Avaga yethachum sonalum kova patatha

[10:13 AM] **Aruna HR Dvein:** Unnecessary ah ethacham reason sollunga paren

[10:13 AM] **You:** Okay ah

[10:13 AM] **Aruna HR Dvein:** Ne vena paru

[10:13 AM] **Aruna HR Dvein:**
> _You: Okay ah_
Hm seri da

[10:13 AM] **You:** Ni matum yethum vai veturatha

[10:13 AM] **You:** Because namaku salary slip venum

[10:13 AM] **Aruna HR Dvein:**
> _You: Because namaku salary slip venum_
Ama da crt dhn

[10:14 AM] **Aruna HR Dvein:** [Voice message]

[10:15 AM] **You:** Apdi rompa periya problem achuna apaum niga porumiya eruka

[10:15 AM] **You:** Ungaluku 30k salary varanum

[10:15 AM] **You:** Atha vakitu pouruka

[10:16 AM] **Aruna HR Dvein:** Nan July and Aug la 2 days leave potan 13 13 nu kuduthalu enaku ok dhn da 26k va

[10:16 AM] **Aruna HR Dvein:**
> _You: Apdi rompa periya problem achuna apaum niga porumiya eruka_
Sure da

[10:16 AM] **You:** Hmm ok

[10:16 AM] **You:** Marupatium soluran yethum vai veturathiga

[10:17 AM] **Aruna HR Dvein:**
> _You: Marupatium soluran yethum vai veturathiga_
Vida matan da sure ah

[10:17 AM] **You:** Avaga Yenna venum nalum pesuvaga ungala poka vaikanum na salary vara varakum amithiya eruthutu last la yelam vakunathuku aprom kuta pesikalam

[10:17 AM] **You:**
> _Aruna HR Dvein: Vida matan da sure ah_
Hmm ok

[10:18 AM] **Aruna HR Dvein:**
> _You: Avaga Yenna venum nalum pesuvaga ungala poka vaikanum na salary vara varakum amithiya eruthutu last la yelam vakunathuku aprom kuta pesikalam_
Kandipa da munik

[10:18 AM] **Aruna HR Dvein:** Ne anga Enna pnranu paru

[10:18 AM] **Aruna HR Dvein:** Ph use panatha

[10:18 AM] **Aruna HR Dvein:** Eruma patha soluvan

[10:18 AM] **You:** Because evaga Yenna Venum nalum soluvaga .. emc kita ungala pathi thappa kuta soluvaga. Evaga work ah pakala but naga salary kututhom nu

[10:18 AM] **You:**
> _Aruna HR Dvein: Eruma patha soluvan_
Hmm ok

[10:18 AM] **You:** Evening pesalan

[10:18 AM] **Aruna HR Dvein:**
> _You: Because evaga Yenna Venum nalum soluvaga .. emc kita ungala pathi thappa kuta soluvaga. Evaga work ah pakala but naga salary kututhom nu_
Nan record send panuvan and Robin ta elame soliduvan apd matu ivanunga ethacham sona ah

[10:19 AM] **Aruna HR Dvein:** Robin ta main ah enaku salary varula enaku growth llama dhn na Vera company pathanu soliduvan

[10:29 AM] **You:** Hmm

[10:29 AM] **You:** Yethum reply pannirukara unga sir

[10:29 AM] **Aruna HR Dvein:** Mam matum dhn paniruku

[10:40 AM] **You:**
> _Aruna HR Dvein: Image_
Appo tha sir ku call panaga

[10:49 AM] **Aruna HR Dvein:**
> _You: Appo tha sir ku call panaga_
Adhan polla

[11:11 AM] **You:** Hmm ama

[11:11 AM] **You:** 11:11

[11:11 AM] **You:** Time

[12:04 PM] **Aruna HR Dvein:** 🪬🪬🪬🪬🧿🤌🏻

[12:05 PM] **Aruna HR Dvein:** Meeting pocha?

[1:41 PM] **You:** Just solitaga nala yetuga nu

[3:33 PM] **Aruna HR Dvein:**
> _You: Just solitaga nala yetuga nu_
Ok ok da

[3:33 PM] **Aruna HR Dvein:** Jayasri edho Aruna nu mess panuchi

[3:34 PM] **Aruna HR Dvein:** Ana nan reply paniyu athu response panala

[3:34 PM] **Aruna HR Dvein:** Enna panura ava

[5:39 PM] **You:** Athu suthikitu eruku

[6:03 PM] **Aruna HR Dvein:** Munik

[6:03 PM] **Aruna HR Dvein:** Enaku epodhn salary poduvangalam thrla

[6:03 PM] **Aruna HR Dvein:** Tension agudhu

[6:15 PM] **You:**
> _Aruna HR Dvein: Enaku epodhn salary poduvangalam thrla_
😕

[6:28 PM] **Aruna HR Dvein:** Nallave iruka matanga nasama poravanunha

[6:28 PM] **You:**
> _Aruna HR Dvein: Nallave iruka matanga nasama poravanunha_
Yarium apdi solatha

[6:29 PM] **You:** Avaga pannurathuku avaga anupavipaga

[6:34 PM] **Aruna HR Dvein:** [Voice message]

[6:35 PM] **You:**
> _Aruna HR Dvein: Voice message_
Pls ethu god ungala sothikiraru

[6:35 PM] **You:** Niga intha time la tha porumiya erukanum

[6:54 PM] **Aruna HR Dvein:** 🥺🥺🥺

[6:54 PM] **You:** Ama

[6:55 PM] **You:** Eppo ni panna vetiyathu yelam yanna natakuthunu porumiya patha pothum

[8:29 PM] **Aruna HR Dvein:** [Sticker]

[8:30 PM] **You:** [Sticker]

[8:30 PM] **Aruna HR Dvein:** Saptya da

[8:32 PM] **You:** Illa

[8:32 PM] **You:** Enitha

[8:32 PM] **You:** Ni

[8:55 PM] **Aruna HR Dvein:** Ipodhn da saptan Saptu amma ku help panitu vantha

[8:56 PM] **Aruna HR Dvein:** Dress madichan, vessel wash pana ah

[8:56 PM] **Aruna HR Dvein:** Kitchen ah clean panitu ipodhn okanthan da

[9:33 PM] **You:** 😂Yenna ponnu panna vetiya work ni pannura

[9:44 PM] **Aruna HR Dvein:**
> _You: 😂Yenna ponnu panna vetiya work ni pannura_
Oduu

[9:44 PM] **You:** 😂

[9:45 PM] **You:** Wednesday jayasree treat

[9:46 PM] **Aruna HR Dvein:** Wednesday vanthuruvan nanu

[9:46 PM] **Aruna HR Dvein:** Sunday Bdy va avaluku?

[9:47 PM] **You:**
> _Aruna HR Dvein: Sunday Bdy va avaluku?_
Ama

[9:49 PM] **Aruna HR Dvein:**
> _You: Ama_
Ok xa

[9:49 PM] **Aruna HR Dvein:** Da

[9:55 PM] **You:** Hmm

[11:07 PM] **Aruna HR Dvein:** https://www.instagram.com/reel/DcvWP-1TvYd/?stkn=cGxiZ2QyN2w3dXIy

---

## September 11, 2026

[7:20 AM] **You:**
> _Aruna HR Dvein: https://www.instagram.com/reel/DcvWP-1TvYd/?stkn=cGxiZ2QyN2w3dXIy_
💯💯💯💯🤣🤣🤣🤣🤣🤣

[7:12 PM] **Aruna HR Dvein:** Nalla pocha day?

[7:22 PM] **You:** Jaya sree ku phone

[7:22 PM] **You:** One plus

[7:22 PM] **You:** 30k

[7:31 PM] **Aruna HR Dvein:** Navin sona ah

[7:31 PM] **You:** Road la vachu yethachum profesionals cake cut pannuvagala

[7:31 PM] **You:** 🤦‍♂️

[7:31 PM] **You:** Kocham kuta mechuruty ah illa

[7:33 PM] **Aruna HR Dvein:** [Voice message]

[7:33 PM] **You:** [Voice message]

[7:37 PM] **Aruna HR Dvein:** [Voice message]

[8:44 PM] **You:** Etha pathitha nanum navin om unga kita pesanum

[8:44 PM] **You:** Wednesday

[8:44 PM] **You:** Selvamani kita soliruga

[8:44 PM] **Aruna HR Dvein:**
> _You: Wednesday_
Enna pesanu sollu

[8:44 PM] **Aruna HR Dvein:**
> _You: Selvamani kita soliruga_
Ok da

[8:44 PM] **You:** Naga yethum Avan kita marachathu ill

[8:45 PM] **You:** First time avakita marakirom

[8:45 PM] **Aruna HR Dvein:**
> _You: First time avakita marakirom_
Solluren munik nan enna ninaicha nerula soli ungala veliya kuptu pogalam ninaichan

[8:46 PM] **You:**
> _Aruna HR Dvein: Solluren munik nan enna ninaicha nerula soli ungala veliya kuptu pogalam ninaichan_
Okay appo soluga

[8:46 PM] **You:**
> _Aruna HR Dvein: Enna pesanu sollu_
Niga Yenna next move pananum nu

[8:47 PM] **Aruna HR Dvein:**
> _You: Niga Yenna next move pananum nu_
Atha first sollunga da plz

[8:47 PM] **Aruna HR Dvein:** Pressure agudhu

[8:48 PM] **Aruna HR Dvein:** [Voice message]

[8:50 PM] **You:** [Voice message]

[8:52 PM] **Aruna HR Dvein:**
> _You: Voice message_
Ok da nan kekuren ennanu trm va pesuren robin sir ta

[8:52 PM] **Aruna HR Dvein:** Kekuren

[8:52 PM] **You:** Hmm ok

[8:52 PM] **You:** Epaum soluran porumatha mukiyam

[8:53 PM] **Aruna HR Dvein:**
> _You: Epaum soluran porumatha mukiyam_
Apdthan iruken da

[8:54 PM] **Aruna HR Dvein:** Ana entha employee July month ku kudukama irupanga sollu

[8:56 PM] **You:** Nama pesurathuku time varum

[8:56 PM] **You:** Appo pesuvom

[8:57 PM] **Aruna HR Dvein:** Kandipa pesuvan da

[9:06 PM] **You:** 🩷

[11:24 PM] **You:** Hospital poniya

[11:37 PM] **Aruna HR Dvein:**
> _You: Hospital poniya_
Illaiye

[11:37 PM] **Aruna HR Dvein:** Ana apo apo valikudhu pakkanum enanu

[11:38 PM] **You:** Gas ah eruka pokuthu

[11:38 PM] **You:** Yethukum check panniko

[11:42 PM] **Aruna HR Dvein:** Ok munik

[11:42 PM] **Aruna HR Dvein:** Adhan nanu ninaichan

[11:45 PM] **You:** Hmm

[11:52 PM] **Aruna HR Dvein:** Tuesday ve vanthuruviyq

[11:52 PM] **Aruna HR Dvein:** Oorla irundhu

[11:52 PM] **Aruna HR Dvein:** ?

[11:53 PM] **You:** Wednesday morning tha varuvan

[11:53 PM] **You:**
> _Aruna HR Dvein: ?_
Yeah

[11:53 PM] **You:** Ni

[11:53 PM] **Aruna HR Dvein:**
> _You: Ni_
Tuesday ve

[11:53 PM] **You:** Hmm ok

---

## September 13, 2026

[4:27 PM] **Aruna HR Dvein:**
> _You: Video_
😍

[5:10 PM] **You:** [Sticker]

[8:04 PM] **Aruna HR Dvein:** [Sticker]

[8:29 PM] **You:** [Sticker]

[8:30 PM] **Aruna HR Dvein:** Enna pnra munik

[9:00 PM] **You:** Saptu erukan

[9:00 PM] **You:** Ni

[9:01 PM] **You:**
> _Aruna HR Dvein: Enna pnra munik_
Epdi kekum pothu happy 🫂🩷🤩

[9:01 PM] **Aruna HR Dvein:**
> _You: Epdi kekum pothu happy 🫂🩷🤩_
Yen apd sollura

[9:01 PM] **You:** Alone ah erukum pothu intha word la. Golden words

[9:02 PM] **You:**
> _Aruna HR Dvein: Video_
Saptu saptu Yenna sapatu

[9:02 PM] **You:** Munati yaru kalu neeti okathuruka ?

[9:13 PM] **Aruna HR Dvein:**
> _You: Alone ah erukum pothu intha word la. Golden words_
Yen apd feel panura ne

[9:13 PM] **Aruna HR Dvein:**
> _You: Munati yaru kalu neeti okathuruka ?_
Patti da

[9:13 PM] **Aruna HR Dvein:**
> _You: Saptu saptu Yenna sapatu_
Briyani dhn

[9:35 PM] **You:**
> _Aruna HR Dvein: Yen apd feel panura ne_
Atha vetuga

[9:35 PM] **You:**
> _Aruna HR Dvein: Briyani dhn_
Nala saptu

[9:35 PM] **You:**
> _Aruna HR Dvein: Patti da_
Ketatha solu dorling

[9:36 PM] **You:** Unga paati dorling ah

[9:38 PM] **Aruna HR Dvein:**
> _You: Unga paati dorling ah_
Yen apd sollura

[9:38 PM] **Aruna HR Dvein:**
> _You: Ketatha solu dorling_
Kandipa solluren munik

[9:39 PM] **Aruna HR Dvein:** V2la amma akka ta lam unaiya pathi navin pathi dhn pesikitae iruntha nanu

[9:39 PM] **Aruna HR Dvein:**
> _You: Nala saptu_
Saptan da

[9:39 PM] **Aruna HR Dvein:** Ne sapdu nalla

[9:39 PM] **Aruna HR Dvein:** Hostel vantha dhn food nallave lla

[10:06 PM] **You:**
> _Aruna HR Dvein: V2la amma akka ta lam unaiya pathi navin pathi dhn pesikitae iruntha nanu_
Apdiya yenanu

[10:06 PM] **You:**
> _Aruna HR Dvein: Hostel vantha dhn food nallave lla_
Ama eppo tha nala saptanum

[10:06 PM] **You:** 🤩

[10:09 PM] **Aruna HR Dvein:**
> _You: Ama eppo tha nala saptanum_
Ama ama

[10:09 PM] **Aruna HR Dvein:**
> _You: Apdiya yenanu_
Solluren nan

[10:11 PM] **You:** Hmm ok

---

## September 14, 2026

[11:21 AM] **You:** Hii

[11:24 AM] **Aruna HR Dvein:** Hiii

[11:31 AM] **You:** Yepdi pokuthu vinayaga sathurthi

[12:39 PM] **You:**
> _Aruna HR Dvein: Image_
🔥

[1:08 PM] **You:** Kanathula Yenna thalumpu

[1:08 PM] **You:** 🙄

[1:46 PM] **Aruna HR Dvein:**
> _You: Kanathula Yenna thalumpu_
[Voice message]

[1:46 PM] **Aruna HR Dvein:**
> _You: Kanathula Yenna thalumpu_
[album message]

[1:46 PM] **Aruna HR Dvein:**
> _You: Kanathula Yenna thalumpu_
[Image]

[1:46 PM] **Aruna HR Dvein:**
> _You: Kanathula Yenna thalumpu_
[Image]

[1:46 PM] **Aruna HR Dvein:**
> _You: Kanathula Yenna thalumpu_
[Image]

[1:46 PM] **Aruna HR Dvein:** [unknown message]

[1:46 PM] **Aruna HR Dvein:** [unknown message]

[1:46 PM] **Aruna HR Dvein:** [unknown message]

[2:33 PM] **You:** Vinayagar ah kanom yelam green ah eruku 🤣🤣🤣🤣

[2:42 PM] **Aruna HR Dvein:** Pehh

[2:42 PM] **Aruna HR Dvein:** Silver da athu

[2:45 PM] **You:** 😂😂

[5:05 PM] **You:** Unga friend yethachum sonaara

[6:00 PM] **Aruna HR Dvein:**
> _You: Unga friend yethachum sonaara_
Yaru

[6:00 PM] **You:** Amount ketom la

[6:00 PM] **You:** Avaga

[6:02 PM] **Aruna HR Dvein:** Nan suma avan ta pesuna xams pogudhunu sonaah adhan disturb panala

[6:02 PM] **Aruna HR Dvein:** Nan nit ketu solluran da

[6:02 PM] **Aruna HR Dvein:** Munik

[6:09 PM] **You:** Hmm ok thanks u

[8:32 PM] **You:** Kanna ag

[8:33 PM] **You:** 🤣

[8:36 PM] **Aruna HR Dvein:** Avan apdthan enaiya pesuvan epovum eh

[9:11 PM] **You:** 😂

[9:12 PM] **You:** Ponugana yelam porupa erukanuga

[10:29 PM] **Aruna HR Dvein:**
> _You: Ponugana yelam porupa erukanuga_
Apdlam lla avan enga relative paiyan closed relative Vera adhan epovu kjm respectful ah pesuvan enkita

[10:45 PM] **You:** 😂

---

## September 15, 2026

[9:16 AM] **Aruna HR Dvein:** Alpha College date solitanga da

[9:16 AM] **Aruna HR Dvein:** IV visit vanthangala avanga

[9:16 AM] **Aruna HR Dvein:** 18th ahn

[9:17 AM] **Aruna HR Dvein:** One day workshop

[9:17 AM] **You:** Friday ah

[9:17 AM] **You:** Hmm ok

[9:17 AM] **Aruna HR Dvein:**
> _You: Friday ah_
Hm ama

[9:18 AM] **Aruna HR Dvein:** Nan eh Thursday dhn varuvan da

[9:18 AM] **You:**
> _Aruna HR Dvein: Nan eh Thursday dhn varuvan da_
Tmr varaliya

[9:18 AM] **You:** Today leave thana

[9:18 AM] **You:** Office

[9:19 AM] **Aruna HR Dvein:** [Voice message]

[9:19 AM] **Aruna HR Dvein:** [Voice message]

[9:20 AM] **You:** Kovil la erukigala

[9:27 AM] **Aruna HR Dvein:** [Voice message]

[10:21 AM] **You:** Yengaum pola

[10:21 AM] **You:** Rompa alachal

[10:21 AM] **You:** Amount ready panna

[12:23 PM] **Aruna HR Dvein:** Course pasanga balance panitanga munik 8k

[12:25 PM] **You:** Okay

[12:25 PM] **You:** Super

[12:25 PM] **Aruna HR Dvein:** Intha alu la waste uh

[12:25 PM] **Aruna HR Dvein:** Iva athuku mela

[12:42 PM] **You:**
> _Aruna HR Dvein: Image_
Pathutu reply panala ah avan

[12:42 PM] **Aruna HR Dvein:**
> _You: Pathutu reply panala ah avan_
Ama munik

[12:51 PM] **Aruna HR Dvein:** https://www.instagram.com/reel/Dc-QKixz1Om/?stkn=MXgwYnJtMmFnZXNxZA==

[1:27 PM] **You:**
> _Aruna HR Dvein: Image_
Course pasagala

[1:27 PM] **You:**
> _Aruna HR Dvein: https://www.instagram.com/reel/Dc-QKixz1Om/?stkn=MXgwYnJtMmFnZXNxZA==_
😂

[1:42 PM] **You:** Salary potanugala

[1:43 PM] **Aruna HR Dvein:**
> _You: Salary potanugala_
Onu lla da

[2:02 PM] **You:** Ketiya

[2:11 PM] **Aruna HR Dvein:** Inu podave lla da

[2:28 PM] **You:** Hmm

[2:28 PM] **You:** Saptacha

[3:29 PM] **Aruna HR Dvein:** Saptan da

[3:29 PM] **Aruna HR Dvein:** Ne saptya munik

[3:39 PM] **You:**
> _Aruna HR Dvein: Ne saptya munik_
Hmm now

[3:39 PM] **Aruna HR Dvein:** Ok da

[3:40 PM] **You:** Hmm

[5:52 PM] **Aruna HR Dvein:** _This message was deleted_

[5:52 PM] **Aruna HR Dvein:** _This message was deleted_

[5:52 PM] **Aruna HR Dvein:** _This message was deleted_

[5:56 PM] **Aruna HR Dvein:** _This message was deleted_

[5:56 PM] **Aruna HR Dvein:** _This message was deleted_

[5:56 PM] **Aruna HR Dvein:** _This message was deleted_

[6:04 PM] **Aruna HR Dvein:** _This message was deleted_

[6:04 PM] **Aruna HR Dvein:** _This message was deleted_

[6:04 PM] **Aruna HR Dvein:** _This message was deleted_

[6:06 PM] **Aruna HR Dvein:** _This message was deleted_

[6:30 PM] **You:** Yenna tha solav varaga

[6:30 PM] **You:** Salary varuma varatha

[6:35 PM] **Aruna HR Dvein:** Enaiku cls llaiya

[6:35 PM] **Aruna HR Dvein:** Nan enna mairu*** ku mail podanu sollu munik

[6:37 PM] **Aruna HR Dvein:** August ku salary vanthurucha unak

[6:37 PM] **Aruna HR Dvein:** Unaku?

---

## September 16, 2026

[6:39 AM] **You:** Eppo tha pg vantha

[6:39 AM] **You:** Balance illa

[9:02 AM] **Aruna HR Dvein:** Ok ok da avlo neram travel ah panuva

[9:28 AM] **You:** Ama night 7 la eruthu morning 5 varakum

[9:29 AM] **Aruna HR Dvein:**
> _You: Ama night 7 la eruthu morning 5 varakum_
Haiyoo evlo long ah

[9:29 AM] **Aruna HR Dvein:** EBhaaa

[11:18 AM] **You:** Ama

[11:18 AM] **You:** 🥲

[12:12 PM] **Aruna HR Dvein:** Office la dhn eh da iruka ah

[12:16 PM] **You:** Ama

[12:32 PM] **Aruna HR Dvein:** Okiee da

[12:33 PM] **You:** Niga

[12:33 PM] **Aruna HR Dvein:** [Forwarded] [Image] Walk in Interview

[12:33 PM] **Aruna HR Dvein:** [Forwarded] [Image] Accenture is Hiring Freshers

[12:49 PM] **Aruna HR Dvein:** Smart india hackathon ku oru prototype pannanum adhukku indha topic eduthurukko ka ,National Weather Big Data Analytics Platform. idhula edhachi idea irukkuma ka

[12:49 PM] **Aruna HR Dvein:** Idhu oru paiyan kekuran enaku idea lla ungaluku therinja sollunga da thmbi's

[12:49 PM] **Aruna HR Dvein:** Grp la potan ne pakkala kjm pathu sollu da

[2:06 PM] **You:** Okay paathu soluran

[2:19 PM] **Aruna HR Dvein:** [Voice message]

[2:25 PM] **You:** Ora session ah

[2:25 PM] **You:** 9.30 to 2.30

[2:45 PM] **You:** _You deleted this message_

[2:48 PM] **You:** [Image]

[4:15 PM] **Aruna HR Dvein:** [Forwarded] [Audio]

[4:15 PM] **Aruna HR Dvein:** [Forwarded] [Audio]

[4:19 PM] **You:** Okay wait

[4:22 PM] **Aruna HR Dvein:**
> _You: Okay wait_
[Voice message]

[4:30 PM] **You:** [Voice message]

[4:32 PM] **Aruna HR Dvein:** [Voice message]

[4:43 PM] **You:** [Voice message]

[4:51 PM] **Aruna HR Dvein:** Ok munik sir

[5:07 PM] **You:** 😂

[5:34 PM] **Aruna HR Dvein:** Topic mam ta solidu da

[5:59 PM] **You:** Okay

[10:30 PM] **You:** Hiii

[10:31 PM] **Aruna HR Dvein:** Hiiii

[10:32 PM] **You:** Saptacha

[10:50 PM] **Aruna HR Dvein:** Saptan da

[10:50 PM] **Aruna HR Dvein:** Ipodhn paduthan

[10:50 PM] **Aruna HR Dvein:** Ne saptya munik

[10:50 PM] **You:**
> _Aruna HR Dvein: Saptan da_
Hmm

[10:50 PM] **You:** Sorry

[10:50 PM] **You:** Student wait pannitu eruthaga

[10:50 PM] **You:** Atha

[10:50 PM] **You:** Call pesa mutiyala

[10:51 PM] **Aruna HR Dvein:**
> _You: Student wait pannitu eruthaga_
Sry da nan dhn sry kekanum

[10:51 PM] **Aruna HR Dvein:** SRY

[10:51 PM] **Aruna HR Dvein:** Disturb panitan

[10:51 PM] **You:**
> _Aruna HR Dvein: Sry da nan dhn sry kekanum_
Apdilam illa

[10:51 PM] **You:** Sari yeppo treat

[10:51 PM] **You:** [Sticker]

[10:51 PM] **Aruna HR Dvein:**
> _You: Sari yeppo treat_
Kandipa vaikuren munik unaku navin selva ku

[10:51 PM] **Aruna HR Dvein:** 🥺🧿🫂

[10:52 PM] **You:**
> _Aruna HR Dvein: Kandipa vaikuren munik unaku navin selva ku_
BBQ nation polama😁

[10:52 PM] **Aruna HR Dvein:** En Kudave irupala ne?🥺🫴🏻

[10:52 PM] **Aruna HR Dvein:**
> _You: BBQ nation polama😁_
Avlo kasu llainga sir ehh

[10:52 PM] **Aruna HR Dvein:** But one day I will

[10:53 PM] **You:** Anga poe niga ungalukunu oru atiyalam create pannanum ok ah normal ah job ku nu poka kutathu .. ethu ungaluku best opportunity

[10:53 PM] **You:**
> _Aruna HR Dvein: En Kudave irupala ne?🥺🫴🏻_
🫂kantipa erupan ethula Yenna doubt

[10:53 PM] **Aruna HR Dvein:**
> _You: Anga poe niga ungalukunu oru atiyalam create pannanum ok ah normal ah job ku nu poka kutathu .. ethu ungaluku best opportunity_
Kandipa munik🥺🫂enoda best ah kudupan

[10:54 PM] **You:**
> _Aruna HR Dvein: But one day I will_
Sure 🙌🫂

[10:54 PM] **Aruna HR Dvein:**
> _You: 🫂kantipa erupan ethula Yenna doubt_
🥺🥺🥺

[10:54 PM] **Aruna HR Dvein:**
> _You: Sure 🙌🫂_
🥰🎉

[10:54 PM] **You:**
> _Aruna HR Dvein: Kandipa munik🥺🫂enoda best ah kudupan_
But inga erutha mathiri chinna vesayathukalam muchiya thuka kutathu

[10:54 PM] **Aruna HR Dvein:**
> _You: But inga erutha mathiri chinna vesayathukalam muchiya thuka kutathu_
Hey loosu nengalam enaku comfortable person anga apd irukathu da

[10:54 PM] **Aruna HR Dvein:** Ik

[10:55 PM] **You:** Atha Mathiri enjoy this moment.. Dvein ah nanachu epdi oru alakana moment ah miss panniratha

[10:55 PM] **You:**
> _Aruna HR Dvein: Hey loosu nengalam enaku comfortable person anga apd irukathu da_
Okay okay 😂🙌

[10:55 PM] **Aruna HR Dvein:**
> _You: Atha Mathiri enjoy this moment.. Dvein ah nanachu epdi oru alakana moment ah miss panniratha_
Kandipa antha thappa pana ah matan da

[10:55 PM] **You:** Yenaku very proud 🫂

[10:55 PM] **Aruna HR Dvein:**
> _You: Okay okay 😂🙌_
I'm gonna miss you all🥺
We 4 forever 🧿😭

[10:56 PM] **Aruna HR Dvein:**
> _You: Yenaku very proud 🫂_
🥺🥺🪬🧿🫂

[10:56 PM] **You:** Ni epdi periya company porathu

[10:56 PM] **Aruna HR Dvein:** Enaku mind la nallapadiya veliya vanthuranum dvein la irundhu

[10:56 PM] **Aruna HR Dvein:**
> _You: Ni epdi periya company porathu_
🥺🥺🫂Thanks alots da

[10:56 PM] **You:**
> _Aruna HR Dvein: Enaku mind la nallapadiya veliya vanthuranum dvein la irundhu_
Athalam vanthuralam

[10:57 PM] **Aruna HR Dvein:**
> _You: Athalam vanthuralam_
🥺

[10:57 PM] **Aruna HR Dvein:** Enga amma la apd thituranga sahana va

[10:58 PM] **You:**
> _Aruna HR Dvein: Enga amma la apd thituranga sahana va_
😂

[10:58 PM] **Aruna HR Dvein:** Mathavanga ullachatha epd panura

[10:58 PM] **Aruna HR Dvein:** Nasama ponavanu soli

[10:58 PM] **You:**
> _Aruna HR Dvein: Enga amma la apd thituranga sahana va_
Unga sister thana😂😂

[10:58 PM] **Aruna HR Dvein:**
> _You: Unga sister thana😂😂_
Enga amma da

[10:58 PM] **You:**
> _Aruna HR Dvein: Nasama ponavanu soli_
Vetuga

[10:58 PM] **Aruna HR Dvein:** Enga akka uh dhn pesuna nalla

[10:58 PM] **You:**
> _Aruna HR Dvein: Enga amma da_
Sahana unga akka thana

[10:58 PM] **You:** 🤣

[10:58 PM] **You:** Atha sonna

[10:58 PM] **Aruna HR Dvein:**
> _You: Sahana unga akka thana_
Ava la sethu poga naiyu

[10:58 PM] **Aruna HR Dvein:**
> _You: Atha sonna_
[Sticker]

[10:58 PM] **Aruna HR Dvein:** [Sticker]

[10:59 PM] **You:** Unga mama lokesh 🤣🤣🤣

[10:59 PM] **You:**
> _Aruna HR Dvein: Ava la sethu poga naiyu_
Pavam vetuga

[10:59 PM] **Aruna HR Dvein:**
> _You: Unga mama lokesh 🤣🤣🤣_
[Sticker]

[10:59 PM] **Aruna HR Dvein:**
> _You: Pavam vetuga_
Ethey pavaam ah

[10:59 PM] **You:** [Sticker]

[11:00 PM] **You:** Unga mama kochuka poraru loki

[11:00 PM] **Aruna HR Dvein:** [Voice message]

[11:00 PM] **Aruna HR Dvein:**
> _You: Unga mama kochuka poraru loki_
[Voice message]

[11:00 PM] **You:**
> _Aruna HR Dvein: Voice message_
Okay

[11:02 PM] **Aruna HR Dvein:** Solitan da

[11:02 PM] **You:** Okay

[11:02 PM] **You:** Pathukalam

[11:02 PM] **You:** Vaaga

[11:02 PM] **You:** [Sticker]

[11:04 PM] **Aruna HR Dvein:** Trm pesitu solluren enna panalam nu solitu

[11:04 PM] **You:** Okay

[11:04 PM] **Aruna HR Dvein:** Trm 8clk train

[11:04 PM] **Aruna HR Dvein:** Nan thoonguren da neeyu rest edu

[11:04 PM] **Aruna HR Dvein:** Gn Tata✨

[11:05 PM] **You:**
> _Aruna HR Dvein: Nan thoonguren da neeyu rest edu_
Okay gn 🩷

---

## September 17, 2026

[8:08 AM] **You:** Oiii

[8:08 AM] **You:** 🫂

[8:09 AM] **You:** Train yeritiya

[8:09 AM] **You:** Saptiya

[8:09 AM] **You:** Water yetuthukitiya

[8:10 AM] **Aruna HR Dvein:**
> _You: Train yeritiya_
Ipodhn munik

[8:11 AM] **Aruna HR Dvein:**
> _You: Saptiya_
Saptan

[8:11 AM] **Aruna HR Dvein:**
> _You: Water yetuthukitiya_
Elame iruku

[8:11 AM] **Aruna HR Dvein:**
> _You: 🫂_
🫂✨

[8:11 AM] **You:**
> _Aruna HR Dvein: Elame iruku_
Hmm ok paathu va🫂

[8:19 AM] **Aruna HR Dvein:** Sure da

[8:20 AM] **You:** 🫂

[8:33 AM] **Aruna HR Dvein:** [Image] Logesh stry da

[9:16 AM] **You:**
> _Aruna HR Dvein: Image: Logesh stry da_
Unga mama

[9:16 AM] **You:** 😂

[9:17 AM] **Aruna HR Dvein:**
> _You: Unga mama_
Serupala adipan nerula vantha

[9:17 AM] **You:** 🤣

[9:17 AM] **Aruna HR Dvein:** [Sticker]

[9:18 AM] **You:** [Sticker]

[9:20 AM] **Aruna HR Dvein:** 😅🤪😹

[9:20 AM] **You:** Saturday movies polama

[9:20 AM] **You:** Night

[9:21 AM] **Aruna HR Dvein:** Enna movie

[9:21 AM] **You:**
> _Aruna HR Dvein: Enna movie_
Movie name sonatha varuvigalo

[9:22 AM] **You:** 500 kai la eruku yenaku account la venum

[9:22 AM] **You:** Eppo

[9:22 AM] **You:** Yenaku maathi vetuga

[9:22 AM] **Aruna HR Dvein:**
> _You: 500 kai la eruku yenaku account la venum_
Nan eh kai la dhn vachiruken cash ah

[9:22 AM] **Aruna HR Dvein:** Gpay la lla

[9:22 AM] **Aruna HR Dvein:** 89 dhn iruku

[9:22 AM] **Aruna HR Dvein:**
> _You: Movie name sonatha varuvigalo_
Ama ama

[9:26 AM] **You:**
> _Aruna HR Dvein: 89 dhn iruku_
Sari

[9:33 AM] **Aruna HR Dvein:** Villupuram ehh vantan

[9:33 AM] **You:**
> _Aruna HR Dvein: Villupuram ehh vantan_
Hmm va va

[9:34 AM] **You:** Mass pannurom

[9:34 AM] **Aruna HR Dvein:**
> _You: Mass pannurom_
Mass ah

[9:34 AM] **Aruna HR Dvein:** ENaku office varave pudikala da🥲😤

[9:34 AM] **You:** S

[9:34 AM] **You:**
> _Aruna HR Dvein: ENaku office varave pudikala da🥲😤_
Unga office ku po

[9:34 AM] **You:** Direct ah

[9:34 AM] **Aruna HR Dvein:**
> _You: Direct ah_
Hahaba

[9:34 AM] **You:** Unga office periya office la😂

[9:34 AM] **Aruna HR Dvein:** Ellaru vantangala

[9:34 AM] **Aruna HR Dvein:**
> _You: Unga office periya office la😂_
😁

[9:34 AM] **You:**
> _Aruna HR Dvein: Ellaru vantangala_
Na 11 clock tha

[9:35 AM] **Aruna HR Dvein:**
> _You: Na 11 clock tha_
Ok ok

[9:57 AM] **You:** Hmm

[11:22 AM] **Aruna HR Dvein:** [Document] ALPHA COLLEGE.docx

[11:23 AM] **You:** Clg la smart screen erukuma

[11:24 AM] **You:** Unga Thampi vanthutan Prasanth

[11:25 AM] **Aruna HR Dvein:**
> _You: Unga Thampi vanthutan Prasanth_
Ava kedakura eruma madu

[11:42 AM] **You:** 😂

[10:42 PM] **Aruna HR Dvein:** Mrg pakkalam

[10:42 PM] **Aruna HR Dvein:** Tata

---

## September 18, 2026

[5:31 AM] **You:** Hmm ok

[6:14 AM] **Aruna HR Dvein:** Kelambitiya da

[6:34 AM] **Aruna HR Dvein:** Oye

[6:34 AM] **You:** Hmm

[6:34 AM] **Aruna HR Dvein:** Avan house owner v2la charge pota ph kuduthurukanam

[6:35 AM] **Aruna HR Dvein:** Oru paiyan cll eduthan

[6:35 AM] **Aruna HR Dvein:** And solla soliruken

[6:35 AM] **You:** Eppo nama sozlikanalur la yaraki wait pannuvom

[6:35 AM] **Aruna HR Dvein:** Aprm antha clg mam uh kelambura apo solla sonanga  avangakitaiyu info panitan

[6:35 AM] **Aruna HR Dvein:**
> _You: Eppo nama sozlikanalur la yaraki wait pannuvom_
Ama ama

[6:35 AM] **You:**
> _Aruna HR Dvein: Aprm antha clg mam uh kelambura apo solla sonanga  avangakitaiyu info panitan_
Hmm ok

[6:35 AM] **You:** Intro english la kutukanuma

[6:35 AM] **You:** ?

[6:36 AM] **Aruna HR Dvein:**
> _You: Intro english la kutukanuma_
No da tamil dhn

[6:36 AM] **You:**
> _Aruna HR Dvein: No da tamil dhn_
Hmm

[6:36 AM] **Aruna HR Dvein:** Mm

[6:39 AM] **You:** Mam amount kututhagala

[6:39 AM] **Aruna HR Dvein:** Kudukala da

[6:40 AM] **You:** Na yesterday jaya sri kita sonna night

[6:40 AM] **You:** Aruna pavam athukita amount illa nu

[6:40 AM] **Aruna HR Dvein:**
> _You: Na yesterday jaya sri kita sonna night_
Adhu mam ta solluranu sona ah

[6:40 AM] **Aruna HR Dvein:** Ana mutta kanni inu podala

[6:40 AM] **Aruna HR Dvein:**
> _You: Aruna pavam athukita amount illa nu_
No thanks odu

[6:41 AM] **You:** Aprom ketan jaya sri kita aruna ku intha month salary potagala nu . July month ah ennum potalanu soluchu

[6:41 AM] **You:** Mam kita sokucham amount today nama porathuku

[6:41 AM] **Aruna HR Dvein:** Sholinganallur vantom

[6:41 AM] **Aruna HR Dvein:** Paru

[6:41 AM] **You:** Send pannuranu sonagalam

[11:01 AM] **You:** https://colab.research.google.com/drive/1dDSbxqer-5V00hD613nuWYKlpXAnQyDV

[11:05 AM] **You:** https://colab.research.google.com/drive/1dDSbxqer-5V00hD613nuWYKlpXAnQyDV?usp=sharing

[11:15 AM] **Aruna HR Dvein:** [Document] M I S I N T E R P R E T A T I O N.docx

[1:49 PM] **You:** https://colab.research.google.com/drive/1ftsJFHIjM2uLgfgGkmtiCDVqLtJbLK22

[5:25 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:25 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:25 PM] **Aruna HR Dvein:** [Forwarded] [album message]

[5:25 PM] **Aruna HR Dvein:** [Forwarded] [album message]

[5:25 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:25 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Video]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [Forwarded] [Image]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [album message]

[5:26 PM] **Aruna HR Dvein:** [Video]

[5:26 PM] **Aruna HR Dvein:** [Image]

[5:26 PM] **Aruna HR Dvein:** [Image]

[5:26 PM] **Aruna HR Dvein:** [Image]

[5:26 PM] **Aruna HR Dvein:** [Image]

[5:26 PM] **Aruna HR Dvein:** [Image]

[5:26 PM] **Aruna HR Dvein:** [Image]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[5:26 PM] **Aruna HR Dvein:** [unknown message]

[8:24 PM] **You:** Mam kita vanthutom nu text poturuka

[8:24 PM] **You:** Appo tha nama vantha timing tharium

[8:25 PM] **Aruna HR Dvein:** Potuta da

[8:25 PM] **You:** Hmm

[8:59 PM] **You:** Pg ku yethana maniku vanthanu soniga

[9:00 PM] **You:** Mam kita

[9:35 PM] **You:** Kidney valikuthu

[10:32 PM] **Aruna HR Dvein:** Saptya da ne

[10:33 PM] **Aruna HR Dvein:** Nalla water kudi Washroom poitu padu da

[11:13 PM] **You:** Feedback

[11:13 PM] **You:** Yenna achu

[11:19 PM] **You:**
> _Aruna HR Dvein: Nalla water kudi Washroom poitu padu da_
Hmm ok

---

## September 19, 2026

[8:02 AM] **You:** Feedback matum link send pannugq

[10:00 AM] **Aruna HR Dvein:** Okiee

[10:30 AM] **You:** Niga pathigala feedback

[10:30 AM] **You:** Yepdi vanthuruku

[11:52 AM] **Aruna HR Dvein:** [Document] Alpha College Workshop Feedback (Responses) - Form responses 1.pdf

[11:55 AM] **You:**
> _Aruna HR Dvein: Document: Alpha College Workshop Feedback (Responses) - Form responses 1.pdf_
Mam ku send panniruga

[11:55 AM] **Aruna HR Dvein:** Haiyoo avangaluku panitu dhn unaku pana ah seriya suma suma feedback feedback nu mrg la irundhu torture panitu iruka ah

[11:56 AM] **Aruna HR Dvein:** AVANUNGA simple ah over panitanga good excellent nu soli

[11:56 AM] **You:** Hmm ok

[1:19 PM] **Aruna HR Dvein:** Stomach paravalaiya munik

[1:19 PM] **You:** Hmm eppo parava illa

[1:19 PM] **Aruna HR Dvein:** Nalla water kudi sapdura kjm rest edu nit apodhn kjm acham tired theriyathu unaku

[1:19 PM] **Aruna HR Dvein:** Ok va

[1:19 PM] **You:** Ungalu leg pain okay ah

[1:19 PM] **Aruna HR Dvein:**
> _You: Hmm eppo parava illa_
Spr da

[1:19 PM] **Aruna HR Dvein:** Over ah tab la use panatha seriya

[1:20 PM] **You:**
> _Aruna HR Dvein: Nalla water kudi sapdura kjm rest edu nit apodhn kjm acham tired theriyathu unaku_
Hmm ok tq☺️

[1:20 PM] **Aruna HR Dvein:**
> _You: Ungalu leg pain okay ah_
Apdiye dh iruku da

[1:20 PM] **You:**
> _Aruna HR Dvein: Over ah tab la use panatha seriya_
Hmm panna matan

[1:20 PM] **Aruna HR Dvein:** Nan ipodhn wkup

[1:20 PM] **You:**
> _Aruna HR Dvein: Apdiye dh iruku da_
Thailam theika

[1:20 PM] **Aruna HR Dvein:**
> _You: Hmm ok tq☺️_
[Sticker]

[1:20 PM] **You:**
> _Aruna HR Dvein: Nan ipodhn wkup_
Super

[1:20 PM] **You:** Night lam rompa aluthan

[1:20 PM] **Aruna HR Dvein:**
> _You: Thailam theika_
Ok da saptu aprm ah pananum

[1:20 PM] **Aruna HR Dvein:**
> _You: Night lam rompa aluthan_
Haiyoo🥺

[1:20 PM] **You:** Yennota ala nanachu

[1:20 PM] **Aruna HR Dvein:** Hospital acham poitu vathurukalam nama

[1:21 PM] **You:**
> _You: Yennota ala nanachu_
Epdi na periya ala akanum nu aasa pataga

[1:21 PM] **Aruna HR Dvein:**
> _You: Yennota ala nanachu_
[Voice message]

[1:21 PM] **You:**
> _Aruna HR Dvein: Hospital acham poitu vathurukalam nama_
Athu avalova thariyala

[1:21 PM] **You:**
> _Aruna HR Dvein: Voice message_
Stomach pain thakiralam

[1:21 PM] **You:** But

[1:22 PM] **You:**
> _You: Epdi na periya ala akanum nu aasa pataga_
But eppo avaga yeah kuta illa

[1:22 PM] **You:** 🥺

[1:22 PM] **Aruna HR Dvein:**
> _You: Epdi na periya ala akanum nu aasa pataga_
[Voice message]

[1:23 PM] **Aruna HR Dvein:**
> _You: But eppo avaga yeah kuta illa_
Vidu munik🫂🫂feel panatha Ik it's hard pain nanu face paniruken nan athula irundhu oru 99% veliya vantan 1% iruku dhn adhan unaku advice panuren

[1:23 PM] **You:**
> _Aruna HR Dvein: Voice message_
Antha nanma vetam🥺

[1:39 PM] **Aruna HR Dvein:**
> _You: Antha nanma vetam🥺_
Yen

[1:54 PM] **Aruna HR Dvein:** Munik nama oru 6clk polla kelambalam ok va sikiram ponalu prvla

[1:54 PM] **You:**
> _Aruna HR Dvein: Munik nama oru 6clk polla kelambalam ok va sikiram ponalu prvla_
Okay

[1:54 PM] **You:** Niga 5.30 call pannuga

[1:54 PM] **You:** Na thuka poran

[1:55 PM] **You:** Nigalum saptu thukuga

[1:55 PM] **Aruna HR Dvein:** Ok da

[1:55 PM] **Aruna HR Dvein:** Nanu thoonga dhn poren

[2:03 PM] **You:** Hmm ok

---

## September 20, 2026

[12:51 AM] **You:** Reached ah

[12:52 AM] **Aruna HR Dvein:**
> _You: Reached ah_
Ok da nan room vantu paduthutan

[12:52 AM] **You:** Hmm ok

---

## September 21, 2026

[9:51 AM] **Aruna HR Dvein:** Up:
●Aruna,munik

Navallur to sholinganallur =₹30
Sholinganallur to tambaram =₹54

●NAVIN
karappakam to tambaram =₹30

●Aruna,munik,navin
Tambaram to nasarapet =₹90
Nasarapet to college =₹150(Auto)

Down:
●Aruna,munik, navin 
College to nasarapet =₹150(auto)
Nasarapet to Tambaram =₹90

●Aruna,munik 

Tambaram to sholinganallur =₹54
Sholinganallur to Navalur =₹30

●Navin
Tambaram to karappakam=₹30

Total= ₹708

[10:18 AM] **You:** [Image]

[10:18 AM] **You:** [unknown message]

[5:15 PM] **You:** Sahana mam kita ketu soluga

[5:15 PM] **You:** Today yenaku yepo porathunu

[5:15 PM] **Aruna HR Dvein:** Neeye kellu pa

[5:15 PM] **Aruna HR Dvein:** Nan mess pani inu pakkala

[5:16 PM] **You:** Na keta ungala tha yethachum soluvaga .. so atha soluran

[5:16 PM] **Aruna HR Dvein:** No prblm solla matanga nan face panikuren neeye ketukoo

[5:17 PM] **Aruna HR Dvein:** 4clk mess eh inu pakkala

[5:17 PM] **Aruna HR Dvein:** So enala keka mudiyathu

[5:19 PM] **You:** Hmm tq

---

## September 22, 2026

[3:43 PM] **Aruna HR Dvein:** Munik

[3:43 PM] **Aruna HR Dvein:** Odambu epd iruku ipo ok va

[3:43 PM] **Aruna HR Dvein:** Saptya ne

[4:43 PM] **You:**
> _Aruna HR Dvein: Odambu epd iruku ipo ok va_
Pain ah tha eruku ennum

[4:43 PM] **You:** Muchu vetum pothum eppo pain illa

[4:43 PM] **You:** But normal ah pain ah eruku

[4:45 PM] **Aruna HR Dvein:** Tab potiya ne

[4:45 PM] **Aruna HR Dvein:**
> _You: Pain ah tha eruku ennum_
Idhuku enna solution nu sonangala epo sariagum nu solitu

[4:45 PM] **You:** Hmm potu eppo tha yeluthan . Vomet sence ah eruku

[4:46 PM] **You:** Yenna sonaru sir

[4:46 PM] **You:** Yelam okay thana

[4:48 PM] **Aruna HR Dvein:**
> _You: Hmm potu eppo tha yeluthan . Vomet sence ah eruku_
Haiyoo juice kudikuriya navin ah kuda vaangitu vara solluren

[4:48 PM] **Aruna HR Dvein:**
> _You: Yelam okay thana_
Sir varave lla nan pesave lla

[4:48 PM] **Aruna HR Dvein:** Mam uh varula inu

[4:48 PM] **You:**
> _Aruna HR Dvein: Haiyoo juice kudikuriya navin ah kuda vaangitu vara solluren_
Vetam vetam

[4:48 PM] **You:**
> _Aruna HR Dvein: Mam uh varula inu_
Sir varanu sonaru

[4:50 PM] **Aruna HR Dvein:** [Voice message]

[4:51 PM] **Aruna HR Dvein:** [Voice message]

[4:53 PM] **You:**
> _Aruna HR Dvein: Voice message_
Mam Yenna sonaga

[4:53 PM] **You:**
> _Aruna HR Dvein: Voice message_
Vetam vetam

[4:53 PM] **You:** Na pathukiran

[4:56 PM] **You:** Evalo pesitaga

[4:56 PM] **You:** 😕

[4:57 PM] **Aruna HR Dvein:** Nanu Suma lla pesivitutan

[4:57 PM] **Aruna HR Dvein:** Limit iruku porumaiya iruka matingalana 3months ah salary podama yar porumaiya lla sollu

[5:11 PM] **You:** Sari saryethum eppo kova pattu pesathiga smooth ah veliya pokanum

[5:39 PM] **Aruna HR Dvein:** Sir ta elame pesitan

[5:39 PM] **Aruna HR Dvein:** Cl panaru

[5:39 PM] **You:** Apdiya

[5:39 PM] **You:** Yenna sonaru

[5:39 PM] **You:** Sir

[5:39 PM] **Aruna HR Dvein:** Nalla dhn pesuna avan

[10:13 PM] **You:** Bus yeritan

[10:13 PM] **You:** 🫂

[10:19 PM] **Aruna HR Dvein:** Be safe da navin, selva, sir ta la sollitiya

[10:19 PM] **Aruna HR Dvein:** Water bottle iruka ah

[10:19 PM] **You:**
> _Aruna HR Dvein: Be safe da navin, selva, sir ta la sollitiya_
Hmm solitan sir tha Yenna bus yethi vetaru

[10:19 PM] **You:**
> _Aruna HR Dvein: Water bottle iruka ah_
Hmm eruki

[10:20 PM] **Aruna HR Dvein:**
> _You: Hmm solitan sir tha Yenna bus yethi vetaru_
Parraaahhh

[10:20 PM] **Aruna HR Dvein:**
> _You: Hmm eruki_
Okiee da

[10:20 PM] **You:**
> _Aruna HR Dvein: Parraaahhh_
Ama

[10:20 PM] **You:** Good boy ah akitaru

[10:21 PM] **Aruna HR Dvein:**
> _You: Good boy ah akitaru_
Kelicharu

[10:21 PM] **Aruna HR Dvein:** Nan nambavae matan

[10:21 PM] **Aruna HR Dvein:** Sudden ah yar change aguva sollu neeye

[10:21 PM] **Aruna HR Dvein:** But I'm happy da unaiya care panathula

[10:21 PM] **You:**
> _Aruna HR Dvein: Sudden ah yar change aguva sollu neeye_
Athum correct tha

[10:22 PM] **You:**
> _Aruna HR Dvein: But I'm happy da unaiya care panathula_
🩷yenakum epdi care pannathu happy ah tha eruku .but payama eruku

[10:22 PM] **Aruna HR Dvein:**
> _You: 🩷yenakum epdi care pannathu happy ah tha eruku .but payama eruku_
Onu lla pathukalam vidu

[10:23 PM] **Aruna HR Dvein:** Ne enanu checkup panu body full ah ok va dhairiyama iru pathukalam

[10:24 PM] **You:**
> _Aruna HR Dvein: Ne enanu checkup panu body full ah ok va dhairiyama iru pathukalam_
🫂

[10:24 PM] **You:** Amma aluthutagalam

[10:24 PM] **You:** Nigalum thiriyama eruka

[10:25 PM] **You:** Porumiya pesi vakitu ponga

---

## September 23, 2026

[7:59 AM] **Aruna HR Dvein:**
> _You: Amma aluthutagalam_
Pavaam da ne solu enaku lam onu lla nu solitu

[7:59 AM] **Aruna HR Dvein:**
> _You: Porumiya pesi vakitu ponga_
Kandipa munik

[7:59 AM] **Aruna HR Dvein:**
> _You: Nigalum thiriyama eruka_
Kandipa🫂✨

[8:07 AM] **You:**
> _Aruna HR Dvein: Kandipa munik_
Hmm

[8:07 AM] **You:**
> _Aruna HR Dvein: Kandipa🫂✨_
🫂

[12:05 PM] **Aruna HR Dvein:** munik hospital kelambitiya ne

[4:01 PM] **You:** MRI scan yetuthaga

[4:02 PM] **You:** Cyst muscle demage ah erukam chinatha

[4:07 PM] **Aruna HR Dvein:**
> _You: Cyst muscle demage ah erukam chinatha_
Idhu sariagidum la Vera enna sonanga

[4:11 PM] **You:**
> _Aruna HR Dvein: Idhu sariagidum la Vera enna sonanga_
Sari akirum nu sonaga

[4:12 PM] **Aruna HR Dvein:** Ok da bed rest edhuvu eduka sonangala

[4:12 PM] **Aruna HR Dvein:** All ok dhn eh

[9:34 PM] **You:**
> _Aruna HR Dvein: Ok da bed rest edhuvu eduka sonangala_
Hmm ok

[9:34 PM] **You:** Saptigala

[9:47 PM] **Aruna HR Dvein:** Saptan da ne saptya

[9:47 PM] **Aruna HR Dvein:** Tab potiya

[9:47 PM] **Aruna HR Dvein:** Ipo paravalaiya llaiya

[9:55 PM] **You:**
> _Aruna HR Dvein: Tab potiya_
Hmm

[9:55 PM] **You:**
> _Aruna HR Dvein: Ipo paravalaiya llaiya_
Little bit pain

---

## September 24, 2026

[12:07 AM] **Aruna HR Dvein:**
> _You: Little bit pain_
Inu sariagalaiya avanga solura mari tab crt ah podu munik kjm manas free paniko relax ah iru

[12:08 AM] **You:**
> _Aruna HR Dvein: Inu sariagalaiya avanga solura mari tab crt ah podu munik kjm manas free paniko relax ah iru_
Eppo pain vanthuruchu

[12:09 AM] **You:** Otkathurukan

[12:09 AM] **You:** Thailam thechitu

[12:10 AM] **You:** Evening nala eruthuchu eppo valikuthu

[8:07 AM] **Aruna HR Dvein:**
> _You: Eppo pain vanthuruchu_
Enna da sollura epd agudhu🥲

[8:08 AM] **Aruna HR Dvein:**
> _You: Evening nala eruthuchu eppo valikuthu_
Ipo paravalaiya munik

[9:27 AM] **You:** 😓

[9:48 AM] **Aruna HR Dvein:** odamba pathukoo da request ah kekuran sikiram sari panitu vaa nama enj pananum ok va

[10:58 AM] **You:**
> _Aruna HR Dvein: odamba pathukoo da request ah kekuran sikiram sari panitu vaa nama enj pananum ok va_
Kocham kaistam tha pola yetho yetho soluraga

[11:06 AM] **Aruna HR Dvein:** Edhu edho na puriyala

[11:41 AM] **You:**
> _Aruna HR Dvein: Edhu edho na puriyala_
Neriya check pannaga

[11:41 AM] **You:** Mutiyala rompa injection

[11:41 AM] **Aruna HR Dvein:**
> _You: Mutiyala rompa injection_
Kastama iruku ne sikiram pathu vaa

[11:42 AM] **You:**
> _Aruna HR Dvein: Image_
Ayyo

[11:42 AM] **You:** Eppo Yenna pannurathu

[12:42 PM] **Aruna HR Dvein:** mail panitan da nan solluren unaku

[12:43 PM] **Aruna HR Dvein:** acknowledgement la absconding nu mention agum nu sonaah nan kathi vitutan theryum ah

[12:43 PM] **Aruna HR Dvein:** aprm athuku oru mail potan nanu

[12:43 PM] **Aruna HR Dvein:** evn robin ta full ah pesiduvan nerula

[12:43 PM] **Aruna HR Dvein:** evening

[12:55 PM] **You:** Hmm ok

[12:55 PM] **You:** Onnum payapatathiga

---

## September 25, 2026

[12:33 PM] **Aruna HR Dvein:** Odambu epd iruku munik

[12:33 PM] **Aruna HR Dvein:** All ok va

[12:33 PM] **You:** Hmm eppo parava illa

[12:34 PM] **You:** Yenna achu emc

[12:34 PM] **You:** Porathu

[12:54 PM] **Aruna HR Dvein:** [Voice message]

[12:56 PM] **You:**
> _Aruna HR Dvein: Image_
Personal loan okay ah

[12:59 PM] **Aruna HR Dvein:** [Voice message]

[1:03 PM] **You:**
> _Aruna HR Dvein: Image_
Evaga kekura yethum illa 😓

[1:04 PM] **Aruna HR Dvein:** [Voice message]

[1:04 PM] **Aruna HR Dvein:**
> _You: Evaga kekura yethum illa 😓_
[Voice message]

[1:08 PM] **You:**
> _Aruna HR Dvein: Voice message_
Hay super

[1:08 PM] **You:** Ropin vai la intha word vanthuchuna ethu pothum

[1:08 PM] **You:** 🤩🫂

[1:09 PM] **You:** Athika pacham yenaku call pannuvaga na pesikiran nu solitaru la eni ni 1% kuta feel panna kutathu happy ah eru

[1:10 PM] **You:** Atha Mathiri unmala nampika eruku athalam ni easy ah torget mutuchuruva etha na o kuta eruthu 7 month vachu solura

[1:10 PM] **You:** Na just summa word ah solala

[1:10 PM] **You:** Ni anga poe unota appa name kapathu

[1:10 PM] **You:** Veeramani ponnu na leader quality erukum nu

[1:11 PM] **You:** Atha Mathiri robin unkita oru question kekanum future la .. epdi hard work pannura una yeah avaga use panikama vetaga nu unkita kekanum apdi work paaru god bless you 🫂💥💥💥💥😍😍😍😍😍all the best

[1:12 PM] **You:**
> _Aruna HR Dvein: Voice message_
Yenaku amount vanthathum next day ah papar poturuvan pramiss ah

[1:12 PM] **You:**
> _You: Yenaku amount vanthathum next day ah papar poturuvan pramiss ah_
🥺

[2:03 PM] **Aruna HR Dvein:** [Voice message]

[2:03 PM] **Aruna HR Dvein:**
> _You: Ropin vai la intha word vanthuchuna ethu pothum_
Ama munik

[2:03 PM] **Aruna HR Dvein:**
> _You: Athika pacham yenaku call pannuvaga na pesikiran nu solitaru la eni ni 1% kuta feel panna kutathu happy ah eru_
Kandipa da🥺

[2:03 PM] **Aruna HR Dvein:**
> _You: Atha Mathiri unmala nampika eruku athalam ni easy ah torget mutuchuruva etha na o kuta eruthu 7 month vachu solura_
🥺🥺🥺🥺🧎🏻‍♀️

[2:03 PM] **Aruna HR Dvein:**
> _You: Ni anga poe unota appa name kapathu_
Kandipa nala name oda irupan

[2:03 PM] **Aruna HR Dvein:**
> _You: Veeramani ponnu na leader quality erukum nu_
🥺🥺🥺💪🏻❤️

[2:04 PM] **Aruna HR Dvein:**
> _You: Atha Mathiri robin unkita oru question kekanum future la .. epdi hard work pannura una yeah avaga use panikama vetaga nu unkita kekanum apdi work paaru god bless you 🫂💥💥💥💥😍😍😍😍😍all the best_
Kandipa kekura mari dhn work panuvan nalla hardwork panuvan da

[2:04 PM] **Aruna HR Dvein:**
> _You: Yenaku amount vanthathum next day ah papar poturuvan pramiss ah_
Unmaiyava

[2:04 PM] **Aruna HR Dvein:** [Contact: BEGIN:VCARD
VERSION:3.0
N:;Vishwa;;;
FN:Vishwa
TEL;type=Mobile;waid=919345700541:+91 93457 00541
END:VCARD]

[2:05 PM] **You:**
> _Aruna HR Dvein: Voice message_
Okay.. business loan apply panna IT file panna soluraga athium try pannitan

[2:05 PM] **Aruna HR Dvein:** [Voice message]

[2:05 PM] **You:**
> _Aruna HR Dvein: Unmaiyava_
Ama pramiss ah

[2:06 PM] **Aruna HR Dvein:**
> _You: Okay.. business loan apply panna IT file panna soluraga athium try pannitan_
[Voice message]

[2:07 PM] **You:**
> _Aruna HR Dvein: Voice message_
Kantipa call pannura🫂🩷

[2:07 PM] **Aruna HR Dvein:** [Voice message]

[2:07 PM] **Aruna HR Dvein:** [Voice message]

[2:08 PM] **You:**
> _Aruna HR Dvein: Voice message_
Intha oru word pothum 🫂🫂🩷🩷nama try panalam

[2:08 PM] **You:**
> _Aruna HR Dvein: Voice message_
Okay clear ah voice poturan🩷🫂🫂

[2:09 PM] **You:** Tq🫂🩷🩷

[2:10 PM] **Aruna HR Dvein:** [Voice message]

[2:10 PM] **Aruna HR Dvein:**
> _You: Intha oru word pothum 🫂🫂🩷🩷nama try panalam_
❤️🫂🫂

[2:10 PM] **Aruna HR Dvein:**
> _You: Tq🫂🩷🩷_
Hey pehh

[2:11 PM] **Aruna HR Dvein:** Nalla sapdu odamba pathukoo strength gain panitu vaaa

[2:11 PM] **Aruna HR Dvein:**
> _You: Okay clear ah voice poturan🩷🫂🫂_
Ok da

[2:11 PM] **You:**
> _Aruna HR Dvein: Voice message_
Kantipa🫂🩷🩷

[2:12 PM] **You:**
> _Aruna HR Dvein: Nalla sapdu odamba pathukoo strength gain panitu vaaa_
Kantipa🩷treat marathuratha monday

[2:46 PM] **You:** Jaya sri yeah kita ketuchu

[2:46 PM] **You:** Aruna work vettu pouta nu

[2:47 PM] **You:** Yenaku thariyatha mathiri na kaatikita

[2:49 PM] **Aruna HR Dvein:** [Voice message]

[2:49 PM] **Aruna HR Dvein:**
> _You: Kantipa🩷treat marathuratha monday_
Vaa ne nan vaikuren

[2:51 PM] **You:**
> _Aruna HR Dvein: Voice message_
Illa na thariyalanu tha pesitu erukan thariyatha mathiri

[2:51 PM] **Aruna HR Dvein:**
> _You: Illa na thariyalanu tha pesitu erukan thariyatha mathiri_
Okiee da

[2:51 PM] **Aruna HR Dvein:** Vera enna soluchi

[2:53 PM] **You:** Ketuchu aruna

[2:53 PM] **You:** Company vetu poutalam

[2:54 PM] **You:** Yelaru kitaum solitu tha ponalam

[2:54 PM] **You:** Apdinu .. na keta yethum problem ah office la nu

[2:54 PM] **You:** Illa salary kutukalanu poutalam nu sokuchu

[2:55 PM] **Aruna HR Dvein:** Jayasri enaku ph panudhu ipo

[2:55 PM] **Aruna HR Dvein:** Nan eduka matan

[2:55 PM] **Aruna HR Dvein:**
> _You: Illa salary kutukalanu poutalam nu sokuchu_
Enaku elame dhn prblm  eh

[2:56 PM] **Aruna HR Dvein:**
> _You: Yelaru kitaum solitu tha ponalam_
Yaraiyu nan sollave lla da anga irukavanga kita

[2:56 PM] **You:** But apdi soluchu

[2:57 PM] **Aruna HR Dvein:** [Voice message]

[2:58 PM] **You:** Hmm pathukalam

[5:28 PM] **You:**
> _Aruna HR Dvein: BEGIN:VCARD
VERSION:3.0
N:;Vishwa;;;
FN:Vishwa
TEL;type=Mobile;waid=919345700541:+91 93457 00541
END:VCARD_
Eppo call panatuma evaruku

[5:30 PM] **Aruna HR Dvein:**
> _You: Eppo call panatuma evaruku_
Panu da

[5:31 PM] **You:** Hmm ok

[5:47 PM] **You:** Avaru kocham work ah erukaram aprom kupturaram

[5:50 PM] **Aruna HR Dvein:** [Voice message]

[5:50 PM] **Aruna HR Dvein:** Ne epo chni ku vara munik

[5:50 PM] **You:**
> _Aruna HR Dvein: Voice message_
Hay

[5:50 PM] **You:** Vetam

[5:51 PM] **You:** Avaru free akitu call panatum

[5:51 PM] **You:** Na msg tha pannuna

[5:51 PM] **You:** Yethum thappa nanachuparu

[5:51 PM] **You:**
> _Aruna HR Dvein: Ne epo chni ku vara munik_
Monday

[5:54 PM] **Aruna HR Dvein:**
> _You: Yethum thappa nanachuparu_
Apdlam lla da avan edhuvu ninaika matan

[5:54 PM] **Aruna HR Dvein:**
> _You: Monday_
Ok munik

[5:55 PM] **You:**
> _Aruna HR Dvein: Apdlam lla da avan edhuvu ninaika matan_
Hmm ok vetuga avaga free akitu call panatum

[5:55 PM] **You:** Avasaram illa

[7:30 PM] **Aruna HR Dvein:** Okiee munik

[7:30 PM] **Aruna HR Dvein:** Pesitu sollu

[11:00 PM] **You:** Hmm ok

[11:00 PM] **You:** Avaru busy

[11:18 PM] **Aruna HR Dvein:** [Voice message]

[11:20 PM] **You:** Kantipa niga pannura help 100 matangu return varum

[11:20 PM] **Aruna HR Dvein:**
> _You: Kantipa niga pannura help 100 matangu return varum_
Ada suma iru da munik nangalam irukom

[11:21 PM] **You:** 2027 namakana year ah erukanum

[11:38 PM] **Aruna HR Dvein:** Kandipa irukum munik✨💪🏻

[11:39 PM] **You:** 🥺🫂

[11:48 PM] **Aruna HR Dvein:** [Voice message]

[11:50 PM] **You:**
> _Aruna HR Dvein: Voice message_
Hay

[11:50 PM] **You:** Nenju vali ah

[11:52 PM] **Aruna HR Dvein:** [Voice message]

[11:54 PM] **You:** Cyst pain left or right

[11:54 PM] **Aruna HR Dvein:**
> _You: Cyst pain left or right_
Left

[11:55 PM] **You:** Yenakum apditha eruthuchu

[11:55 PM] **You:** தேய்க்க  kutathu

[11:55 PM] **Aruna HR Dvein:** [Voice message]

[11:55 PM] **You:** Doctor songa

[11:55 PM] **Aruna HR Dvein:**
> _You: Doctor songa_
Ok da

[11:56 PM] **You:**
> _Aruna HR Dvein: Voice message_
Same atha problem tha yenaku

[11:57 PM] **You:** Inner potathiga free ah thukuga athum aluthum

[11:57 PM] **You:** Thailam erutha just apply pannuga . Theika kutathu.

[11:57 PM] **Aruna HR Dvein:** Haan ok da

[11:57 PM] **Aruna HR Dvein:**
> _You: Thailam erutha just apply pannuga . Theika kutathu._
Okiee panuren munik

[11:58 PM] **You:** Breathing ok ah

---

## September 26, 2026

[12:01 AM] **You:** Health pathukoga

[12:01 AM] **Aruna HR Dvein:**
> _You: Breathing ok ah_
Adhulam ok dhn da

[12:01 AM] **You:** Night time 🫂

[12:01 AM] **Aruna HR Dvein:** Heavy feel irundhuchi avlodhn

[12:01 AM] **Aruna HR Dvein:** Ipo ok kjm

[12:02 AM] **Aruna HR Dvein:**
> _You: Night time 🫂_
Kandipa da munik🫂

[12:02 AM] **You:** Safe ah eruka

[12:02 AM] **Aruna HR Dvein:**
> _You: Safe ah eruka_
Ne safe ah iru nan enaiya pathupan da

[12:02 AM] **You:** One day free ah pesalam🫂

[12:02 AM] **Aruna HR Dvein:**
> _You: One day free ah pesalam🫂_
Kandipa da ne chni vaa odambu lam sari panitu ok va

[12:02 AM] **You:**
> _Aruna HR Dvein: Ne safe ah iru nan enaiya pathupan da_
Eruthalum. Just unga kuta katamiku palakititha unga mela evalo feeling varathu

[12:03 AM] **You:** Eppo yethachum ungaluku nu solum pothu my family la oru person ku ana mathiri tha eruku

[12:03 AM] **Aruna HR Dvein:**
> _You: Eppo yethachum ungaluku nu solum pothu my family la oru person ku ana mathiri tha eruku_
Achoow nan safe dhn munik🫂🥺

[12:03 AM] **You:**
> _Aruna HR Dvein: Kandipa da ne chni vaa odambu lam sari panitu ok va_
🫂hmm ok

[12:04 AM] **You:** Rompa stress aakathiga🫂

[12:04 AM] **Aruna HR Dvein:**
> _You: Rompa stress aakathiga🫂_
Ok da

[12:04 AM] **You:** Na erukan pathukalam🫂

[12:04 AM] **Aruna HR Dvein:**
> _You: Na erukan pathukalam🫂_
[Sticker]

[12:04 AM] **You:** Oii today 🥺

[12:04 AM] **You:** My ala pathan

[12:04 AM] **You:** 😭

[12:04 AM] **You:** Avalo kaistama eruku

[12:05 AM] **Aruna HR Dvein:**
> _You: My ala pathan_
Enna sollura

[12:05 AM] **Aruna HR Dvein:** Unmaiyava

[12:05 AM] **Aruna HR Dvein:** Enga patha epd

[12:05 AM] **You:** Road la😭

[12:05 AM] **You:** 1 year aprom

[12:05 AM] **Aruna HR Dvein:** Achooww🫂🫂

[12:06 AM] **You:** Yenala thaanga mutiyala

[12:06 AM] **You:** 😭

[12:06 AM] **Aruna HR Dvein:**
> _You: Yenala thaanga mutiyala_
Avangalu move on agirupanga da

[12:06 AM] **Aruna HR Dvein:** Yen ne matu move on agama iruka ah sollu

[12:06 AM] **You:**
> _Aruna HR Dvein: Avangalu move on agirupanga da_
Ama😭

[12:06 AM] **Aruna HR Dvein:** [Voice message]

[12:06 AM] **You:** Avaga move on akitaga😭

[12:07 AM] **Aruna HR Dvein:**
> _You: Avaga move on akitaga😭_
Simple ne un life ah paru unakunu oru family iruku athula focus panu you have a responsibility in to create a own business

[12:07 AM] **You:** Na Yenna pavam panano😭😭😭

[12:08 AM] **You:** Na thukuran gn😭😭

[12:08 AM] **You:** Intha selvamani navin kita solathiga🥺

[12:08 AM] **Aruna HR Dvein:**
> _You: Na thukuran gn😭😭_
Ada chii serupala adipa  naiye suma azhuthutu iruntha

[12:08 AM] **Aruna HR Dvein:** Konu poturuvom nanu navin selva lam

[12:08 AM] **Aruna HR Dvein:**
> _You: Intha selvamani navin kita solathiga🥺_
Sollala da

[12:09 AM] **You:** Avanuka Yenna nanachu feel pannuvaga pls🥺

[12:09 AM] **Aruna HR Dvein:**
> _You: Avanuka Yenna nanachu feel pannuvaga pls🥺_
Solla matan

[12:09 AM] **Aruna HR Dvein:** Ok va

[12:09 AM] **Aruna HR Dvein:** Ne mooditu thoongu suma loosu paiya mari feel panurathu waste avlodhn solluvan

[12:09 AM] **Aruna HR Dvein:** Un velaiya paru

[12:09 AM] **Aruna HR Dvein:**
> _Aruna HR Dvein: Simple ne un life ah paru unakunu oru family iruku athula focus panu you have a responsibility in to create a own business_
Puriyudha Maramandaaa

[12:09 AM] **You:** Hmm😭

[12:09 AM] **Aruna HR Dvein:** Odu olunga rest edu

[12:09 AM] **Aruna HR Dvein:** [Sticker]

[12:09 AM] **Aruna HR Dvein:** Gn🫂

[12:09 AM] **You:** Gn😭

[12:10 AM] **You:** 🫂

[8:47 AM] **You:** Rompa hope ah pesura

[8:47 AM] **You:** Avaga

[8:56 AM] **You:** Rompa caring ah pasunaga

[8:57 AM] **Aruna HR Dvein:** Ok da amt ku enna sonanga

[8:58 AM] **You:** Veliya kututhurukagalam lock akirucham

[8:58 AM] **You:** Ready panni tharan nu sonaga

[8:59 AM] **You:** Amount thaandi good relationship ketachuruku

[8:59 AM] **Aruna HR Dvein:**
> _You: Amount thaandi good relationship ketachuruku_
☺️😇✨

[8:59 AM] **Aruna HR Dvein:**
> _You: Ready panni tharan nu sonaga_
Ok da

[9:04 AM] **You:** Rompa tq

[9:04 AM] **You:** Yenaku Evalo effort potathuku

[9:09 AM] **You:** https://youtube.com/shorts/QfPAmYFtfJs?si=VP9XgoML1hHKR9Mn

[9:09 AM] **You:** Unota future husband

[9:20 AM] **Aruna HR Dvein:**
> _You: Unota future husband_
Apdlam evanum vara matanunga nallavan ah dhn varuvan

[9:20 AM] **Aruna HR Dvein:**
> _You: Yenaku Evalo effort potathuku_
Vidu da amt kedaicha podhum nu iruken nanu

[12:02 PM] **You:** Wait na check pannitu soluran

[12:02 PM] **You:** Atha kanom

[12:02 PM] **Aruna HR Dvein:** Ok da

[12:03 PM] **Aruna HR Dvein:** [Voice message]

[12:13 PM] **You:** Hmm ok

[12:52 PM] **Aruna HR Dvein:** Pathiya munik

[1:45 PM] **You:** Sorry

[1:45 PM] **You:** My friend yarathutan

[1:45 PM] **You:** 🥺

[1:46 PM] **Aruna HR Dvein:** [Voice message]

[1:46 PM] **You:** Ama🥺

[1:48 PM] **Aruna HR Dvein:** Today va

[1:48 PM] **Aruna HR Dvein:** [Voice message]

[2:03 PM] **You:** [Voice message]

[2:22 PM] **Aruna HR Dvein:** Idhula kodumai theryum ah🧎🏻‍♀️🥲

[2:26 PM] **You:** 🥺

---

## September 27, 2026

[12:33 AM] **Aruna HR Dvein:** Munik

[7:20 AM] **You:** Hmm soluga

[7:25 AM] **You:** Food Street ponigala

[7:49 AM] **Aruna HR Dvein:** Kovil ku pogunan da

[7:59 AM] **You:** Today ah

[8:18 AM] **Aruna HR Dvein:**
> _You: Today ah_
Yesterday evening ah pogunan da

[8:19 AM] **You:** Food Street pokaliya yesterday

[8:28 AM] **Aruna HR Dvein:** Illa yen kekura

[8:31 AM] **You:** Illa navin pokanum intha week nu sonna

[8:31 AM] **You:** Atha ketan

[8:32 AM] **You:** Next week pokalam

[5:30 PM] **You:** Hii

[5:30 PM] **You:** Tmr joining ah

[6:21 PM] **Aruna HR Dvein:**
> _You: Tmr joining ah_
Ama munik

[6:22 PM] **You:** All the best 🤩🤩🤩🔥🔥🔥🫂🫂🫂🫂

[6:26 PM] **Aruna HR Dvein:**
> _You: All the best 🤩🤩🤩🔥🔥🔥🫂🫂🫂🫂_
Thanks alots ra🙏🏻❤️

[6:26 PM] **You:** Tmr evening yepdi eruthuchunu soluga

[6:26 PM] **You:** Yee eppo nervous ah eruka

[6:26 PM] **You:** ?

[6:42 PM] **Aruna HR Dvein:**
> _You: Tmr evening yepdi eruthuchunu soluga_
Sure da

[6:42 PM] **Aruna HR Dvein:**
> _You: Yee eppo nervous ah eruka_
Ama rmbave

---

## September 28, 2026

[6:21 AM] **You:** All the best 😍🤗☺️

[8:39 AM] **Aruna HR Dvein:** Thank you munik❤️🙏🏻

[8:39 AM] **Aruna HR Dvein:** Ana Lita bayama iruku

[8:39 AM] **Aruna HR Dvein:** Dvein la edhuvu prblm panuvangaloo nu

[9:15 AM] **You:**
> _Aruna HR Dvein: Dvein la edhuvu prblm panuvangaloo nu_
Athalam panna mataga

[2:16 PM] **Aruna HR Dvein:** enna jayasri munadi apd act podura ne

[2:23 PM] **You:**
> _Aruna HR Dvein: enna jayasri munadi apd act podura ne_
[Sticker]

[2:51 PM] **Aruna HR Dvein:** jayasri edhacham sonan la

[3:00 PM] **You:**
> _Aruna HR Dvein: jayasri edhacham sonan la_
Illa

[7:28 PM] **You:** Hii

[7:28 PM] **You:** Office mutuchurucha

[7:28 PM] **You:** Yepdi eruthuchu today

[7:28 PM] **You:** First day

[7:28 PM] **You:** 🤩

[7:28 PM] **You:** [Sticker]

[7:32 PM] __[Call]__

[8:09 PM] __[Call]__

[8:23 PM] **Aruna HR Dvein:** [Voice message]

[8:29 PM] **You:** [Voice message]

[10:18 PM] **Aruna HR Dvein:**
> _You: Voice message_
Ada pavatha🥺😬

[10:18 PM] **You:**
> _Aruna HR Dvein: Ada pavatha🥺😬_
Ama😓

[10:18 PM] **You:** Yela pakamum ati mutiyala

[10:26 PM] **Aruna HR Dvein:**
> _You: Yela pakamum ati mutiyala_
Ama ama🤧🤧

[10:26 PM] **You:** 😓

[10:26 PM] **You:** Mutiyala

[10:29 PM] **Aruna HR Dvein:** Over cold ah iruka ah da

[10:30 PM] **You:**
> _Aruna HR Dvein: Over cold ah iruka ah da_
Ama😓

---

## September 29, 2026

[5:46 PM] **Aruna HR Dvein:** odamba pathuko munik leave kuda eduthuko avlodhn solluvan ok va

[5:47 PM] **Aruna HR Dvein:** aprm unoda business ah room vantu enaku full ah voice note la podu

[5:47 PM] **Aruna HR Dvein:** kjm

[5:55 PM] **You:**
> _Aruna HR Dvein: odamba pathuko munik leave kuda eduthuko avlodhn solluvan ok va_
Kandipa😔yenala mutiyala

[5:55 PM] **You:** Eppo same time 2 class yetuka soluraga

[5:55 PM] **Aruna HR Dvein:** Sahana poitala

[5:55 PM] **You:** Online vs offline

[5:55 PM] **You:**
> _Aruna HR Dvein: Sahana poitala_
Hmm potaga

[5:56 PM] **You:**
> _Aruna HR Dvein: aprm unoda business ah room vantu enaku full ah voice note la podu_
Hmm ok sure

[5:57 PM] **Aruna HR Dvein:**
> _You: Hmm potaga_
ok da

[5:57 PM] **Aruna HR Dvein:**
> _You: Eppo same time 2 class yetuka soluraga_
20k ku nalla velai vaanguranga polla

[5:57 PM] **Aruna HR Dvein:**
> _You: Kandipa😔yenala mutiyala_
eduthu thola first uh

[5:57 PM] **Aruna HR Dvein:** loosu

[6:02 PM] **You:** Monday workshop vera

[6:02 PM] **You:** Eruku

[6:02 PM] **You:** 😓

[6:02 PM] **You:** 4 hours

[6:03 PM] **You:** 2 days ku

[6:12 PM] **Aruna HR Dvein:** Haiyoo idhu enna kuthala la iruku

[6:13 PM] **Aruna HR Dvein:** [Voice message]

[6:18 PM] **You:**
> _Aruna HR Dvein: Voice message_
Hmm okay today tha 2 round mutuchuchu nu soliru

[6:24 PM] **Aruna HR Dvein:** Kandipa da soliduvan

[6:24 PM] **Aruna HR Dvein:** Trm enaku week off so join panitanu soliduvan

[6:24 PM] **Aruna HR Dvein:** Aprm enna trm meeting ahm

[6:24 PM] **Aruna HR Dvein:** Ungaluku navin sona ah

[6:25 PM] **You:**
> _Aruna HR Dvein: Trm enaku week off so join panitanu soliduvan_
Okay

[6:26 PM] **You:**
> _Aruna HR Dvein: Aprm enna trm meeting ahm_
Ama😓

[6:26 PM] **You:** Atika poraga

[6:26 PM] **Aruna HR Dvein:**
> _You: Atika poraga_
Yen apd sollura

[6:29 PM] **You:** Ama intha meeting ah Yenga 3 perium atikatha

[6:29 PM] **You:** Niga emc poutigala

[6:30 PM] **You:** Unga kuta naga 3 peru thana eruthom

[6:30 PM] **You:** Atha project nu solli ati

[6:30 PM] **Aruna HR Dvein:** Grp la mess poturuken kellu

[6:43 PM] **You:** Hmm ketan eppo tha

---

## September 30, 2026

[8:58 AM] **Aruna HR Dvein:** Office poriya ne

[8:58 AM] **Aruna HR Dvein:** Ipo odambu epd iruku munik

[8:58 AM] **You:**
> _Aruna HR Dvein: Office poriya ne_
Illa

[8:59 AM] **You:** Thala suthuthu nika mutiyala

[8:59 AM] **You:** Vomit varuthu

[9:05 AM] **Aruna HR Dvein:** Haiyoo enna sollura

[9:05 AM] **Aruna HR Dvein:** Hospital pogalam ah?

[9:07 AM] **You:**
> _Aruna HR Dvein: Image_
Reply pannava illa ah

[9:07 AM] **Aruna HR Dvein:**
> _You: Reply pannava illa ah_
[Voice message]

[9:08 AM] **Aruna HR Dvein:** [Voice message]

[9:14 AM] **You:** Hmm

[6:39 PM] **You:** 8 clock aprom brid amblet sapta polama

[6:39 PM] **You:** Na poncer

[6:40 PM] **Aruna HR Dvein:** [Voice message]

[6:41 PM] **You:** Free ah vetuga

[6:44 PM] **You:** Emc la work lam yepdi eru

[7:06 PM] **Aruna HR Dvein:**
> _You: Emc la work lam yepdi eru_
Enaiku weekoff enaku

[7:06 PM] **You:** aprom yenna vaaka veliya polam yenaku yethachum veliya saptanum pola eruku .

[7:07 PM] **Aruna HR Dvein:**
> _You: aprom yenna vaaka veliya polam yenaku yethachum veliya saptanum pola eruku ._
Mail process panitu iruken da

[7:08 PM] **Aruna HR Dvein:** V2la cll pesitu iruken next enna panalam legal ah pogalam ah lla venam ah nu

[7:08 PM] **Aruna HR Dvein:** Nan solluren iru

[7:08 PM] **You:** okay

[7:25 PM] **Aruna HR Dvein:** Elame pesitan da akka varangalam trm

[7:25 PM] **Aruna HR Dvein:** Ne nit saptu vaa

[7:25 PM] **Aruna HR Dvein:** Pogalam

[7:36 PM] **You:** hmm okay

[8:36 PM] **You:** Polama

[8:37 PM] **Aruna HR Dvein:** Ok da en pg theryum la

[8:38 PM] **Aruna HR Dvein:** Anga mangos shop iruku

[8:38 PM] **Aruna HR Dvein:** Anga nalla irukum

[8:38 PM] **Aruna HR Dvein:** Vaa

[8:38 PM] **You:** Hmm ok varan

[8:38 PM] **Aruna HR Dvein:** Ok da

[8:38 PM] **You:** Vanthutu call pannura

[8:38 PM] **Aruna HR Dvein:** Ne kita vara apo cl panu

[8:38 PM] **You:** Hmm

[8:46 PM] __[Call]__

[8:47 PM] __[Call]__

---

## October 1, 2026

[7:01 PM] __[Call]__

---

## October 2, 2026

[9:24 AM] **You:** Oruthan call panna

[9:24 AM] **You:** Yenna nu kekala🤦‍♂️

[12:46 PM] **Aruna HR Dvein:** It's ok bro solluren

[12:50 PM] **You:** Summa kuptan

---

## October 4, 2026

[8:53 PM] **You:** Hello

[8:54 PM] **You:** Thiruvanamali workshop yepdi jaya sri kita pochu

[9:04 PM] **Aruna HR Dvein:** Thrla enanu

[9:05 PM] **You:** Tmr poraga

[9:06 PM] **You:** Mou sing panna

[9:08 PM] **Aruna HR Dvein:** Ok munik

[9:08 PM] **You:** Hmm

---

## October 5, 2026

[8:22 AM] **You:** Yee kita 230 tha eruthuchu

[8:22 AM] **You:** Sorry 😕

[8:22 AM] **You:** Send pannitan

[8:36 AM] **Aruna HR Dvein:** Haan okiee munik

[8:36 AM] **You:** Hmm yesterday office ah ungaluku

[8:36 AM] **You:** ?

[8:37 AM] **Aruna HR Dvein:** Hm Ama

---

## October 6, 2026

[8:42 PM] **You:** Yee left aanika

[8:42 PM] **You:** Yenna achu

[8:44 PM] **You:** Hello

[8:53 PM] **Aruna HR Dvein:**
> _You: Yenna achu_
Nothing bro

[8:55 PM] **You:** Soluga

[8:55 PM] **You:** Na yethum thappa pesitana

[9:10 PM] **You:** Hello

[9:12 PM] **Aruna HR Dvein:**
> _You: Na yethum thappa pesitana_
No pa

[9:12 PM] **You:** Aprom yee

[9:12 PM] **You:** Yenna achu

[9:12 PM] **You:** Sonatha na tharium😓

[9:12 PM] **Aruna HR Dvein:** Munik thonuchi pana ah ok va edhula onu lla kekurathuku

[9:12 PM] **Aruna HR Dvein:** Viduru

[9:12 PM] **You:** Na yethum thappa pesitana

[9:13 PM] **Aruna HR Dvein:** Illaiye pa

[9:14 PM] **You:** Yee eppo pa soli pesuriga
