# WhatsApp Chat Export: Jayasree Mam Hr
Export date: October 23, 2026 at 3:27 PM

---

## August 28, 2026

[10:26 AM] __Jayasree Mam Hr's security code changed. Tap to learn more.__

[10:26 AM] __This business is now using a secure service from Meta to manage this chat. Click to learn more.__

[10:26 AM] __AI from Meta receives messages to improve AI quality and generate messages for this business. Click to learn more.__

---

## September 3, 2026

[11:35 AM] __Someone turned off disappearing messages__

[11:35 AM] **Jayasree Mam Hr:** [album message]

[11:35 AM] **Jayasree Mam Hr:** [album message]

[11:35 AM] **Jayasree Mam Hr:** Jeppair engineering college

[11:35 AM] **Jayasree Mam Hr:** [album message]

[11:35 AM] **Jayasree Mam Hr:** [album message]

[11:35 AM] **Jayasree Mam Hr:** Hindustan college of arts and science(17/07/2026)

[11:35 AM] **Jayasree Mam Hr:** Jeppair engineering college (10/08/26 to 12/08/26)

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image] Sapta wwaww ka

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

[11:35 AM] **Jayasree Mam Hr:** [Image]

---

## September 4, 2026

[7:38 AM] **You:** Hii

[7:54 AM] **Jayasree Mam Hr:** Nan mam kita ketukura wait munik

[8:03 AM] **You:** Athu illa mam

[8:03 AM] **You:** Clg work Shop doubt

[8:03 AM] **You:** Atha kupta

[8:04 AM] **Jayasree Mam Hr:** Okok

[8:05 AM] **Jayasree Mam Hr:** Courses Iruku today

[8:05 AM] **Jayasree Mam Hr:**
> _You: Clg work Shop doubt_
Enna doubt

[8:06 AM] **You:**
> _Jayasree Mam Hr: Courses Iruku today_
Hmm

[8:16 AM] **You:** Mou yethukaka sign pannom

[8:16 AM] **You:** Prepos

[9:16 AM] **Jayasree Mam Hr:** Purila munik

[9:16 AM] **Jayasree Mam Hr:** Today Selvamani varala , navin varamata la

[9:16 AM] **You:**
> _Jayasree Mam Hr: Today Selvamani varala , navin varamata la_
Selvamani varuvan

[9:17 AM] **You:** Tmr tha Avan leave

[9:17 AM] **Jayasree Mam Hr:** Okok ama ama😅

[9:17 AM] **Jayasree Mam Hr:** Nan today Saturday nanachita😂

[9:19 AM] **You:**
> _Jayasree Mam Hr: Nan today Saturday nanachita😂_
🤣

[9:19 AM] **You:** Tea navin ku cancel panniruga

[9:35 AM] **Jayasree Mam Hr:** Okok

[9:44 AM] **Jayasree Mam Hr:** [album message]

[9:44 AM] **Jayasree Mam Hr:** [Image]

[9:44 AM] **Jayasree Mam Hr:** [Image]

[9:44 AM] **Jayasree Mam Hr:** [Image]

[9:44 AM] **Jayasree Mam Hr:** Addon courses

[9:44 AM] **You:** Avalothana

[9:44 AM] **You:** Workshop illa ah

[9:44 AM] **Jayasree Mam Hr:** Ama

[9:44 AM] **You:** Intership

[9:45 AM] **Jayasree Mam Hr:**
> _You: Intership_
Intership illa

[9:45 AM] **You:**
> _Jayasree Mam Hr: Addon courses_
Yenna course

[9:45 AM] **You:** Java python ai data science

[9:45 AM] **Jayasree Mam Hr:** Data analyst 
Ai & ds

[9:45 AM] **You:** Hmm

[9:45 AM] **Jayasree Mam Hr:** [Voice message]

[9:46 AM] **You:** Hmm ok

[9:51 AM] **You:** Mam

[9:51 AM] **You:** Mou thana

[9:59 AM] **Jayasree Mam Hr:** Yes muni

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [album message]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

[11:32 AM] **Jayasree Mam Hr:** [Forwarded] [Image]

---

## September 9, 2026

[2:54 PM] **Jayasree Mam Hr:** Hi

[2:58 PM] **You:** [Document] Dvein.pdf

[7:57 PM] **Jayasree Mam Hr:** TMR 8:30 vanthuru

[7:57 PM] **Jayasree Mam Hr:** Munik marakatha

[8:15 PM] **You:** Hmm

[8:15 PM] **You:** Meeting ah

[9:48 PM] **Jayasree Mam Hr:** Ama ama

---

## September 10, 2026

[9:23 AM] **Jayasree Mam Hr:** https://forms.gle/J18dowrU3opPam4h9

[9:35 AM] **Jayasree Mam Hr:** https://forms.gle/b74T1a89Fqvn2YaK6

[1:26 PM] **Jayasree Mam Hr:** [Image]

[1:26 PM] **Jayasree Mam Hr:** [Image]

[1:43 PM] **Jayasree Mam Hr:** [Forwarded] [Document] Ms Sahana R - Resume.pdf

[1:45 PM] **Jayasree Mam Hr:** 9994885399

[1:47 PM] **Jayasree Mam Hr:** 9894226350

---

## September 11, 2026

[9:43 AM] **Jayasree Mam Hr:** Oi

[9:43 AM] **Jayasree Mam Hr:** Vanthutiya

[9:43 AM] **Jayasree Mam Hr:** Ennoda laptop charger edutu va?

[9:50 AM] **You:** Okay

[12:39 PM] **Jayasree Mam Hr:** [Forwarded] [Document] II B.SC CS NAME LIST (ADD-ON) 2026 SEP.xlsx

[12:39 PM] **Jayasree Mam Hr:** [Forwarded] [Document] ADDON_COURSE_II B.Sc. CS S1 ATTENDANCE.xlsx

[12:39 PM] **Jayasree Mam Hr:** [Forwarded] [Document] addon certificate.xlsx

---

## September 12, 2026

[7:10 AM] __Jayasree Mam Hr's security code changed. Tap to learn more.__

[7:10 AM] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[7:18 AM] __This business is now using a secure service from Meta to manage this chat. Click to learn more.__

[11:11 AM] **Jayasree Mam Hr:** [Forwarded] [Document] DVein_AddOn_Course_Proposal_Hindustan_College_IIIYear_AIDS.pdf

[11:15 AM] **Jayasree Mam Hr:** [Forwarded] [Document] DVein_AddOn_Course_Proposal_Hindustan_College.pdf

[11:16 AM] **You:** 2la yethu format la pananum

[11:17 AM] **Jayasree Mam Hr:** Data science format

[11:17 AM] **You:** Hm

[11:33 AM] **You:** Eppo ethu ready panna porathu yentha clg

[11:33 AM] **You:** Clg name

[11:35 AM] **Jayasree Mam Hr:** Sri balaji chockalingam engineering college

[12:01 PM] **You:** Antha clg sts Yenna department

[12:02 PM] **Jayasree Mam Hr:** Department thr la ya

[12:02 PM] **Jayasree Mam Hr:** Department la vena vidu

[12:03 PM] **You:** Hmm

[12:03 PM] **Jayasree Mam Hr:** Sekarama sent panu

[12:27 PM] **You:** [Document] Sri balaji chockalingam engineering college.docx

[12:28 PM] **You:** check pannikoga yethachum change pananum na soluga change panniran

[12:29 PM] **Jayasree Mam Hr:** Ok ok

[12:30 PM] **Jayasree Mam Hr:** Screenshot shot sent pandriya enna ku

[12:30 PM] **Jayasree Mam Hr:** Open yagala?

[12:31 PM] **You:** [Image]

[12:32 PM] **You:** [Image]

[12:32 PM] **You:** niga kututha formet la ya tha pannirukan

[12:34 PM] **You:**
> _Jayasree Mam Hr: Screenshot shot sent pandriya enna ku_
Laptop la open pannuga

[12:34 PM] **Jayasree Mam Hr:** [Image]

[12:35 PM] **You:**
> _Jayasree Mam Hr: Image_
[Voice message]

[12:36 PM] **Jayasree Mam Hr:** jayasrihr.dveininnovations@gmail.com

[12:37 PM] **Jayasree Mam Hr:** 3 hourses pathidu

[12:37 PM] **Jayasree Mam Hr:** [Voice message]

[12:38 PM] **You:** Okay

[12:38 PM] **You:** Titen la paruga send panitan

[12:42 PM] **Jayasree Mam Hr:** Hands on tools enga

[12:44 PM] **You:** Hindustan la erutha atha formet tha poturukan

[12:44 PM] **You:** Athula hands on tool illa

[12:44 PM] **You:** Yethuku kila varanum

[12:46 PM] **Jayasree Mam Hr:** Mail paru

[12:47 PM] **Jayasree Mam Hr:** [Image]

[1:05 PM] **You:** [Document] Sri balaji chockalingam engineering college1.docx

[1:06 PM] **You:** Mail paaru

[1:11 PM] **You:** Check pannuga

[1:11 PM] **You:** Okay na pdf ah send panniruvan

[1:49 PM] **Jayasree Mam Hr:** Okok

[2:28 PM] **Jayasree Mam Hr:** 8015288323

[2:29 PM] **You:** Yenathu

[2:29 PM] **You:** Ethu

[2:30 PM] **Jayasree Mam Hr:** Summa sent pana

[2:35 PM] **Jayasree Mam Hr:**
> _You: Document: Sri balaji chockalingam engineering college1.docx_
Pdf

[2:35 PM] **You:** Okay

[2:41 PM] **Jayasree Mam Hr:** Sent panitya?

[2:41 PM] **You:** [Forwarded] [Document] Sri balaji chockalingam engineering college1.pdf

[2:55 PM] **Jayasree Mam Hr:** Nan sent pana tha pathiya

[2:55 PM] **Jayasree Mam Hr:** Titan la

[2:56 PM] **You:** Illa

[2:56 PM] **Jayasree Mam Hr:** Paru

[2:56 PM] **Jayasree Mam Hr:** [Voice message]

[2:57 PM] **You:** 😕

[2:58 PM] **Jayasree Mam Hr:** Ne oru vati nan sent pana tha para

[2:59 PM] **You:** Requirement form college

[2:59 PM] **You:** Athana

[3:03 PM] **Jayasree Mam Hr:** Ama

[3:12 PM] **You:** Niga change panniruvigala

[3:12 PM] **You:** Or

[3:49 PM] **Jayasree Mam Hr:** Nan share panida

[3:49 PM] **Jayasree Mam Hr:** Vida

[3:49 PM] **You:** Hmm ok

[3:52 PM] **Jayasree Mam Hr:** [Voice message]

[3:52 PM] **You:** Okay thank you 🫡💥

[3:55 PM] **Jayasree Mam Hr:** Okok

---

## September 13, 2026

[7:29 PM] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

[7:29 PM] __Jayasree Mam Hr's security code changed. Tap to learn more.__

---

## September 15, 2026

[9:33 AM] **Jayasree Mam Hr:** Oi

[9:33 AM] **Jayasree Mam Hr:** Ennoda personal WhatsApp last seen kathutha paru?

[9:37 AM] **You:** Katithu

[9:38 AM] **You:** Sunday

[9:38 AM] **You:** Night 8.16

[9:38 AM] **You:** Last seen

[9:40 AM] **Jayasree Mam Hr:** Okok munik

[9:40 AM] **Jayasree Mam Hr:** Personal WhatsApp open yagala

[9:40 AM] **Jayasree Mam Hr:** New phone la pana paru apo

[10:12 AM] **You:** Hmm okay

[10:12 AM] **You:** Food ku solitigala

[10:12 AM] **You:** Tmr ku

[10:12 AM] **Jayasree Mam Hr:** Illa

[10:12 AM] **Jayasree Mam Hr:** Tmr vagikala ma or Saturday?

[10:12 AM] **Jayasree Mam Hr:** Tmr nanga Hindustan clg poitu vom

[10:13 AM] **Jayasree Mam Hr:** Pg vanthutiya ne ?

[10:17 AM] **You:**
> _Jayasree Mam Hr: Tmr nanga Hindustan clg poitu vom_
Okay

[10:17 AM] **You:**
> _Jayasree Mam Hr: Pg vanthutiya ne ?_
Night tha kelampuvan

[10:31 AM] **Jayasree Mam Hr:** Okok

[10:31 AM] **Jayasree Mam Hr:**
> _You: Night tha kelampuvan_
Epo morning variviya?

[10:32 AM] **You:**
> _Jayasree Mam Hr: Epo morning variviya?_
S

[10:32 AM] **Jayasree Mam Hr:** Okok

[10:33 AM] **Jayasree Mam Hr:** Ellarum miss panu la ?

[10:35 AM] **You:**
> _Jayasree Mam Hr: Ellarum miss panu la ?_
Ama🥲

[10:35 AM] **You:** 😓

[10:37 AM] **Jayasree Mam Hr:** Next diwali pova pola

[10:37 AM] **Jayasree Mam Hr:**
> _You: Ama🥲_
Seri seri apo id card kudu thu

[10:38 AM] **You:**
> _Jayasree Mam Hr: Seri seri apo id card kudu thu_
[Sticker]

[10:38 AM] **You:** [Sticker]

[10:39 AM] **Jayasree Mam Hr:** 😂😂

[1:07 PM] **Jayasree Mam Hr:** Oi

[1:07 PM] **Jayasree Mam Hr:** Namba oru hod sir kita poi

[1:07 PM] **Jayasree Mam Hr:** Pesinola

[1:08 PM] **Jayasree Mam Hr:** Athu bca department tha na

[1:10 PM] **You:**
> _Jayasree Mam Hr: Athu bca department tha na_
Sari ah thariyala

[3:22 PM] **Jayasree Mam Hr:** Oi

[3:22 PM] **Jayasree Mam Hr:** Discord message etho vanthucha?

[3:39 PM] **You:** [Image]

[3:39 PM] **You:** Etha vanthuruku

[3:39 PM] **You:**
> _Jayasree Mam Hr: Discord message etho vanthucha?_
Vera yenna

[3:39 PM] **Jayasree Mam Hr:** Okok

[3:39 PM] **You:** [Image]

[3:40 PM] **Jayasree Mam Hr:** Aiii enakuu

[3:40 PM] **You:** 🤣

[3:40 PM] **Jayasree Mam Hr:** Unnku 3 mutta ya

[3:40 PM] **You:** 🤣yes

[3:40 PM] **You:** [Sticker]

[3:41 PM] **Jayasree Mam Hr:** [Sticker]

[3:41 PM] **Jayasree Mam Hr:** Nala saptuu vaa

[3:42 PM] **Jayasree Mam Hr:** Work pana no la

[3:42 PM] **You:**
> _Jayasree Mam Hr: Work pana no la_
[Sticker]

[3:42 PM] **Jayasree Mam Hr:** 😂😂

[5:19 PM] **You:** Yenga poturukaka

[5:19 PM] **You:** Diwali leave

[5:32 PM] **Jayasree Mam Hr:** Ok discord la

[5:32 PM] **Jayasree Mam Hr:** Unnku varala ya?

[5:32 PM] **You:** Ill

[5:32 PM] **Jayasree Mam Hr:** Paru nala

[5:32 PM] **Jayasree Mam Hr:** Unna add panala yo nan?

[5:33 PM] **You:** Panala yethula varum

[5:33 PM] **Jayasree Mam Hr:** Wait nan check pandra

[5:33 PM] **You:** Annosment ah

[5:33 PM] **Jayasree Mam Hr:**
> _You: Panala yethula varum_
Discord la illa

[5:33 PM] **Jayasree Mam Hr:** Sry

[5:33 PM] **Jayasree Mam Hr:** Titan

[5:33 PM] **You:** Okay wait

[5:33 PM] **Jayasree Mam Hr:** Oi

[5:34 PM] **Jayasree Mam Hr:** Office la ya sapta Nala iruko ma? Illa na direct yango poi sapturigala?

[5:36 PM] **You:**
> _Jayasree Mam Hr: Office la ya sapta Nala iruko ma? Illa na direct yango poi sapturigala?_
Yelarukitaum ketukoga

[5:36 PM] **You:** Because ethu only my dission illa la🤷‍♂️

[5:36 PM] **Jayasree Mam Hr:** Ne aolu

[5:36 PM] **Jayasree Mam Hr:** Slu

[5:53 PM] **Jayasree Mam Hr:** Oi

[5:53 PM] **Jayasree Mam Hr:** 2030

[5:53 PM] **Jayasree Mam Hr:** 11 dum briyani+ 65 solikuka

[6:22 PM] **You:** Okay

---

## September 16, 2026

[1:17 PM] **Jayasree Mam Hr:** Enna ku photo eduthu share oanu

[1:17 PM] **Jayasree Mam Hr:** Panu

[2:05 PM] **You:** [Image]

[5:03 PM] **You:** https://meet.google.com/spr-xcid-csv

[5:04 PM] **You:** https://meet.google.com/irr-mbmv-mzr

---

## September 17, 2026

[6:13 PM] **You:** Mam

[6:13 PM] **You:** Na eppo Yenna pannurathu

[6:13 PM] **You:** Course illa today

[6:13 PM] **Jayasree Mam Hr:** Aruna kita ketu

[6:13 PM] **You:** Yenna keka

[6:13 PM] **Jayasree Mam Hr:** Man kita keka solu muni

[6:13 PM] **You:** Niga ketu soluga mam Ora work ah mutuchurum

[6:14 PM] **Jayasree Mam Hr:**
> _You: Yenna keka_
Ne enna keka no ma atha kelu

[6:14 PM] **Jayasree Mam Hr:** Seri iru

[6:14 PM] **Jayasree Mam Hr:**
> _You: Niga ketu soluga mam Ora work ah mutuchurum_
[Sticker]

[6:14 PM] **You:**
> _Jayasree Mam Hr: Sticker_
[Sticker]

[6:15 PM] **Jayasree Mam Hr:** 😂😂

[6:16 PM] **Jayasree Mam Hr:**
> _You: Sticker_
Aruna va keka sola, apram mam muni muni soldra avnuku support pandriya nu kepaga

[6:16 PM] **Jayasree Mam Hr:** Aruna oda students la ava ga atha soldra

[6:16 PM] **You:** Hmm ok

[6:17 PM] **Jayasree Mam Hr:** Okok

[6:17 PM] **Jayasree Mam Hr:** Ketu enna ku solu

[6:17 PM] **You:** Hmm ok

[6:22 PM] **You:** Mam msg pakala

[6:22 PM] **You:** Call om yetukala

[6:22 PM] **Jayasree Mam Hr:** Seri iru

[6:22 PM] **Jayasree Mam Hr:** 10 clock vario ko

[6:24 PM] **You:** Hmm ok thank u🥲

[6:31 PM] **Jayasree Mam Hr:** Tmr clg la ethna mani Iruka no

[6:31 PM] **Jayasree Mam Hr:** 9 to ?

[6:33 PM] **You:** clg 9 to 2.30

[7:01 PM] **Jayasree Mam Hr:** Ok mam kalaba solitaga

[7:18 PM] **You:** Hmm ok

[7:52 PM] **Jayasree Mam Hr:** Oi

[8:58 PM] **Jayasree Mam Hr:** https://www.instagram.com/reel/DdCCae8OFxk/?stkn=aTJsdjlsYzQ1M3hv

[9:18 PM] **You:**
> _Jayasree Mam Hr: https://www.instagram.com/reel/DdCCae8OFxk/?stkn=aTJsdjlsYzQ1M3hv_
Saturday reels panalan😂

[9:28 PM] **Jayasree Mam Hr:** Ne , aruna panuga na edukura😅😂

[9:29 PM] **You:**
> _Jayasree Mam Hr: Ne , aruna panuga na edukura😅😂_
🤣🤣

---

## September 18, 2026

[5:39 AM] **You:** 6.30 kala bus yeranum

[5:40 AM] **You:** 🥱

[5:48 AM] **Jayasree Mam Hr:** Ama ama

[5:48 AM] **Jayasree Mam Hr:** Pathu poitu vaga

[5:48 AM] **Jayasree Mam Hr:** Bus eritu soluga

[6:18 AM] **You:** Kelampitom

[6:18 AM] **You:**
> _Jayasree Mam Hr: Ama ama_
Panakaraga 5.30 ku gym poriga

[6:18 AM] **You:** Yangala paaruga office porom 5.30 ku

[6:18 AM] **You:** 😓

[6:19 AM] **Jayasree Mam Hr:**
> _You: Panakaraga 5.30 ku gym poriga_
Nan pola

[6:19 AM] **Jayasree Mam Hr:**
> _You: Yangala paaruga office porom 5.30 ku_
Bus eritiya

[6:19 AM] **You:**
> _Jayasree Mam Hr: Bus eritiya_
Illa

[6:19 AM] **Jayasree Mam Hr:** Poi eraru

[6:19 AM] **Jayasree Mam Hr:** Kasu?

[6:36 AM] **You:**
> _Jayasree Mam Hr: Kasu?_
🥲

[6:36 AM] **You:** Loan keturukan bank la vanthurum bus ku

[6:37 AM] **Jayasree Mam Hr:** Nejama va?

[6:37 AM] **You:** 😂

[6:37 AM] **Jayasree Mam Hr:** Aruna kita kelu mam kuduthagala nu?

[6:39 AM] **You:** Illa

[6:39 AM] **You:** Kutukala

[6:41 AM] **Jayasree Mam Hr:** Apaiya nan mesg panita mam ku

[6:41 AM] **Jayasree Mam Hr:** Iru patha soluvaga

[6:42 AM] **Jayasree Mam Hr:** Nala poi panuga, Unnoda motivation pasagalauku kuduthu

[6:42 AM] **Jayasree Mam Hr:** Intership join pana vai👊😂

[6:42 AM] **Jayasree Mam Hr:** Ipo porathuku kasu Iruka?

[12:21 PM] **Jayasree Mam Hr:** [Forwarded] Mam, Could you conduct two days workshop on agentic AI.?

[4:45 PM] **Jayasree Mam Hr:** Oi

[5:24 PM] **You:** Ahh

[5:24 PM] **You:** Soluga

[5:30 PM] **Jayasree Mam Hr:** Office varuvigala?

[5:37 PM] **You:**
> _Jayasree Mam Hr: Office varuvigala?_
Manasachiya illa ah

[5:37 PM] **You:** Naga v2 ku varava 8 mani akirum

[5:37 PM] **You:** 😓

[5:37 PM] **Jayasree Mam Hr:** Apdiya Seri seri pathu poga

[5:37 PM] **You:**
> _Jayasree Mam Hr: Apdiya Seri seri pathu poga_
😓

[5:37 PM] **Jayasree Mam Hr:**
> _You: Manasachiya illa ah_
Nan keta summa , mam illa

[5:37 PM] **You:**
> _Jayasree Mam Hr: Nan keta summa , mam illa_
😂

[5:37 PM] **You:** Okay

[5:38 PM] **Jayasree Mam Hr:** Travel evolu neram?

[5:38 PM] **You:**
> _Jayasree Mam Hr: Travel evolu neram?_
3 hours

[5:38 PM] **Jayasree Mam Hr:** Okok

[5:38 PM] **Jayasree Mam Hr:** Enga Iruka ipo

[5:38 PM] **You:** Yenala mutiyala

[5:38 PM] **Jayasree Mam Hr:** Video pathoya

[5:38 PM] **Jayasree Mam Hr:** ?

[5:38 PM] **Jayasree Mam Hr:** Insta la

[5:39 PM] **You:**
> _Jayasree Mam Hr: Enga Iruka ipo_
Yetho road la rompa naram pokuthu

[5:39 PM] **You:**
> _Jayasree Mam Hr: Insta la_
Yenna video

[5:39 PM] **Jayasree Mam Hr:** https://www.instagram.com/reel/DdbWk41P-jk/?stkn=MTdrZm5kYW5odHM3Zw==

[5:39 PM] **Jayasree Mam Hr:**
> _You: Yetho road la rompa naram pokuthu_
Seri seri

[5:41 PM] **You:**
> _Jayasree Mam Hr: https://www.instagram.com/reel/DdbWk41P-jk/?stkn=MTdrZm5kYW5odHM3Zw==_
Athu yaru oru payan hero mathiri erukan data science la

[5:46 PM] **Jayasree Mam Hr:**
> _You: Athu yaru oru payan hero mathiri erukan data science la_
Apo heroine mari irukaga avaga yaru😂

[5:47 PM] **You:**
> _Jayasree Mam Hr: Apo heroine mari irukaga avaga yaru😂_
Athu name yetho HR am🥴

[5:47 PM] **You:** Over ah seen potum

[5:57 PM] **Jayasree Mam Hr:**
> _You: Over ah seen potum_
Nan na ennaku seen pota va thryathu

[6:35 PM] **You:** Call pannuga

[6:35 PM] **You:** Hello

[6:38 PM] **Jayasree Mam Hr:** Oi

[6:38 PM] **Jayasree Mam Hr:** Wait enga akka video call pandra ga

[6:39 PM] **You:**
> _Jayasree Mam Hr: Wait enga akka video call pandra ga_
Akka ah mukiyam

[6:39 PM] **You:** Munik mukiyam illa appo

[6:52 PM] **You:** [album message]

[6:52 PM] **You:** [Image]

[6:52 PM] **You:** [Image]

[6:52 PM] **You:** [Image]

[6:52 PM] **You:** [Image]

[6:54 PM] **Jayasree Mam Hr:** Supperrr , vera level 🔥🔥🔥God bless you ✨

[7:22 PM] **You:**
> _Jayasree Mam Hr: Supperrr , vera level 🔥🔥🔥God bless you ✨_
Thank you 🙌💥

[7:22 PM] **Jayasree Mam Hr:** Unga veetula ellarum share panu

[7:27 PM] **You:** Colour aakitu share pannuvan😂😂😂

[7:27 PM] **You:** Appo tha payan chennai poe hero mathiri akitanu soluvaga

[7:27 PM] **You:** Karuva payana anupa kutathu

[7:28 PM] **Jayasree Mam Hr:**
> _You: Colour aakitu share pannuvan😂😂😂_
Seri seri , unga veetu ku ne hero tha

[7:28 PM] **You:**
> _Jayasree Mam Hr: Seri seri , unga veetu ku ne hero tha_
[Sticker]

[7:28 PM] **Jayasree Mam Hr:** Veetu poigala?

[7:28 PM] **You:** Illa

[7:29 PM] **You:** 30 minutes

[8:00 PM] **Jayasree Mam Hr:** Okok poitu Nala rest eduga

[8:05 PM] **You:** [Forwarded] [Image]

[8:05 PM] **You:** Mam

[8:05 PM] **You:** Ethu my friend

[8:05 PM] **You:** Unganala mutucha amount send pannuga

[8:05 PM] **You:** 🙏🥺🙇‍♂️

[8:06 PM] **Jayasree Mam Hr:** Enna achi ?

[8:06 PM] **You:** Accident

[8:07 PM] **Jayasree Mam Hr:** Nejama yankita illa ,500 cash tha Iruku . Enna ku salary poda kuda  potu irupa

[8:22 PM] **You:** Okay onnum problem illa ungaluku tharucha group ku send pannuga

[8:22 PM] **You:** Friends

---

## September 19, 2026

[8:00 AM] **You:** Gm

[8:00 AM] **You:** Have a nice day ❤️

[8:00 AM] **You:** Student yeppo varuvaga online class timing

[8:00 AM] **You:** Ennum thukuriga pola

[8:45 AM] **Jayasree Mam Hr:** Okok

[8:45 AM] **Jayasree Mam Hr:**
> _You: Have a nice day ❤️_
Ena ku sutha odabu mudila , night sudden na

[8:46 AM] **Jayasree Mam Hr:** Vomiting, headache ellam vanthuchi

[8:46 AM] **Jayasree Mam Hr:** Night fulla la thugala , appa token hospital pokukaga

[8:46 AM] **Jayasree Mam Hr:** Unnku paravala ya ipo?

[8:46 AM] **You:**
> _Jayasree Mam Hr: Night fulla la thugala , appa token hospital pokukaga_
Yeah thiter nu

[8:47 AM] **You:** Eppo parava illa ah

[8:47 AM] **You:**
> _Jayasree Mam Hr: Unnku paravala ya ipo?_
Hmm ok

[8:47 AM] **Jayasree Mam Hr:**
> _You: Yeah thiter nu_
Thr la ya , clg food set yagala pola .

[8:47 AM] **Jayasree Mam Hr:** Tension vera

[8:48 AM] **You:**
> _Jayasree Mam Hr: Thr la ya , clg food set yagala pola ._
Limit ah saptanum .. 😂

[8:48 AM] **You:**
> _Jayasree Mam Hr: Tension vera_
Sari sari nala tablet potu thukuga sari akirum

[8:51 AM] **Jayasree Mam Hr:**
> _You: Limit ah saptanum .. 😂_
Ahh yapadi la illa 😂

[8:51 AM] **Jayasree Mam Hr:** Mam kita leave keka pora

[8:51 AM] **Jayasree Mam Hr:**
> _You: Sari sari nala tablet potu thukuga sari akirum_
Okok

[8:51 AM] **You:**
> _Jayasree Mam Hr: Mam kita leave keka pora_
Hmm ok

[8:51 AM] **You:** Rest yetuga leave potu

[8:51 AM] **Jayasree Mam Hr:** Okok

[9:23 AM] **You:** Timing

[9:23 AM] **You:** Class ku

[9:25 AM] **Jayasree Mam Hr:** Group la paru

[9:26 AM] **You:** Okay

[9:26 AM] **You:** 10 to 12 ah

[9:27 AM] **Jayasree Mam Hr:** Ama ama

[9:28 AM] **You:** Okay

[11:25 AM] **Jayasree Mam Hr:** Low pressure solitaga🥲

[11:25 AM] **You:** Apdina

[11:26 AM] **You:** Yethanala apdi varum ma ?

[11:26 AM] **Jayasree Mam Hr:**
> _You: Yethanala apdi varum ma ?_
Water nariya kudikanoma

[11:26 AM] **Jayasree Mam Hr:** Athu la etho illa sonaga

[11:26 AM] **You:** Niga nalathana water kutipaga

[11:26 AM] **Jayasree Mam Hr:** Nala rest edu sonaga

[11:27 AM] **You:**
> _Jayasree Mam Hr: Nala rest edu sonaga_
Hmm nala thukuga

[11:27 AM] **Jayasree Mam Hr:**
> _You: Niga nalathana water kutipaga_
Atha thr🥲

[11:27 AM] **Jayasree Mam Hr:**
> _You: Hmm nala thukuga_
Okok

[11:27 AM] **Jayasree Mam Hr:** Byee

[11:27 AM] **Jayasree Mam Hr:** 1 students tha na

[11:27 AM] **Jayasree Mam Hr:** Okok

[11:35 AM] **You:**
> _Jayasree Mam Hr: 1 students tha na_
Ama

[12:14 PM] **Jayasree Mam Hr:** Oi

[12:14 PM] **Jayasree Mam Hr:** Enna heart potu Iruka

[12:14 PM] **You:**
> _Jayasree Mam Hr: Enna heart potu Iruka_
Output

[12:14 PM] **You:** Vanthuruku

[12:15 PM] **You:** Atha

[12:15 PM] **Jayasree Mam Hr:** Mam patha

[12:15 PM] **You:** Na yethum thappa anupaliya

[12:15 PM] **You:** 🙄

[12:15 PM] **Jayasree Mam Hr:** Seri seri

[12:16 PM] **You:** Ponuka kuta veliyatura avanukalam veturuka😂 output vanthuchunu na heart pota athu kuthama

[12:16 PM] **You:** 🤣

[12:17 PM] **Jayasree Mam Hr:**
> _You: Ponuka kuta veliyatura avanukalam veturuka😂 output vanthuchunu na heart pota athu kuthama_
Selvamani ku da pota thu illa

[12:17 PM] **Jayasree Mam Hr:** Ava students la

[12:17 PM] **You:** 😂

[12:19 PM] **Jayasree Mam Hr:** Ithu variko yaro potu nan patha illa

[12:19 PM] **You:** Hmm ok

[12:20 PM] **Jayasree Mam Hr:** Seri

[5:15 PM] **You:** Hii

[5:41 PM] **Jayasree Mam Hr:** Slu

[5:43 PM] **You:** Today

[5:43 PM] **You:** 5.30 ah

[5:43 PM] **You:** Illa 6.30 ah

[5:43 PM] **You:** Work complete time

[5:44 PM] **Jayasree Mam Hr:** 5:00 clock tha poka

[5:44 PM] **Jayasree Mam Hr:** Pola

[5:44 PM] **You:** Hmm

---

## September 20, 2026

[6:07 AM] **Jayasree Mam Hr:**
> _You: Video: ✨_
🙌🔥📈

[9:01 AM] **You:** 🤩

[9:43 AM] **You:** Eppo health okay ah

[11:12 AM] **Jayasree Mam Hr:** Ahh Okok seriyachi

[11:40 AM] **You:** Hmm

[1:50 PM] **Jayasree Mam Hr:** Mm

---

## September 21, 2026

[11:50 AM] **You:** III S-I
BALAJI A
YOGESHWARAN P

III S-II 
GOKULRAJ K
PARTHASARATHI N
SERAN K
PADMA PRIYA A
SHAM K
GOKUL G
KISHORE MANI A
SANJAI S
KAVIPRIYA N

[1:22 PM] **Jayasree Mam Hr:** Oi

[1:22 PM] **Jayasree Mam Hr:** Enaku oru help panu

[1:50 PM] **You:** Soluga

[1:50 PM] **You:** Health issues ah

[1:58 PM] **You:**
> _You: Health issues ah_
Okay ah

[4:10 PM] **Jayasree Mam Hr:**
> _You: Health issues ah_
Ama ama

[4:10 PM] **Jayasree Mam Hr:** Sudden romba fever yachi

[4:10 PM] **Jayasree Mam Hr:** Tmr rom vanthu injection pola solitukaga

[4:13 PM] **You:** Hmm ok

[4:13 PM] **You:** Paathukoga

[4:13 PM] **You:**
> _Jayasree Mam Hr: Enaku oru help panu_
Yenna help

[4:14 PM] **Jayasree Mam Hr:** [Document] Attendance sheet -2- - Sheet1.pdf

[4:14 PM] **Jayasree Mam Hr:** Ithu continue pana attendance next week ku

[4:15 PM] **Jayasree Mam Hr:** Last friend variko

[4:15 PM] **Jayasree Mam Hr:** Ellarum present podudu

[4:15 PM] **You:** Voice send pannuga

[4:15 PM] **Jayasree Mam Hr:** [Voice message]

[4:16 PM] **Jayasree Mam Hr:** Puritha

[4:16 PM] **You:** Okay

[4:26 PM] **You:** [Image]

[4:26 PM] **You:** okay ah

[4:43 PM] **Jayasree Mam Hr:** Panitya?

[4:44 PM] **You:**
> _You: Image_
Okay ah ethu

[4:45 PM] **Jayasree Mam Hr:** [Voice message]

[4:45 PM] **You:** [Voice message]

[4:47 PM] **Jayasree Mam Hr:** Ama ama

[4:50 PM] **You:** Ama na Yenna meaning

[4:52 PM] **Jayasree Mam Hr:** [Voice message]

[4:52 PM] **You:** Hmm

[4:54 PM] **You:** [Voice message]

[4:55 PM] **Jayasree Mam Hr:** [Voice message]

[4:55 PM] **Jayasree Mam Hr:** [Voice message]

[4:55 PM] **Jayasree Mam Hr:**
> _Jayasree Mam Hr: Document: Attendance sheet -2- - Sheet1.pdf_
[Voice message]

[4:56 PM] **You:** [Voice message]

[4:56 PM] **You:** [Image]

[4:58 PM] **Jayasree Mam Hr:** Seri sent panu

[4:58 PM] **Jayasree Mam Hr:** Pdf va

[4:59 PM] **You:** Hmm

[5:00 PM] **You:** [Document] Attendance sheet -2- - Sheet1 (1).pdf

[5:19 PM] **You:** Mam

[5:20 PM] **You:** Today and tmrw course pasagaluku interview erukam

[5:20 PM] **You:** So avaga nala attend panna mutiyatham

[5:20 PM] **You:** Tmr 9.30 ku vanthuran

[5:20 PM] **You:** Today?

[6:11 PM] **Jayasree Mam Hr:** Ok munik

[6:11 PM] **Jayasree Mam Hr:**
> _You: Today?_
Mam kita inform paniduga

[6:11 PM] **You:** Na Yenna pannurathu

[6:11 PM] **You:**
> _Jayasree Mam Hr: Mam kita inform paniduga_
Nana pannirava

[6:11 PM] **You:** Mam tmr varuvagala

[6:11 PM] **Jayasree Mam Hr:** Today 7:30 to 8:30

[6:12 PM] **Jayasree Mam Hr:** Oru class Iruku edukuriya

[6:12 PM] **Jayasree Mam Hr:** Pg la ya

[6:12 PM] **You:**
> _Jayasree Mam Hr: Oru class Iruku edukuriya_
No pls😕

[6:12 PM] **Jayasree Mam Hr:**
> _You: Nana pannirava_
Aruna kita solidu

[6:13 PM] **Jayasree Mam Hr:** Mam ku oba seri illa

[6:13 PM] **You:** Today matum no

[6:14 PM] **You:** Tmr yetukuran

[6:14 PM] **You:** Tmr course illa

[6:14 PM] **You:** Tmr kantipa yetukuran

[6:14 PM] **You:** Pls

[6:14 PM] **You:**
> _Jayasree Mam Hr: Mam ku oba seri illa_
Apdiya

[6:14 PM] **You:** Yenna achu

[6:14 PM] **Jayasree Mam Hr:** Seri

[6:14 PM] **Jayasree Mam Hr:**
> _You: Yenna achu_
Odabu seri illa

[6:15 PM] **You:** Hmm ok

[6:15 PM] **You:** Na Yenna panatum 6.30 ku poratha ?

[6:15 PM] **Jayasree Mam Hr:** Aruna

[6:15 PM] **Jayasree Mam Hr:** Ne mam msg panu illa na

[6:15 PM] **You:** Hmm ok

[6:16 PM] **Jayasree Mam Hr:** Oi

[6:17 PM] **Jayasree Mam Hr:** Mam, online tha Iruka ga

[6:17 PM] **Jayasree Mam Hr:** Msg panu

[6:18 PM] **You:** [Forwarded] Ok pa Athuku etha madhiri schedule alignment pannirunga

[6:18 PM] **You:** Mam

[6:18 PM] **You:** Epdi splirukaka

[6:19 PM] **You:** Na kelampikirava ? 😕

[6:19 PM] **You:** Tmr yetukuran confirm

[6:19 PM] **You:** Evening

[6:19 PM] **You:** Hello

[6:23 PM] **You:** Mam

[6:25 PM] **Jayasree Mam Hr:** Oi

---

## September 22, 2026

[3:14 AM] **You:** Mam

[3:14 AM] **You:** Nenchu rompa valikuthu

[3:14 AM] **You:** Hospital poran

[3:15 AM] **You:** Navin selvamani ku msg pannirukan

[12:53 PM] **Jayasree Mam Hr:** Hi

[12:53 PM] **Jayasree Mam Hr:** Enna yachii

[12:53 PM] **Jayasree Mam Hr:** Nan ipo tha phone on pandra

[1:01 PM] **Jayasree Mam Hr:** Pathukoo

[1:01 PM] **Jayasree Mam Hr:** Enna periya problem ahh

[1:04 PM] **You:** Hmm

[1:13 PM] **Jayasree Mam Hr:** Ne free ya Iruka apo call panu

[1:14 PM] **You:** Free tha

[1:15 PM] **Jayasree Mam Hr:** Call panuva?

[1:16 PM] **Jayasree Mam Hr:** Oi

[1:25 PM] **Jayasree Mam Hr:** Good evening, Mam.

My mentor has been changed recently, and I would like to request if I could continue with my previous mentor. I have already been attending classes with my previous mentor for the past one month, so I have become comfortable with their teaching style and way of explaining the concepts.

Since the new mentor’s teaching style is different, I’m finding it a little difficult to adjust and understand the lessons as easily as before. It’s not that the new mentor is not teaching well; I’m just more comfortable and able to understand better with my previous mentor.

I would really appreciate it if I could continue with my previous mentor. I’m also completely okay if the classes are conducted online.

So, I kindly request you to please consider changing my mentor back to my previous mentor.

Thank you for understanding, Mam.

[1:25 PM] **Jayasree Mam Hr:** Suba msg

[1:41 PM] **You:**
> _Jayasree Mam Hr: Good evening, Mam.

My mentor has been changed recently, and I would like to request if I could continue with my previous mentor. I have already been attending classes with my previous mentor for the past one month, so I have become comfortable with their teaching style and way of explaining the concepts.

Since the new mentor’s teaching style is different, I’m finding it a little difficult to adjust and understand the lessons as easily as before. It’s not that the new mentor is not teaching well; I’m just more comfortable and able to understand better with my previous mentor.

I would really appreciate it if I could continue with my previous mentor. I’m also completely okay if the classes are conducted online.

So, I kindly request you to please consider changing my mentor back to my previous mentor.

Thank you for understanding, Mam._
Mam ku send pannigala

[1:52 PM] **Jayasree Mam Hr:** Okok

[4:57 PM] **Jayasree Mam Hr:** Oi

[7:30 PM] **Jayasree Mam Hr:** Recharge panitya?

[9:19 PM] **You:** Illa

---

## September 23, 2026

[6:09 AM] **Jayasree Mam Hr:** Yen?

[6:09 AM] **Jayasree Mam Hr:** Parvala night tu?

[6:14 AM] **You:** Na native vanthutan

[7:17 AM] **Jayasree Mam Hr:** Night ta?

[7:17 AM] **Jayasree Mam Hr:** Veetu ku poitya

[7:47 AM] **You:** Ama

[7:47 AM] **You:** Sir tha yethi vetaru bus

[7:47 AM] **Jayasree Mam Hr:** Apdiya Seri

[7:48 AM] **You:** Sir nala pathukitaru

[7:48 AM] **Jayasree Mam Hr:**
> _You: Sir nala pathukitaru_
Apadiya, Nala sir tha pola

[7:48 AM] **Jayasree Mam Hr:** Ne ethna mani ku reach yana?

[7:48 AM] **Jayasree Mam Hr:** Yesterday

[7:52 AM] **You:**
> _Jayasree Mam Hr: Ne ethna mani ku reach yana?_
Eppo tha

[7:57 AM] **Jayasree Mam Hr:** Seri seri

[7:57 AM] **Jayasree Mam Hr:** Paru

[9:28 AM] **You:** Hmm

[9:29 AM] **You:** Ungaluku okay ah

[9:29 AM] **You:** Health

[9:42 AM] **Jayasree Mam Hr:** Konjam paravala ipo etho

[9:42 AM] **Jayasree Mam Hr:** Tired apdiya tha Iruku

[9:42 AM] **Jayasree Mam Hr:** Unnku epdi Iruku?

[9:43 AM] **You:** Hospital poka porom 11 clock

[9:43 AM] **You:**
> _Jayasree Mam Hr: Tired apdiya tha Iruku_
Hmm nala tv paaruga sariya akirum

[9:49 AM] **Jayasree Mam Hr:** Okok

[9:49 AM] **Jayasree Mam Hr:**
> _You: Hmm nala tv paaruga sariya akirum_
Tv ya

[9:49 AM] **Jayasree Mam Hr:** 😂😂

[2:42 PM] **Jayasree Mam Hr:** Oi

[4:04 PM] **You:** [Sticker]

[4:32 PM] **Jayasree Mam Hr:** Enna yachi checkup

[4:39 PM] **You:** muscle demage nu sonaga

[4:40 PM] **Jayasree Mam Hr:** Yen demage yacha?

[4:41 PM] **You:** Yethulium etuchutana nu ketaga

[4:41 PM] **Jayasree Mam Hr:** Purila la ya

[4:42 PM] **You:** Ati patuchanu ketaga

[4:42 PM] **You:** Yepayachum

[4:44 PM] **Jayasree Mam Hr:** Apdina

[4:45 PM] **You:** அடி பட்டுச்சா apdinu ketaga

[4:46 PM] **Jayasree Mam Hr:** Ohh okok

[4:46 PM] **Jayasree Mam Hr:** Paducha?

[4:46 PM] **You:** Illa

[4:46 PM] **Jayasree Mam Hr:** Vera enna sonaga

[4:47 PM] **You:** Tablet injection potaga

[4:47 PM] **Jayasree Mam Hr:** Epo office varuva ne?

[4:47 PM] **You:** Rest yetuka solirukaka

[4:47 PM] **Jayasree Mam Hr:**
> _You: Tablet injection potaga_
Okok

[4:47 PM] **Jayasree Mam Hr:**
> _You: Rest yetuka solirukaka_
Okok rest eduthu ta va

[4:47 PM] **You:**
> _Jayasree Mam Hr: Epo office varuva ne?_
Thariyala sari aana otana ooti vanthuruvan

[4:47 PM] **Jayasree Mam Hr:** Rest eduthu porumiya ma va

[4:48 PM] **You:**
> _Jayasree Mam Hr: Rest eduthu porumiya ma va_
My family kita sonna sir nala pathukitarunu

[4:48 PM] **Jayasree Mam Hr:** Call panuva ipo?

[4:49 PM] **You:**
> _Jayasree Mam Hr: Call panuva ipo?_
Wait

[4:49 PM] **You:** My friend vera yerathu poutanam

[4:49 PM] **You:** 🥺

[4:50 PM] **You:**
> _You: Image_
Evan

[4:50 PM] **You:** 🥺

[4:50 PM] **Jayasree Mam Hr:** Yanta paiya na?

[4:50 PM] **You:** Na unga kita amount ketan la antha payan

[4:50 PM] **You:** 🥺

[4:51 PM] **Jayasree Mam Hr:** Enkita nejama illa ne vera

[4:51 PM] **Jayasree Mam Hr:** Avaga parents evolu kastam pathu irupagala

[4:51 PM] **Jayasree Mam Hr:** Age 23 tha

[4:51 PM] **You:**
> _Jayasree Mam Hr: Enkita nejama illa ne vera_
Athalam onnum illa

[4:51 PM] **You:**
> _Jayasree Mam Hr: Age 23 tha_
Ama

[4:51 PM] **You:**
> _Jayasree Mam Hr: Avaga parents evolu kastam pathu irupagala_
🥺

[4:52 PM] **Jayasree Mam Hr:** 🥲

[4:52 PM] **Jayasree Mam Hr:** Recharge panitya?

[4:52 PM] **You:** Yenala eppo anga poka kuta mutiyala

[4:52 PM] **You:**
> _Jayasree Mam Hr: Recharge panitya?_
Illa

[4:52 PM] **Jayasree Mam Hr:** Mam, vera tmr variya kekuraga

[4:52 PM] **You:**
> _Jayasree Mam Hr: Mam, vera tmr variya kekuraga_
Ungalava

[4:52 PM] **Jayasree Mam Hr:** Ama ne rest edu

[4:53 PM] **Jayasree Mam Hr:**
> _You: Ungalava_
Ama , clg mou sing pana, enna suthama mudila

[4:53 PM] **You:**
> _Jayasree Mam Hr: Ama , clg mou sing pana, enna suthama mudila_
Ayyo😓

[4:53 PM] **Jayasree Mam Hr:** 🙃

---

## September 24, 2026

[12:19 PM] **Jayasree Mam Hr:** Oi

[12:19 PM] **You:** Hmm

[12:19 PM] **You:** Soluga

[12:20 PM] **Jayasree Mam Hr:** Monday tha varuviya ne?

[12:20 PM] **You:** Thariyala 😓

[12:20 PM] **You:** Suthama mutiyala

[12:20 PM] **Jayasree Mam Hr:** Seri seri

[12:20 PM] **You:** Avalo injection

[12:21 PM] **Jayasree Mam Hr:** Enaku night mudiya , morning hospital poitu vantha🙃

[12:21 PM] **You:** Musel demage ah erukama

[12:21 PM] **Jayasree Mam Hr:** Okok

[12:21 PM] **You:**
> _Jayasree Mam Hr: Enaku night mudiya , morning hospital poitu vantha🙃_
Eppo v2 la ah erukiga

[12:21 PM] **Jayasree Mam Hr:** Ama ama

[12:21 PM] **You:** Hmm sun tv la seriel paruga

[12:22 PM] **You:** Amma kuta join panni

[12:22 PM] **You:** Sari ah akirum

[12:22 PM] **You:** Trust jeses

[12:24 PM] **Jayasree Mam Hr:** Ne vera suthama mudila

[12:25 PM] **You:**
> _Jayasree Mam Hr: Ne vera suthama mudila_
Chanel maatha mutiyala ah

[12:25 PM] **You:** Tv la

[12:26 PM] **Jayasree Mam Hr:** Illa tv va office la tha iruku

[12:38 PM] **Jayasree Mam Hr:** Mam msg panikuraga

[12:57 PM] **You:** Yenanu

[12:57 PM] **You:** Msg panaga

[12:57 PM] **Jayasree Mam Hr:** Wait soldra

[12:57 PM] **You:** Hmm

[1:00 PM] **You:** Yethum problem ha

[2:07 PM] **Jayasree Mam Hr:** Illa illa

[3:03 PM] **You:** Hmm

[5:22 PM] **You:** Mam

[5:22 PM] **You:** Course pasagaluku yarachum yetuka Sola mutiuma

[5:23 PM] **You:** Nigala solura mathiri kuta soluga

[5:27 PM] **Jayasree Mam Hr:** Enna sola no

[5:27 PM] **Jayasree Mam Hr:** Class illa na

[5:30 PM] **You:** Ill vera yarachum yetuka mutiuma

[5:31 PM] **You:** Avagaluku leave nariya vanthutuchu

[5:31 PM] **You:** Sari vetuga avagaluku tharium

[5:31 PM] **You:** Yenaku health issues nu

[5:31 PM] **You:** Vetuga

[5:33 PM] **Jayasree Mam Hr:** Okok

[5:33 PM] **Jayasree Mam Hr:** Online pasaga kita mato solita

[5:34 PM] **You:** Hmm

---

## September 25, 2026

[7:34 PM] __[Call]__

---

## September 28, 2026

[11:28 AM] **Jayasree Mam Hr:** [Forwarded] [Document] Sri_Ramakrishna_College_DS_AI_Workshop_Proposal.pdf

[11:28 AM] **Jayasree Mam Hr:** Genetic Ai

[12:20 PM] **Jayasree Mam Hr:** [Forwarded] [Image]

[12:41 PM] **You:** [Document] Sri_Ramakrishna_College_DS_AI_Workshop_Proposal_removed.pdf

[12:55 PM] **You:** [Document] Sri_Ramakrishna_College_DS_AI_Workshop_Proposal_removed (2).pdf

[12:59 PM] **You:** [Document] Sri_Ramakrishna_College_DS_AI_Workshop_Proposal (2).pdf

---

## October 3, 2026

[9:45 AM] **Jayasree Mam Hr:** [Forwarded] [Document] Sri_Ramakrishna_College_DS_AI_Workshop_Proposal (2).pdf

[3:12 PM] **You:** KAYALVIZHI.V - S2
LOGESH.K - S2

SUDHA MERLIN D - S3
SHAM M - S3
LAKSHMI P - S3

[4:08 PM] **You:** [Forwarded] [Contact: BEGIN:VCARD
VERSION:3.0
N:Mam;Shanthi;Sona;;
FN:Shanthi Sona Mam
TEL;type=Mobile;waid=919790201617:+91 97902 01617
END:VCARD]

---

## October 6, 2026

[4:49 PM] **You:** [Document] Payslip_DVN-CORE-001_May_2026_7402328077352631582_1778566612976.pdf

---

## October 7, 2026

[4:47 PM] **Jayasree Mam Hr:** [album message]

[4:47 PM] **Jayasree Mam Hr:** [Video]

[4:47 PM] **Jayasree Mam Hr:** [Image]

[4:47 PM] **Jayasree Mam Hr:** [Video]

[5:19 PM] **You:** [Forwarded] [2 contacts]

---

## October 8, 2026

[4:56 PM] **Jayasree Mam Hr:** [Forwarded] [Document] MoU Signing College Collaboration Presentation.pdf

[5:50 PM] **You:** [Forwarded] For internship,You need all these:
1.)Internship Completion Certificate.
2.) Internship Report (Day by day process)
3.) PPT Presentation

[5:51 PM] **You:** +91 63812 69573

---

## October 21, 2026

[11:04 AM] **Jayasree Mam Hr:** Sree Venkateswara College of Engineering

[11:23 AM] **Jayasree Mam Hr:** Sri Venkateswara College Of Engineering & Technology(Autonomous)

[5:07 PM] **Jayasree Mam Hr:** [album message]

[5:07 PM] **Jayasree Mam Hr:** [Video]

[5:07 PM] **Jayasree Mam Hr:** [Video]

[5:08 PM] **Jayasree Mam Hr:** [Video]

[5:08 PM] **Jayasree Mam Hr:** [Video]

[5:08 PM] **Jayasree Mam Hr:** [Video]

[5:08 PM] **Jayasree Mam Hr:** [Image]

[5:08 PM] **Jayasree Mam Hr:** [Image]

[5:08 PM] **Jayasree Mam Hr:** [Video]

[5:08 PM] **Jayasree Mam Hr:** [Image]

---

## October 22, 2026

[3:47 PM] **Jayasree Mam Hr:** Ennoda personal WhatsApp lastseen solu

[3:54 PM] **You:** Okay

[3:54 PM] __[Call]__

[3:55 PM] **You:** Na last seen off panni vachurukan so yenaku katathu last seen

[3:55 PM] **Jayasree Mam Hr:** Illa ya off pana la

[3:56 PM] **You:** Morning 9.48

[3:56 PM] **Jayasree Mam Hr:** Okok conform la

[3:56 PM] **You:** _Waiting for this message. This may take a while._

[3:56 PM] **You:**
> _Jayasree Mam Hr: Okok conform la_
Confirm

---

## October 23, 2026

[2:02 PM] **Jayasree Mam Hr:** [Forwarded] [Document] Data Analyst Proposal.pdf

[2:02 PM] **Jayasree Mam Hr:** Sekarama panidu sent panu

[3:08 PM] **You:** [Document]

[3:26 PM] **You:** [Document]
